# Triage SOPs

Use the audit invariants to select SOPs. Do not improvise. Cross-root, cycle, hub, PR DAG dependency and blocked-merge cases require human-controlled triage.
