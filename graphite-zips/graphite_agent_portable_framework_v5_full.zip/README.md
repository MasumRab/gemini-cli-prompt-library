# Graphite Agent Portable Framework V5 Full

Run in a Git repository:

```bash
python .graphite-agent/tools/graphite_agent.py all --local-only
```

Or stepwise:

```bash
python .graphite-agent/tools/discover_repo.py
python .graphite-agent/tools/topology_analyse.py
python .graphite-agent/tools/relationship_analyse.py
python .graphite-agent/tools/discover_targets.py
python .graphite-agent/tools/target_analyse.py
python .graphite-agent/tools/root_health.py
python .graphite-agent/tools/replay_risk.py
python .graphite-agent/tools/hunk_decompose.py
python .graphite-agent/tools/stack_order.py
python .graphite-agent/tools/validate_replay.py || true
python .graphite-agent/tools/validate_targets.py || true
python .graphite-agent/tools/validate_roots.py || true
python .graphite-agent/tools/validate_stack_order.py || true
python .graphite-agent/tools/checklist.py || true
python .graphite-agent/tools/analyze_consistency.py || true
python .graphite-agent/tools/generate_questions.py
python .graphite-agent/tools/generate_recommendations.py
python .graphite-agent/tools/generate_agent_todos.py
python .graphite-agent/tools/prepare_agent_briefing.py
python .graphite-agent/tools/build_command_plan.py
python .graphite-agent/tools/write_report.py
python .graphite-agent/tools/converge.py || true
```

Execution is analyzer-first and gated. Real mutation is not wired by default.
