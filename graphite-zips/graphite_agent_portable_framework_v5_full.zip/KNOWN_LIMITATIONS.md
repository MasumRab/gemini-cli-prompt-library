# Known Limitations

- Replay simulation is conservative and does not yet perform full temporary-worktree cherry-pick simulation by default.
- PR metadata integration is local-only unless extended with a GitHub adapter.
- Hunk decomposition parses standard git diff output and provides heuristic labels, not semantic understanding.
- Stack ordering is conservative and prefers blocking over unsafe inference.
- Execution boundary is intentionally not wired to real Graphite mutation commands by default.
- YAML parsing is best with PyYAML; otherwise only JSON/simple fallback is available.
