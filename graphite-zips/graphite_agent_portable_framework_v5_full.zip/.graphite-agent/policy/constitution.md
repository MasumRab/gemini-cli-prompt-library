# Graphite Agent Constitution

- Analyzer mode by default.
- No semantic conflict auto-resolution.
- No mutation without explicit approval.
- No hardcoded repo paths in core code.
- Patch equivalence is triage-only.
