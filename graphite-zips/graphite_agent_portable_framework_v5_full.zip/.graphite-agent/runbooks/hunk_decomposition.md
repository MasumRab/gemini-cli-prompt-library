# Hunk Decomposition

Generated V5 documentation for hunk_decomposition. Follow artifact-first workflow and validators before execution.
