#!/usr/bin/env python3
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent))
import argparse,json
from lib.recommendations import record_option
p=argparse.ArgumentParser(); p.add_argument('--branch'); p.add_argument('--option',required=True); p.add_argument('--reason',required=True); p.add_argument('--question'); p.add_argument('--scope')
a=p.parse_args(); print(json.dumps(record_option(a.branch,a.option,a.reason,a.question,a.scope),indent=2))
