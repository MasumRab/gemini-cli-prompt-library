from __future__ import annotations
from .io import read_json, write_artifact, LATEST_DIR, get_run_id
from . import git_utils as g
def build():
    rid=get_run_id(); inv=read_json(LATEST_DIR/'repo_inventory.json',{})
    roots=set(inv.get('targets',{}).get('discovered',[]) or []) or {'main'}
    branches=inv.get('branches',{}).get('local',[])
    nodes={r:{'type':'root','name':r,'head':g.head(r) or g.head('origin/'+r)} for r in roots}
    edges=[]; i=0
    for b in branches:
        nodes[b]={'type':'branch','name':b,'head':g.head(b)}
        candidates=[]
        for r in roots:
            ref=r if g.head(r) else 'origin/'+r
            if g.head(ref) and g.is_ancestor(ref,b): candidates.append(r)
        parent=sorted(candidates)[0] if candidates else None
        if parent:
            i+=1; edges.append({'id':f'edge-{i:06d}','from':parent,'to':b,'edge_type':'nearest_root_ancestor','classification':'executable_candidate','confidence':'medium','evidence':[f'{parent} is ancestor of {b}']})
        else:
            i+=1; edges.append({'id':f'edge-{i:06d}','from':None,'to':b,'edge_type':'unrooted','classification':'triage_only','confidence':'medium','evidence':['no discovered root ancestor found']})
    graph={'run_id':rid,'roots':sorted(roots),'nodes':nodes,'edges':edges}
    write_artifact('topology_graph.json',graph,rid); return graph
