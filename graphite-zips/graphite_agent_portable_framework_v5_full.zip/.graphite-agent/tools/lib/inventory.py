from __future__ import annotations
from . import git_utils as g
from .config import load_config
from .io import write_artifact, get_run_id
def discover(local_only=True,new_run=True,config_path=None):
    rid=get_run_id(new=new_run); cfg=load_config(config_path); gr=g.root()
    if not gr: raise RuntimeError('Not inside a Git repository')
    st=g.status(); targets=set(cfg.get('roots',{}).get('configured',[]) or [])
    oh=g.origin_head()
    if oh: targets.add(oh)
    inv={'run_id':rid,'repo':{'git_root':gr,'path':gr,'current_branch':g.branch(),'is_dirty':bool(st)},'state':{**g.active_state(gr),'conflicted_files':g.unmerged(),'status_porcelain':st},'branches':{'local':g.local_branches(),'remote':g.remote_branches()},'targets':{'configured':sorted(cfg.get('roots',{}).get('configured',[]) or []),'origin_head':oh,'discovered':sorted(targets)},'pr_metadata':{'available':False,'reason':'local_only' if local_only else 'gh adapter not configured','items':[]}}
    write_artifact('repo_inventory.json',inv,rid); return inv
