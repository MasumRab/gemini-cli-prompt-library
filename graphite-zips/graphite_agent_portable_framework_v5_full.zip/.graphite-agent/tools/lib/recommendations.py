from __future__ import annotations
from .io import read_json, write_artifact, write_text_artifact, append_jsonl, OUTPUTS_DIR, LATEST_DIR, get_run_id
from datetime import datetime, timezone
def questions():
    rid=get_run_id(); out=[]; risk=read_json(LATEST_DIR/'replay_risk.json',{}); tm=read_json(LATEST_DIR/'target_matrix.json',{'branches':{}}); rh=read_json(LATEST_DIR/'root_health.json',{'roots':{}})
    for b,m in tm.get('branches',{}).items():
        if m.get('requires_user_decision'): out.append({'id':f'q-target-{len(out)+1:06d}','type':'target_intent','branch':b,'question':f'Which target should {b} use?','options':[f"target={c['target']}" for c in m.get('candidate_targets',[])]+['leave_triage','exclude_from_migration'],'recommended_option':'leave_triage','reason':'Target intent unresolved'})
    for r,h in rh.get('roots',{}).items():
        if h.get('health')=='stale': out.append({'id':f'q-root-{len(out)+1:06d}','type':'root_refresh_policy','target_root':r,'question':f'How should stale root {r} be handled?','options':['refresh_root_before_stacking','create_clean_integration_base','do_not_refresh_root','leave_affected_branches_triage'],'recommended_option':'create_clean_integration_base','reason':'Root health is stale'})
    if risk.get('summary',{}).get('overall_risk')=='high': out.append({'id':f'q-replay-{len(out)+1:06d}','type':'conflict_resolution_policy','branch':risk.get('branch'),'question':'How should replay blockers be handled?','options':['resolve_manually_then_rerun','abort_rebase_then_reanalyse','leave_branch_blocked'],'recommended_option':'resolve_manually_then_rerun','reason':'Replay risk is high'})
    res={'run_id':rid,'questions':out}; write_artifact('decision_prompts.json',res,rid); return res
def recommendations():
    rid=get_run_id(); risk=read_json(LATEST_DIR/'replay_risk.json',{}); q=read_json(LATEST_DIR/'decision_prompts.json',{'questions':[]}); opts=[]
    if risk.get('summary',{}).get('overall_risk')=='high': opts=[{'id':'opt-001','label':'Block execution and resolve replay blockers','risk':'low','automation_level':'safe','why':['High replay risk detected'],'todos':['Resolve/abort active replay state','Rerun replay_risk','Rerun validate_replay']},{'id':'opt-002','label':'Run hunk decomposition before planning','risk':'medium','automation_level':'analysis_only','why':['Replay blockers may need decomposition'],'todos':['Run hunk_decompose','Review semantic decisions']}]
    else: opts=[{'id':'opt-001','label':'Proceed to validators and dry-run command plan','risk':'low','automation_level':'analysis_only','why':['No critical replay blockers detected'],'todos':['Run checklist','Run analyze_consistency','Build command plan']}]
    res={'run_id':rid,'recommendations':[{'id':'rec-000001','branch':risk.get('branch'),'situation':risk.get('summary',{}).get('primary_reason'),'recommended_option':opts[0]['id'],'options':opts,'open_questions':[x['id'] for x in q.get('questions',[])]}]}; write_artifact('recommendation_options.json',res,rid); return res
def todos():
    rid=get_run_id(); recs=read_json(LATEST_DIR/'recommendation_options.json',{'recommendations':[]}); out=[]; i=0
    for rec in recs.get('recommendations',[]):
        for todo in rec.get('options',[{}])[0].get('todos',[]): i+=1; out.append({'id':f'todo-{i:06d}','status':'open','priority':'critical' if i==1 else 'high','branch':rec.get('branch'),'description':todo,'completion_check':'rerun converge and validators'})
    res={'run_id':rid,'todos':out}; write_artifact('agent_todos.json',res,rid); return res
def briefing():
    rid=get_run_id(); risk=read_json(LATEST_DIR/'replay_risk.json',{}); recs=read_json(LATEST_DIR/'recommendation_options.json',{}); td=read_json(LATEST_DIR/'agent_todos.json',{'todos':[]})
    text=f"# Agent Briefing\n\nRun ID: `{rid}`\n\nReplay risk: **{risk.get('summary',{}).get('overall_risk','unknown')}**\n\n{risk.get('summary',{}).get('primary_reason','')}\n\n## Todos\n" + ''.join(f"- {t['id']}: {t['description']}\n" for t in td.get('todos',[]))
    write_text_artifact('agent_briefing.md',text,rid,True); work={'run_id':rid,'status':'blocked' if risk.get('summary',{}).get('overall_risk')=='high' else 'ready_for_validation','briefing':'agent_briefing.md','recommendations':'recommendation_options.json','todos':'agent_todos.json','next_agent_action':{'command':'python .graphite-agent/tools/present_options.py'}}; write_artifact('agent_work_package.json',work,rid); return text
def record_option(branch, option, reason, question=None, scope=None):
    ev={'event_id':'dec-'+datetime.now(timezone.utc).strftime('%Y%m%d%H%M%S'),'event_type':'decision_recorded','decision_type':'recommendation_option','branch':branch,'question_id':question,'scope':scope,'choice':'option='+option,'reason':reason,'run_id':get_run_id(),'timestamp':datetime.now(timezone.utc).isoformat()}; append_jsonl(OUTPUTS_DIR/'decision_log.jsonl',ev); return ev
def converge():
    rid=get_run_id(); rv=read_json(LATEST_DIR/'validation/replay_validation.json',{}); tv=read_json(LATEST_DIR/'validation/target_validation.json',{}); rt=read_json(LATEST_DIR/'validation/root_validation.json',{}); sv=read_json(LATEST_DIR/'validation/stack_order_validation.json',{}); td=read_json(LATEST_DIR/'agent_todos.json',{'todos':[]})
    blockers=[]
    for rep in [rv,tv,rt,sv]: blockers+=rep.get('failed_checks',[])
    open_t=[t for t in td.get('todos',[]) if t.get('status')!='done']
    res={'run_id':rid,'converged':not blockers and not open_t,'status':'blocked' if blockers or open_t else 'pass','remaining_blockers':blockers,'remaining_todos':[t['id'] for t in open_t],'next_command':'python .graphite-agent/tools/generate_agent_todos.py' if open_t else None}; write_artifact('convergence_report.json',res,rid); return res
