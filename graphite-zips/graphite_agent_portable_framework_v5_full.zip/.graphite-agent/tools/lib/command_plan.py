from __future__ import annotations
from .io import read_json, write_artifact, LATEST_DIR, get_run_id
def build(dry_run=True):
    rid=get_run_id(); reps=[read_json(LATEST_DIR/'validation/replay_validation.json',{}),read_json(LATEST_DIR/'validation/target_validation.json',{}),read_json(LATEST_DIR/'validation/root_validation.json',{}),read_json(LATEST_DIR/'validation/stack_order_validation.json',{})]
    blocked=[r for r in reps if r.get('status')=='blocked']; so=read_json(LATEST_DIR/'stack_order.json',{'targets':{}})
    cmds=[]
    if not blocked:
        for _,s in so.get('targets',{}).items():
            for stack in s.get('stacks',[]):
                for b in stack.get('branches',[]): cmds.append({'type':'suggested_graphite_track','branch':b['branch'],'parent':b['resolved_parent'],'command':f"gt track {b['branch']} --parent {b['resolved_parent']}",'requires_approval':True})
    plan={'run_id':rid,'mode':'dry_run' if dry_run else 'approved_required','execution_allowed':False,'blocked_by':[r for r in ['validate_replay','validate_targets','validate_roots','validate_stack_order'] if blocked],'commands':cmds}
    write_artifact('command_plan.json',plan,rid); return plan
