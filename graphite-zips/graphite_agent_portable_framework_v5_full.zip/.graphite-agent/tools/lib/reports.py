from __future__ import annotations
from .io import read_json, write_text_artifact, LATEST_DIR, get_run_id
def write_report():
    rid=get_run_id(); inv=read_json(LATEST_DIR/'repo_inventory.json',{}); risk=read_json(LATEST_DIR/'replay_risk.json',{}); so=read_json(LATEST_DIR/'stack_order.json',{}); cp=read_json(LATEST_DIR/'command_plan.json',{})
    lines=['# Branch Stacking Report','',f'Run ID: `{rid}`','','## Executive Summary',f"Replay risk: **{risk.get('summary',{}).get('overall_risk','unknown')}**",f"Execution allowed: **{cp.get('execution_allowed',False)}**",'','## Repository Inventory',f"- Git root: `{inv.get('repo',{}).get('git_root','unknown')}`",f"- Current branch: `{inv.get('repo',{}).get('current_branch','unknown')}`",'','## Replay Risk',risk.get('summary',{}).get('primary_reason','No replay risk summary.'),'','## Stack Order',f"Targets: {len(so.get('targets',{}))}",'','## Recommended Next Commands']
    if risk.get('summary',{}).get('overall_risk')=='high': lines+=['1. Resolve replay blockers.','2. Run replay_risk.py.','3. Run validate_replay.py.']
    else: lines+=['1. Run checklist.py.','2. Run analyze_consistency.py.','3. Run build_command_plan.py --dry-run.']
    text='\n'.join(lines)+'\n'; write_text_artifact('branch_stacking_report.md',text,rid,True); return text
