from __future__ import annotations
from .io import read_json, write_artifact, LATEST_DIR, get_run_id
def discover_targets():
    rid=get_run_id(); inv=read_json(LATEST_DIR/'repo_inventory.json',{})
    c={}
    for r in inv.get('targets',{}).get('discovered',[]): c[r]={'target':r,'confidence':'high' if r==inv.get('targets',{}).get('origin_head') else 'medium','score':85 if r==inv.get('targets',{}).get('origin_head') else 60,'signals':['discovered from repo inventory']}
    out={'run_id':rid,'candidates':c}; write_artifact('target_candidates.json',out,rid); return out
def analyse_targets():
    rid=get_run_id(); topo=read_json(LATEST_DIR/'topology_graph.json',{'edges':[]}); cand=read_json(LATEST_DIR/'target_candidates.json',{'candidates':{}})
    branches={}; qs=[]; i=0
    for e in topo.get('edges',[]):
        if e.get('to') in cand.get('candidates',{}): continue
        inferred=e.get('from')
        req=inferred is None
        qrefs=[]
        if req:
            i+=1; qid=f'q-target-{i:06d}'; qrefs=[qid]
            qs.append({'id':qid,'branch':e.get('to'),'question_type':'target_intent','question':f'Which target should {e.get("to")} use?','options':['target='+x for x in cand.get('candidates',{})]+['leave_triage','exclude_from_migration'],'recommended_option':'leave_triage','confidence':'medium'})
        branches[e.get('to')]={'declared_target':None,'candidate_targets':[{'target':inferred,'confidence':'medium','evidence':['topology inferred root']}] if inferred else [],'confirmed_targets':[],'diagnostic_category':'target_confirmed' if not req else 'target_intent_required','requires_user_decision':req,'question_refs':qrefs}
    out={'run_id':rid,'branches':branches}; write_artifact('target_matrix.json',out,rid); write_artifact('target_questions.json',qs,rid); return out
