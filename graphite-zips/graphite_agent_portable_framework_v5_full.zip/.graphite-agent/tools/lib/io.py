from __future__ import annotations
import json, os
from datetime import datetime, timezone
from pathlib import Path
from typing import Any
AGENT_DIR=Path('.graphite-agent')
OUTPUTS_DIR=AGENT_DIR/'outputs'
RUNS_DIR=OUTPUTS_DIR/'runs'
LATEST_DIR=OUTPUTS_DIR/'latest'
REPORTS_DIR=AGENT_DIR/'reports'
CURRENT_RUN_FILE=OUTPUTS_DIR/'current_run.txt'
def ensure_dirs():
    for p in [OUTPUTS_DIR,RUNS_DIR,LATEST_DIR,REPORTS_DIR]: p.mkdir(parents=True,exist_ok=True)
def utc_run_id(): return datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')
def get_run_id(new=False):
    ensure_dirs(); env=os.environ.get('GRAPHITE_AGENT_RUN_ID')
    if env and not new: CURRENT_RUN_FILE.write_text(env); return env
    if not new and CURRENT_RUN_FILE.exists(): return CURRENT_RUN_FILE.read_text().strip()
    rid=utc_run_id(); CURRENT_RUN_FILE.write_text(rid); return rid
def run_dir(run_id=None):
    p=RUNS_DIR/(run_id or get_run_id()); (p/'validation').mkdir(parents=True,exist_ok=True); return p
def read_json(path, default=None):
    p=Path(path)
    if not p.exists(): return default
    return json.loads(p.read_text(encoding='utf-8'))
def write_json(path, data):
    p=Path(path); p.parent.mkdir(parents=True,exist_ok=True); p.write_text(json.dumps(data,indent=2,sort_keys=True),encoding='utf-8')
def write_artifact(name, data, run_id=None):
    rd=run_dir(run_id); write_json(rd/name,data); write_json(LATEST_DIR/name,data); return rd/name
def write_text_artifact(name,text,run_id=None,also_report=False):
    rd=run_dir(run_id); p=rd/name; p.parent.mkdir(parents=True,exist_ok=True); p.write_text(text,encoding='utf-8')
    lp=LATEST_DIR/name; lp.parent.mkdir(parents=True,exist_ok=True); lp.write_text(text,encoding='utf-8')
    if also_report:
        rp=REPORTS_DIR/Path(name).name; rp.parent.mkdir(parents=True,exist_ok=True); rp.write_text(text,encoding='utf-8')
    return p
def append_jsonl(path,data):
    p=Path(path); p.parent.mkdir(parents=True,exist_ok=True)
    with p.open('a',encoding='utf-8') as f: f.write(json.dumps(data,sort_keys=True)+'\n')
def read_jsonl(path):
    p=Path(path)
    if not p.exists(): return []
    return [json.loads(x) for x in p.read_text(encoding='utf-8').splitlines() if x.strip()]
