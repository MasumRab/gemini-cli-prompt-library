from __future__ import annotations
import subprocess
from pathlib import Path
def git(args, check=False):
    p=subprocess.run(['git']+args,capture_output=True,text=True)
    if check and p.returncode: raise RuntimeError(f"git {' '.join(args)} failed: {p.stderr}")
    return p.returncode,p.stdout.strip(),p.stderr.strip()
def root():
    c,o,_=git(['rev-parse','--show-toplevel']); return o if c==0 else None
def branch():
    c,o,_=git(['branch','--show-current']); return o if c==0 and o else None
def status():
    c,o,_=git(['status','--porcelain=v1','-uall']); return o.splitlines() if c==0 and o else []
def local_branches():
    c,o,_=git(['for-each-ref','refs/heads','--format=%(refname:short)']); return o.splitlines() if c==0 and o else []
def remote_branches():
    c,o,_=git(['for-each-ref','refs/remotes','--format=%(refname:short)']); return [x for x in o.splitlines() if not x.endswith('/HEAD')] if c==0 and o else []
def origin_head():
    c,o,_=git(['symbolic-ref','refs/remotes/origin/HEAD'])
    return o.rsplit('/',1)[-1] if c==0 and o.startswith('refs/remotes/origin/') else None
def head(ref):
    c,o,_=git(['rev-parse',ref]); return o if c==0 else None
def merge_base(a,b):
    c,o,_=git(['merge-base',a,b]); return o if c==0 else None
def is_ancestor(a,b): return git(['merge-base','--is-ancestor',a,b])[0]==0
def upstream():
    c,o,_=git(['rev-parse','--abbrev-ref','--symbolic-full-name','@{u}']); return o if c==0 and o else None
def active_state(git_root=None):
    g=Path(git_root or root() or '.')/'.git'
    return {'active_rebase':(g/'rebase-merge').exists() or (g/'rebase-apply').exists(),'active_merge':(g/'MERGE_HEAD').exists(),'active_cherry_pick':(g/'CHERRY_PICK_HEAD').exists(),'active_revert':(g/'REVERT_HEAD').exists()}
def unmerged():
    out=[]; types={'DD':'both_deleted','AU':'added_by_us','UD':'delete_modify','UA':'added_by_them','DU':'delete_modify','AA':'both_added','UU':'both_modified'}
    for line in status():
        if len(line)>=4 and line[:2] in types: out.append({'path':line[3:],'status':line[:2],'conflict_type':types[line[:2]]})
    return out
def commits(ref_range):
    c,o,_=git(['log','--reverse','--pretty=format:%H%x1f%s',ref_range]);
    return [{'sha':x.split('\x1f')[0],'subject':x.split('\x1f',1)[1] if '\x1f' in x else ''} for x in o.splitlines()] if c==0 and o else []
def log_shortstat(ref_range):
    c,o,_=git(['log','--shortstat','--pretty=format:@@@%H%x1f%s',ref_range])
    if c!=0 or not o: return []
    rec=[]
    for block in o.split('@@@'):
        block=block.strip()
        if not block: continue
        lines=block.splitlines(); h=lines[0].split('\x1f'); stat=' '.join(lines[1:])
        rec.append({'commit':h[0],'subject':h[1] if len(h)>1 else '','shortstat':stat})
    return rec
def merge_commits(ref_range):
    c,o,_=git(['rev-list','--merges',ref_range]); return o.splitlines() if c==0 and o else []
def diff_name_only(ref_range=None):
    args=['diff','--name-only'] + ([ref_range] if ref_range else [])
    c,o,_=git(args); return o.splitlines() if c==0 and o else []
def diff_patch(ref_range):
    c,o,_=git(['diff',ref_range,'--unified=3']); return o if c==0 else ''
