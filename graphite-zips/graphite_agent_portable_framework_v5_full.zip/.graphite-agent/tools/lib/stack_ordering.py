from __future__ import annotations
from .io import read_json, write_artifact, LATEST_DIR, get_run_id
def build():
    rid=get_run_id(); topo=read_json(LATEST_DIR/'topology_graph.json',{'edges':[]}); tm=read_json(LATEST_DIR/'target_matrix.json',{'branches':{}}); rh=read_json(LATEST_DIR/'root_health.json',{'roots':{}}); risk=read_json(LATEST_DIR/'replay_risk.json',{})
    targets={}
    for r,h in rh.get('roots',{}).items(): targets[r]={'root_health':h.get('health'),'execution_allowed':h.get('execution_allowed',False),'blocked_reason':None if h.get('execution_allowed') else h.get('recommended_action'),'stacks':[]}
    for e in topo.get('edges',[]):
        b=e.get('to'); r=e.get('from')
        if not b or b in rh.get('roots',{}): continue
        if tm.get('branches',{}).get(b,{}).get('requires_user_decision'): continue
        if risk.get('branch')==b and risk.get('summary',{}).get('overall_risk')=='high': continue
        if r in targets and targets[r]['execution_allowed']:
            if not targets[r]['stacks']: targets[r]['stacks'].append({'stack_id':f'stack-{r}-0001','branches':[]})
            targets[r]['stacks'][0]['branches'].append({'branch':b,'order':len(targets[r]['stacks'][0]['branches'])+1,'resolved_parent':r,'action':'track_only'})
    out={'run_id':rid,'targets':targets}; write_artifact('stack_order.json',out,rid); return out
