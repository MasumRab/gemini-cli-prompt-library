from __future__ import annotations
from .io import read_json, write_artifact, LATEST_DIR, get_run_id
from . import git_utils as g
def build():
    rid=get_run_id(); topo=read_json(LATEST_DIR/'topology_graph.json',{'edges':[]}); rel=[]; i=0
    for e in topo.get('edges',[]):
        i+=1; rel.append({'id':f'rel-{i:06d}',**e})
        if e.get('from') and e.get('to'):
            rng=f"{e['from']}..{e['to']}"
            merges=g.merge_commits(rng)
            if merges:
                i+=1; rel.append({'id':f'rel-{i:06d}','from':e['from'],'to':e['to'],'edge_type':'merge_commits_in_branch_range','classification':'blocked','confidence':'high','evidence':[f'{len(merges)} merge commit(s) in {rng}'],'metadata':{'merge_commits':merges}})
    out={'run_id':rid,'edges':rel}; write_artifact('relationship_graph.json',out,rid); return out
