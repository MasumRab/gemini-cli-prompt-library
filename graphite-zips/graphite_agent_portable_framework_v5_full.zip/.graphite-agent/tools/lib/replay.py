from __future__ import annotations
import re
from pathlib import Path
from . import git_utils as g
from .config import load_config,is_generated,is_ignored
from .io import read_json, write_artifact, LATEST_DIR, get_run_id
def _shortstat(stat):
    files=0; lines=0
    m=re.search(r'(\d+) files? changed',stat); files=int(m.group(1)) if m else 0
    for m in re.finditer(r'(\d+) (insertion|deletion)',stat): lines+=int(m.group(1))
    return files,lines
def _markers(paths):
    out=[]
    for pth in paths[:200]:
        p=Path(pth)
        if p.exists() and p.is_file():
            try: txt=p.read_text(errors='ignore')
            except Exception: continue
            if '<<<<<<< ' in txt or '=======' in txt or '>>>>>>> ' in txt: out.append({'path':pth,'markers':True})
    return out
def assess(branch=None, proposed_parent=None, simulate=False):
    rid=get_run_id(); cfg=load_config(); inv=read_json(LATEST_DIR/'repo_inventory.json',{})
    current=branch or inv.get('repo',{}).get('current_branch') or g.branch(); parent=proposed_parent or g.upstream() or (inv.get('targets',{}).get('origin_head'))
    ref_parent=parent if parent and g.head(parent) else ('origin/'+parent if parent else None)
    ref_range=f'{ref_parent}..{current}' if ref_parent and current and g.head(ref_parent) and g.head(current) else None
    conflicted=g.unmerged(); st=g.active_state(inv.get('repo',{}).get('git_root'))
    paths=[x[3:] for x in g.status() if len(x)>3 and not is_ignored(x[3:],cfg)]
    markers=_markers([c['path'] for c in conflicted] or paths)
    large=[]
    if ref_range:
        for rec in g.log_shortstat(ref_range):
            f,l=_shortstat(rec.get('shortstat',''))
            if f>=cfg['replay']['large_commit_file_threshold'] or l>=cfg['replay']['large_commit_line_threshold']: large.append({**rec,'files_changed':f,'lines_changed':l,'risk':'large_mixed_commit','recommendation':'consider decomposition'})
    generated=[{'path':p,'reason':'matches generated file pattern','recommendation':'regenerate_after_replay'} for p in paths if is_generated(p,cfg)]
    merge_commits=g.merge_commits(ref_range) if ref_range else []
    high=any(st.values()) or bool(conflicted) or bool(markers)
    risk={'run_id':rid,'branch':current,'proposed_parent':parent,'summary':{'overall_risk':'high' if high else 'medium' if large or generated or merge_commits else 'low','execution_allowed':not high,'primary_reason':'active replay/conflict state detected' if high else 'review recommended' if (large or generated or merge_commits) else 'no immediate replay blockers detected'},'repository_state':{**st,'dirty_worktree':bool(g.status())},'conflicts':{'conflicted_files':conflicted,'conflict_markers_detected':markers},'commit_risks':large,'generated_file_risks':generated,'merge_commit_risks':[{'sha':m,'risk':'merge_commit_in_replay_range'} for m in merge_commits],'recommendations':[]}
    if high: risk['recommendations']+=['Resolve/abort active replay state before command planning','Rerun replay_risk after clean']
    if large: risk['recommendations'].append('Run hunk_decompose for large mixed commits')
    if generated: risk['recommendations'].append('Regenerate generated artifacts after replay when possible')
    write_artifact('replay_risk.json',risk,rid); return risk
