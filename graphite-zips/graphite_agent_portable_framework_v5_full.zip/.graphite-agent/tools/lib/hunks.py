from __future__ import annotations
import re
from . import git_utils as g
from .config import is_generated
from .io import read_json, write_artifact, write_text_artifact, LATEST_DIR, get_run_id
def decompose(branch=None):
    rid=get_run_id(); risk=read_json(LATEST_DIR/'replay_risk.json',{}); branch=branch or risk.get('branch')
    parent=risk.get('proposed_parent')
    ref_parent=parent if parent and g.head(parent) else ('origin/'+parent if parent else None)
    patch=g.diff_patch(f'{ref_parent}..{branch}') if branch and ref_parent and g.head(ref_parent) else ''
    items=[]; current_file=None
    for line in patch.splitlines():
        if line.startswith('diff --git'):
            parts=line.split(); current_file=parts[-1][2:] if len(parts)>=4 else None
        elif line.startswith('@@') and current_file:
            label='generated_artifact' if is_generated(current_file) else 'source_or_text_change'
            items.append({'branch':branch,'file':current_file,'hunk_header':line,'label':label,'recommendation':'regenerate_after_replay' if label=='generated_artifact' else 'review_or_replay'})
    for c in risk.get('conflicts',{}).get('conflicted_files',[]): items.append({'branch':branch,'file':c['path'],'label':c.get('conflict_type'),'recommendation':'manual_semantic_decision_required'})
    out={'run_id':rid,'branch':branch,'decomposition':items,'manual_semantic_decisions':[x for x in items if x['recommendation']=='manual_semantic_decision_required']}
    write_artifact('hunk_decomposition.json',out,rid)
    md='# Hunk Decomposition Report\n\n'+'\n'.join(f"- `{x['file']}` {x.get('hunk_header','')}: {x['label']} -> {x['recommendation']}" for x in items)+'\n'
    write_text_artifact('hunk_decomposition.md',md,rid,True); return out
