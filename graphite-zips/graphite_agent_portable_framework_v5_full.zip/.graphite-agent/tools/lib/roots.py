from __future__ import annotations
from .io import read_json, write_artifact, LATEST_DIR, get_run_id
def analyse_roots():
    rid=get_run_id(); tm=read_json(LATEST_DIR/'target_matrix.json',{'branches':{}}); tc=read_json(LATEST_DIR/'target_candidates.json',{'candidates':{}})
    roots={}; qs=[]; i=0
    for t in tc.get('candidates',{}):
        affected=[b for b,m in tm.get('branches',{}).items() if any(c.get('target')==t for c in m.get('candidate_targets',[]))]
        unresolved=[b for b in affected if tm['branches'][b].get('requires_user_decision')]
        stale=len(unresolved)>=2
        roots[t]={'health':'stale' if stale else 'current','diagnostic_category':'shared_root_staleness' if stale else 'root_current','affected_branches':affected,'evidence':['multiple unresolved branches for target'] if stale else ['no shared root blocker detected'],'recommended_action':'root_refresh_decision_required' if stale else 'stack_order_allowed','execution_allowed':not stale}
        if stale:
            i+=1; qs.append({'id':f'q-root-{i:06d}','target_root':t,'question_type':'root_refresh_policy','question':f'Multiple branches under {t} are unresolved. How should this root be handled?','options':['refresh_root_before_stacking','create_clean_integration_base','do_not_refresh_root','leave_affected_branches_triage'],'recommended_option':'create_clean_integration_base','affected_branches':affected})
    out={'run_id':rid,'roots':roots}; write_artifact('root_health.json',out,rid); write_artifact('root_refresh_questions.json',qs,rid); return out
