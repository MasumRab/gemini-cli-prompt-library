from __future__ import annotations
from .io import read_json, write_artifact, LATEST_DIR, get_run_id
def validate_replay():
    risk=read_json(LATEST_DIR/'replay_risk.json',{}); failed=[]; st=risk.get('repository_state',{})
    for k in ['active_rebase','active_merge','active_cherry_pick']:
        if st.get(k): failed.append({'id':k.replace('_','-'),'severity':'critical','message':f'{k} detected'})
    if risk.get('conflicts',{}).get('conflicted_files'): failed.append({'id':'conflicted-files','severity':'critical','message':'Conflicted files are present'})
    if risk.get('conflicts',{}).get('conflict_markers_detected'): failed.append({'id':'conflict-markers','severity':'critical','message':'Conflict markers detected'})
    rep={'run_id':get_run_id(),'status':'blocked' if failed else 'pass','failed_checks':failed,'next_actions':['Resolve replay/conflict state and rerun replay_risk'] if failed else []}; write_artifact('validation/replay_validation.json',rep); return rep
def validate_targets():
    tm=read_json(LATEST_DIR/'target_matrix.json',{'branches':{}}); failed=[{'id':'unresolved-target-intent','branch':b,'severity':'high'} for b,m in tm.get('branches',{}).items() if m.get('requires_user_decision')]
    rep={'run_id':get_run_id(),'status':'blocked' if failed else 'pass','failed_checks':failed}; write_artifact('validation/target_validation.json',rep); return rep
def validate_roots():
    rh=read_json(LATEST_DIR/'root_health.json',{'roots':{}}); failed=[{'id':'stale-root-blocker','target_root':r,'severity':'critical'} for r,h in rh.get('roots',{}).items() if h.get('health')=='stale' and not h.get('execution_allowed')]
    rep={'run_id':get_run_id(),'status':'blocked' if failed else 'pass','failed_checks':failed}; write_artifact('validation/root_validation.json',rep); return rep
def validate_stack_order():
    so=read_json(LATEST_DIR/'stack_order.json',{'targets':{}}); failed=[{'id':'blocked-target-has-stack','target_root':r,'severity':'critical'} for r,s in so.get('targets',{}).items() if not s.get('execution_allowed') and s.get('stacks')]
    rep={'run_id':get_run_id(),'status':'blocked' if failed else 'pass','failed_checks':failed}; write_artifact('validation/stack_order_validation.json',rep); return rep
def checklist():
    required=['repo_inventory.json','topology_graph.json','target_matrix.json','root_health.json','replay_risk.json','stack_order.json']; checks=[]
    for f in required:
        ok=(LATEST_DIR/f).exists(); checks.append({'id':'artifact-'+f,'status':'pass' if ok else 'failed','severity':'critical' if not ok else 'low','message':f+' present' if ok else f+' missing'})
    failed=[c for c in checks if c['status']=='failed']; rep={'run_id':get_run_id(),'status':'blocked' if failed else 'pass','summary':{'total':len(checks),'failed':len(failed),'passed':len(checks)-len(failed)},'checks':checks}; write_artifact('checklist_report.json',rep); return rep
def analyze_consistency():
    issues=[]; cmd=read_json(LATEST_DIR/'command_plan.json',{}); risk=read_json(LATEST_DIR/'replay_risk.json',{}); so=read_json(LATEST_DIR/'stack_order.json',{})
    if cmd.get('commands') and risk.get('summary',{}).get('overall_risk')=='high': issues.append({'id':'replay-risk-command-plan-conflict','severity':'critical','message':'High replay risk but command plan contains commands'})
    for r,s in so.get('targets',{}).items():
        if not s.get('execution_allowed') and s.get('stacks'): issues.append({'id':'stale-root-stack-conflict','severity':'critical','message':f'{r} blocked but has stacks'})
    rep={'run_id':get_run_id(),'status':'blocked' if any(i['severity']=='critical' for i in issues) else 'pass','issues':issues,'summary':{'critical':sum(1 for i in issues if i['severity']=='critical')}}; write_artifact('analysis_report.json',rep); return rep
