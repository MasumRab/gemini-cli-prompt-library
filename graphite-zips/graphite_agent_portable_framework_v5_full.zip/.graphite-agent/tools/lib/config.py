from __future__ import annotations
from pathlib import Path
import json, fnmatch
DEFAULT_CONFIG={
 'repo':{'name':'auto','mode':'local_only'},
 'analysis':{'include_remote_branches':True,'include_local_branches':True,'include_pr_metadata':'auto','max_branches':250},
 'roots':{'configured':[],'discover':True},
 'generated_files':{'patterns':['dist/**','build/**','*.generated.*','*.lock'],'treat_as_replay_risk':True},
 'ignore_paths':['.git/**','.venv/**','node_modules/**'],
 'replay':{'large_commit_file_threshold':20,'large_commit_line_threshold':800,'simulate':False,'max_commits_per_branch':50},
 'execution':{'default_mode':'analyzer_only','require_explicit_approval':True}
}
def _merge(a,b):
    o=dict(a)
    for k,v in (b or {}).items(): o[k]=_merge(o[k],v) if isinstance(v,dict) and isinstance(o.get(k),dict) else v
    return o
def _load(path):
    txt=Path(path).read_text(encoding='utf-8')
    try:
        import yaml
        return yaml.safe_load(txt) or {}
    except Exception:
        try: return json.loads(txt)
        except Exception: return {}
def load_config(path=None):
    cfg=dict(DEFAULT_CONFIG); p=Path(path) if path else Path('.graphite-agent/config/repo.yaml')
    if p.exists(): cfg=_merge(cfg,_load(p))
    return cfg
def is_ignored(path,cfg=None):
    cfg=cfg or load_config(); return any(fnmatch.fnmatch(path,pat) for pat in cfg.get('ignore_paths',[]))
def is_generated(path,cfg=None):
    cfg=cfg or load_config(); return any(fnmatch.fnmatch(path,pat) for pat in cfg.get('generated_files',{}).get('patterns',[]))
