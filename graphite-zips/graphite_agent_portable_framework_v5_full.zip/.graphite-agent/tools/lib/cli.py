from __future__ import annotations
import argparse, json
from . import inventory, topology, relationships, targets, roots, replay, hunks, stack_ordering, validation, recommendations, command_plan, reports

def build_parser():
    p=argparse.ArgumentParser(prog='graphite_agent.py')
    p.add_argument('--config'); p.add_argument('--run-id'); p.add_argument('--new-run',action='store_true'); p.add_argument('--local-only',action='store_true'); p.add_argument('--json',action='store_true'); p.add_argument('--dry-run',action='store_true'); p.add_argument('--verbose',action='store_true')
    sub=p.add_subparsers(dest='cmd',required=True)
    for c in ['discover','topology','relationships','targets','roots','replay-risk','decompose','stack-order','checklist','analyze','recommend','command-plan','report','converge','all']:
        sp=sub.add_parser(c); sp.add_argument('--branch'); sp.add_argument('--parent')
    return p
def main(argv=None):
    a=build_parser().parse_args(argv); out=None
    if a.cmd=='discover': out=inventory.discover(local_only=True,new_run=a.new_run or True,config_path=a.config)
    elif a.cmd=='topology': out=topology.build()
    elif a.cmd=='relationships': out=relationships.build()
    elif a.cmd=='targets': targets.discover_targets(); out=targets.analyse_targets()
    elif a.cmd=='roots': out=roots.analyse_roots()
    elif a.cmd=='replay-risk': out=replay.assess(branch=a.branch,proposed_parent=a.parent)
    elif a.cmd=='decompose': out=hunks.decompose(branch=a.branch)
    elif a.cmd=='stack-order': out=stack_ordering.build()
    elif a.cmd=='checklist': out=validation.checklist()
    elif a.cmd=='analyze': out=validation.analyze_consistency()
    elif a.cmd=='recommend': recommendations.questions(); recommendations.recommendations(); recommendations.todos(); out={'briefing':recommendations.briefing()}
    elif a.cmd=='command-plan': out=command_plan.build(dry_run=True)
    elif a.cmd=='report': out={'report':reports.write_report()}
    elif a.cmd=='converge': out=recommendations.converge()
    elif a.cmd=='all':
        inventory.discover(local_only=True,new_run=True,config_path=a.config); topology.build(); relationships.build(); targets.discover_targets(); targets.analyse_targets(); roots.analyse_roots(); replay.assess(); hunks.decompose(); stack_ordering.build(); validation.validate_replay(); validation.validate_targets(); validation.validate_roots(); validation.validate_stack_order(); validation.checklist(); validation.analyze_consistency(); recommendations.questions(); recommendations.recommendations(); recommendations.todos(); recommendations.briefing(); command_plan.build(True); reports.write_report(); out=recommendations.converge()
    print(json.dumps(out,indent=2) if not isinstance(out,str) else out)
