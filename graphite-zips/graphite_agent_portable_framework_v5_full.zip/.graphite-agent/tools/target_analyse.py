#!/usr/bin/env python3
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent))
import json
from lib.targets import analyse_targets
out=analyse_targets()
print(out if isinstance(out,str) else json.dumps(out,indent=2))
