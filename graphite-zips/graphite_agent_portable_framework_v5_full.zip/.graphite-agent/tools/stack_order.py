#!/usr/bin/env python3
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent))
import json
from lib.stack_ordering import build
out=build()
print(out if isinstance(out,str) else json.dumps(out,indent=2))
