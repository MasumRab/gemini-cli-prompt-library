#!/usr/bin/env python3
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent))
import argparse,json
from lib.io import read_json, LATEST_DIR
p=argparse.ArgumentParser(); p.add_argument('--branch'); a=p.parse_args(); recs=read_json(LATEST_DIR/'recommendation_options.json',{'recommendations':[]})
for rec in recs.get('recommendations',[]):
    if a.branch and rec.get('branch')!=a.branch: continue
    print(f"# Options for `{rec.get('branch')}`\n")
    for opt in rec.get('options',[]):
        print(f"## {opt['id']}: {opt['label']}\nRisk: {opt['risk']}\n")
        for t in opt.get('todos',[]): print(f"- {t}")
