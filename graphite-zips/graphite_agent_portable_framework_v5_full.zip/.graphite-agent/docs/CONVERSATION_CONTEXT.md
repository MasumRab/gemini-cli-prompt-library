# Conversation Context

V5 implements the discussed portable graphite-agent framework: repo-neutral config, run-scoped artifacts, topology/target/root/stack/replay/hunk analysis, Spec Kit-style checklist/analyze/recommend/converge workflow, and safe execution boundary. If existing code differs, preserve it under backups and adapt via config/hooks rather than hardcoding assumptions.
