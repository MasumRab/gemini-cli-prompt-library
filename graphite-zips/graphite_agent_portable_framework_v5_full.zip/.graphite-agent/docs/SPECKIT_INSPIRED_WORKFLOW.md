# Spec Kit-Inspired Workflow

Graphite-agent adapts Spec Kit's artifact-first quality-gate style: discover -> analyze -> checklist -> recommend -> todos -> converge -> dry-run command plan -> approval boundary.
