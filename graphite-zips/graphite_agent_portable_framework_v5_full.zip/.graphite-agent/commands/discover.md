# Discover

Generated V5 documentation for discover. Follow artifact-first workflow and validators before execution.
