import os, subprocess, tempfile, shutil, unittest, importlib.util, sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def load(rel,name):
    spec=importlib.util.spec_from_file_location(name,ROOT/rel); mod=importlib.util.module_from_spec(spec); sys.modules[name]=mod; spec.loader.exec_module(mod); return mod
class V5Tests(unittest.TestCase):
    def test_config_defaults(self):
        cfg=load('tools/lib/config.py','cfg').load_config('/nope.yaml')
        self.assertEqual(cfg['execution']['default_mode'],'analyzer_only')
    def test_syntax_marker(self):
        self.assertTrue((ROOT/'tools/graphite_agent.py').exists())
    @unittest.skipIf(shutil.which('git') is None, 'git executable not available in test environment')
    def test_temp_git_minimal_flow(self):
        with tempfile.TemporaryDirectory() as td:
            repo=Path(td); subprocess.run(['git','init'],cwd=repo,check=True,stdout=subprocess.DEVNULL); subprocess.run(['git','config','user.email','a@b.c'],cwd=repo,check=True); subprocess.run(['git','config','user.name','t'],cwd=repo,check=True)
            shutil.copytree(ROOT, repo/'.graphite-agent')
            (repo/'a.txt').write_text('a\n'); subprocess.run(['git','add','a.txt'],cwd=repo,check=True); subprocess.run(['git','commit','-m','init'],cwd=repo,check=True,stdout=subprocess.DEVNULL)
            subprocess.run(['python','.graphite-agent/tools/graphite_agent.py','all','--local-only'],cwd=repo,check=False,stdout=subprocess.DEVNULL)
            self.assertTrue((repo/'.graphite-agent/outputs/latest/repo_inventory.json').exists())
            self.assertTrue((repo/'.graphite-agent/outputs/latest/command_plan.json').exists())
if __name__=='__main__': unittest.main()
