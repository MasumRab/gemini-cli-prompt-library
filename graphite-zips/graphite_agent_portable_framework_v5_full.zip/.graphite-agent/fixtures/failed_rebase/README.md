Failed rebase fixture: use conflicted status patterns to validate high replay-risk behavior.
