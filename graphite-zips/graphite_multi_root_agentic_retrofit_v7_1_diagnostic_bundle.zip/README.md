# Graphite Multi-Root Agentic Retrofit V7.1 Diagnostic Bundle

## Syntax check
`python -m py_compile .graphite-agent/tools/*.py .graphite-agent/*.py`

## Tests
`python .graphite-agent/tests/run_tests.py`

## With existing V6.4 outputs
`python .graphite-agent/tools/analyse.py`

## With local V6.4 analyser
`python .graphite-agent/tools/analyse.py --legacy-analyser .graphite-agent/1_analyze_and_plan_v64.py`

## Command loop
`checklist.py -> query.py/explain.py/questions.py -> decide.py/revise_decision.py/revoke_decision.py -> rebuild_plan.py -> validate_plan.py -> execute_approved.py`
