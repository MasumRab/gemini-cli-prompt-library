#!/usr/bin/env python3
import argparse, json, subprocess
from pathlib import Path
from agent_core import run_diagnostics
p=argparse.ArgumentParser(); p.add_argument('--legacy-analyser'); a=p.parse_args()
if a.legacy_analyser:
    legacy=Path(a.legacy_analyser)
    if not legacy.exists(): raise SystemExit(f'Legacy analyser not found: {legacy}')
    subprocess.run(f'python {legacy}', shell=True, check=True)
print(json.dumps(run_diagnostics(write=True)['summary'], indent=2))
