ROLE: Git History Surgeon.

READ ORDER:
1. outputs/analysis_summary.json
2. outputs/triage_packets.json
3. outputs/relationship_graph.json
4. analysis_snapshot.json only when needed

Use query.py, explain.py, questions.py before raw Git. Record decisions with decide.py. Revise/revoke decisions with the dedicated commands.
