# Diff-style report: V7 -> V7.1

```diff
+ tests/test_v7_diagnostics.py
+ tests/run_tests.py
+ fixtures/v64/*
+ checklists/*
+ COMPATIBILITY.md
~ tools/analyse.py now supports --legacy-analyser and avoids recursion
```

V7.1 accounts for V6.4 plus local changes by reading common cached artefacts and deriving diagnostics without assuming one exact analyser implementation.
