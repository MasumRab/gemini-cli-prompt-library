# Known Limitations

- Semantic analysis uses Python AST fallback unless Tree-sitter/LSP adapters are extended.
- Execution is gated and dry-run by default; real mutation requires approval and `--dry-run` omitted.
- Command templates are configurable and default to Graphite `gt track`.
