from __future__ import annotations
from .ast_extractors import extract_symbols
class TreeSitterAdapter:
    def parse_file(self,path): return extract_symbols(path)
    def available(self):
        try: import tree_sitter; return {'tree_sitter': True}
        except Exception: return {'tree_sitter': False, 'fallback':'python_ast'}
