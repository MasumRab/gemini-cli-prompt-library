from __future__ import annotations
from .io import read_json, artifact, LATEST, get_run_id
from .trajectory import TrajectoryAnalyzer

def validate_replay():
    r=read_json(LATEST/'replay_risk.json',{}); failed=[]
    if r.get('summary',{}).get('overall_risk')=='high': failed.append({'id':'high-replay-risk','severity':'critical'})
    return artifact('validation/replay_validation.json',{'run_id':get_run_id(),'status':'blocked' if failed else 'pass','failed_checks':failed})

def validate_roots():
    rh=read_json(LATEST/'root_health.json',{'roots':{}}); topo=read_json(LATEST/'topology_graph.json',{}); replay=read_json(LATEST/'replay_risk.json',{})
    failed=TrajectoryAnalyzer().stale_roots(rh, topo, replay)
    return artifact('validation/root_validation.json',{'run_id':get_run_id(),'status':'blocked' if failed else 'pass','failed_checks':failed})

def validate_targets():
    tm=read_json(LATEST/'target_matrix.json',{'branches':{}}); failed=[{'id':'unresolved-target-intent','branch':b,'severity':'high'} for b,m in tm.get('branches',{}).items() if m.get('requires_user_decision')]
    return artifact('validation/target_validation.json',{'run_id':get_run_id(),'status':'blocked' if failed else 'pass','failed_checks':failed})

def validate_semantics():
    qs=read_json(LATEST/'semantic_questions.json',{'questions':[]}); failed=[]
    if qs.get('questions'): failed.append({'id':'semantic-questions-open','severity':'high','count':len(qs['questions'])})
    return artifact('validation/semantic_validation.json',{'run_id':get_run_id(),'status':'blocked' if failed else 'pass','failed_checks':failed})

def validate_all():
    reps=[validate_replay(), validate_targets(), validate_roots(), validate_semantics()]
    failed=[r for r in reps if r['status']=='blocked']
    return artifact('validation/all_validation.json',{'run_id':get_run_id(),'status':'blocked' if failed else 'pass','reports':reps})
