from __future__ import annotations
import ast
from pathlib import Path

def extract_symbols(path):
    if not str(path).endswith('.py'): return {'path':str(path),'language':'unknown','parse_status':'unsupported','symbols':[]}
    try: text=Path(path).read_text(encoding='utf-8'); tree=ast.parse(text)
    except Exception as exc: return {'path':str(path),'language':'python','parse_status':'error','error':str(exc),'symbols':[]}
    syms=[]; parents=[]
    class V(ast.NodeVisitor):
        def visit_ClassDef(self,node):
            name='.'.join(parents+[node.name]); syms.append({'id':f'sym:{path}:{name}','name':name,'kind':'class','file':str(path),'range':{'start_line':node.lineno,'end_line':getattr(node,'end_lineno',node.lineno)},'signature':node.name}); parents.append(node.name); self.generic_visit(node); parents.pop()
        def visit_FunctionDef(self,node):
            args=[a.arg for a in node.args.args]; name='.'.join(parents+[node.name]); kind='method' if parents else ('test' if node.name.startswith('test_') else 'function'); syms.append({'id':f'sym:{path}:{name}','name':name,'kind':kind,'file':str(path),'range':{'start_line':node.lineno,'end_line':getattr(node,'end_lineno',node.lineno)},'signature':f"{node.name}({', '.join(args)})"}); parents.append(node.name); self.generic_visit(node); parents.pop()
    V().visit(tree); return {'path':str(path),'language':'python','parse_status':'ok','symbols':syms}
