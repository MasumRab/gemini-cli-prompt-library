from __future__ import annotations
from .git_core import GitCore

class TrajectoryAnalyzer:
    def __init__(self, git: GitCore | None = None): self.git = git or GitCore()
    def root_candidates(self, configured=None):
        roots=set(configured or [])
        oh=self.git.origin_head()
        if oh: roots.add(oh)
        for b in self.git.local_branches()+self.git.remote_branches():
            name=b.split('/',1)[1] if '/' in b else b
            if name in {'main','master','develop','dev','trunk'}: roots.add(name)
        return sorted(roots)
    def branch_root_edges(self, roots):
        edges=[]; i=0
        for b in self.git.local_branches():
            parent=None; evidence=[]
            for r in roots:
                ref=r if self.git.head(r) else 'origin/'+r
                if self.git.head(ref) and self.git.is_ancestor(ref,b):
                    parent=r; evidence.append(f'{r} is ancestor of {b}'); break
            i+=1
            edges.append({'id':f'edge-{i:06d}','from':parent,'to':b,'edge_type':'nearest_root_ancestor' if parent else 'unrooted','classification':'executable_candidate' if parent else 'triage_only','evidence':evidence or ['no root ancestor found']})
        return edges
    def stale_roots(self, root_health, topology, replay):
        stale=[]
        if replay.get('repository_state',{}).get('active_rebase'):
            stale.append({'id':'active-rebase','severity':'critical','evidence':['active rebase blocks stale-root confidence']})
        for root, health in root_health.get('roots',{}).items():
            if health.get('health')=='stale' and not health.get('execution_allowed'):
                stale.append({'id':'stale-root-blocker','target_root':root,'severity':'critical','evidence':health.get('evidence',[]) or ['root_health reports stale and blocked']})
        return stale
