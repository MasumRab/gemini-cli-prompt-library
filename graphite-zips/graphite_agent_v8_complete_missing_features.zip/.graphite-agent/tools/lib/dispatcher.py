from __future__ import annotations
import argparse, json
from .analysis import discover_repo, analyse
from .projection import rebuild_execution_plan
from .replay import replay_risk
from .validation import validate_all, validate_replay, validate_targets, validate_roots, validate_semantics
from .semantic import semantic_inventory, ast_index, symbol_graph, reference_graph, semantic_conflicts, semantic_questions, semantic_recommendations
from .command_plan import build_command_plan
from .execution import ExecutionEngine
from .io import artifact, read_json, LATEST, get_run_id, text_artifact
from .task_tracker import export_todos

STAGES = {
  'discover': {'description':'Discover repository state','prerequisites':[],'gate':None},
  'analyse': {'description':'Analyze topology/targets/roots','prerequisites':['repo_inventory.json'],'gate':'replay_clean_or_reported'},
  'semantic': {'description':'Build semantic inventory and questions','prerequisites':['analysis_snapshot.json'],'gate':'semantic_enabled'},
  'project': {'description':'Project decisions to execution plan','prerequisites':['analysis_snapshot.json'],'gate':'decisions_projectable'},
  'validate': {'description':'Run validation gates','prerequisites':['execution_plan.json'],'gate':'all_validations'},
  'plan': {'description':'Build dry-run command plan','prerequisites':['execution_plan.json'],'gate':'validation_pass'},
  'execute': {'description':'Execute approved commands','prerequisites':['command_plan.json'],'gate':'user_approval_required'}
}

def semantic_stage():
    semantic_inventory(); ast_index(); symbol_graph(); reference_graph(); semantic_conflicts(); semantic_questions(); semantic_recommendations(); return validate_semantics()

def recommend():
    sem=read_json(LATEST/'semantic_questions.json',{'questions':[]}); todos=[{'id':f'todo-sem-{i+1:06d}','status':'open','priority':'high','description':'Resolve semantic question '+q['id'],'question_ref':q['id']} for i,q in enumerate(sem.get('questions',[]))]
    return artifact('agent_todos.json',{'run_id':get_run_id(),'todos':todos})

def report():
    plan=read_json(LATEST/'command_plan.json',{}); sem=read_json(LATEST/'semantic_questions.json',{'questions':[]})
    return text_artifact('branch_stacking_report.md','# Branch Stacking Report\n\nCommands: '+str(len(plan.get('commands',[])))+'\nSemantic questions: '+str(len(sem.get('questions',[])))+'\n',report=True)

def all_stage():
    discover_repo(); replay_risk(); analyse(); semantic_stage(); rebuild_execution_plan(); validate_all(); build_command_plan(); recommend(); report(); return read_json(LATEST/'command_plan.json',{})

def main(argv=None):
    p=argparse.ArgumentParser(); p.add_argument('--dry-run',action='store_true'); p.add_argument('--backend',default='internal')
    sub=p.add_subparsers(dest='cmd',required=True)
    for c in ['discover','analyse','replay-risk','semantic','project','validate','validate-roots','validate-replay','validate-targets','validate-semantics','plan','execute','export-todos','all']: sub.add_parser(c)
    a=p.parse_args(argv)
    mapping={'discover':discover_repo,'analyse':analyse,'replay-risk':replay_risk,'semantic':semantic_stage,'project':rebuild_execution_plan,'validate':validate_all,'validate-roots':validate_roots,'validate-replay':validate_replay,'validate-targets':validate_targets,'validate-semantics':validate_semantics,'plan':build_command_plan,'execute':lambda: ExecutionEngine().execute(dry_run=a.dry_run),'export-todos':lambda: export_todos(a.backend,a.dry_run),'all':all_stage}
    out=mapping[a.cmd](); print(json.dumps(out,indent=2) if not isinstance(out,str) else out)
