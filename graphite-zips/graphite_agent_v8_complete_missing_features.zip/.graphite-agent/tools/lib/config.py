from __future__ import annotations
from pathlib import Path
import json, fnmatch

DEFAULT_CONFIG = {
  'roots': {'configured': [], 'discover': True},
  'generated_files': {'patterns': ['dist/**','build/**','generated/**','*.generated.*','*.lock']},
  'ignore_paths': ['.git/**','.venv/**','node_modules/**','.graphite-agent/outputs/**'],
  'execution': {
    'default_mode': 'analyzer_only',
    'require_explicit_approval': True,
    'graphite': {
      'track_template': 'gt track {branch} --parent {parent}',
      'restack_template': 'gt restack {branch}',
      'submit_template': 'gt submit {branch}'
    }
  },
  'semantics': {'enabled': True, 'max_files_per_run': 1000},
  'task_tracking': {'backend': 'internal', 'beads': {'enabled': False, 'command': 'bd'}}
}

def _merge(a,b):
    out = dict(a)
    for k,v in (b or {}).items():
        out[k] = _merge(out[k], v) if isinstance(v,dict) and isinstance(out.get(k),dict) else v
    return out

def _load(path: Path) -> dict:
    text = path.read_text(encoding='utf-8')
    try:
        import yaml
        return yaml.safe_load(text) or {}
    except Exception:
        try: return json.loads(text)
        except Exception: return {}

def load_config(path: str | Path | None = None) -> dict:
    cfg = dict(DEFAULT_CONFIG)
    p = Path(path) if path else Path('.graphite-agent/config/repo.yaml')
    if p.exists(): cfg = _merge(cfg, _load(p))
    return cfg

def matches(path, patterns): return any(fnmatch.fnmatch(path, pat) for pat in patterns)
def is_generated(path, cfg=None): cfg=cfg or load_config(); return matches(path, cfg.get('generated_files',{}).get('patterns',[]))
def is_ignored(path, cfg=None): cfg=cfg or load_config(); return matches(path, cfg.get('ignore_paths',[]))
