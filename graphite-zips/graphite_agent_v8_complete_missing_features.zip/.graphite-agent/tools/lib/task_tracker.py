from __future__ import annotations
from .io import read_json, artifact, LATEST, get_run_id

def export_todos(backend='internal', dry_run=True):
    todos=read_json(LATEST/'agent_todos.json',{'todos':[]})
    return artifact('task_export_plan.json',{'run_id':get_run_id(),'backend':backend,'dry_run':dry_run,'items':todos.get('todos',[])})
