from __future__ import annotations
from .git_core import GitCore
from .io import artifact, get_run_id

def replay_risk():
    g=GitCore(); st=g.active_state(); conf=g.conflicted_files(); high=any(st.values()) or bool(conf)
    return artifact('replay_risk.json',{'run_id':get_run_id(),'branch':g.current_branch(),'summary':{'overall_risk':'high' if high else 'low','execution_allowed':not high,'primary_reason':'active replay/conflict state detected' if high else 'no immediate replay blockers detected'},'repository_state':{**st,'dirty_worktree':bool(g.status_lines())},'conflicts':{'conflicted_files':conf,'conflict_markers_detected':[]}})
