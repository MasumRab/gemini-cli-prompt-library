from __future__ import annotations
from .io import read_json, artifact, LATEST, get_run_id
from .config import load_config

def build_command_plan():
    validation=read_json(LATEST/'validation/all_validation.json',{})
    execution=read_json(LATEST/'execution_plan.json', read_json('.graphite-agent/outputs/execution_plan.json', {'execution_queue':[]}))
    blocked = validation.get('status')=='blocked'
    commands=[]; cfg=load_config(); tmpl=cfg['execution']['graphite']['track_template']
    if not blocked:
        for item in execution.get('execution_queue',[]):
            cmd=tmpl.format(branch=item['branch'], parent=item['parent'])
            commands.append({'type':'graphite_track','branch':item['branch'],'parent':item['parent'],'command':cmd,'requires_approval':True,'blocked_by':[]})
    return artifact('command_plan.json',{'run_id':get_run_id(),'mode':'dry_run','execution_allowed':False,'blocked_by':['validation'] if blocked else [],'commands':commands})
