from __future__ import annotations
import os, subprocess
from .io import read_json, artifact, LATEST, get_run_id
from .validation import validate_all

class ExecutionEngine:
    def __init__(self): self.command_log=[]
    def execute(self, dry_run=True):
        validation=validate_all()
        plan=read_json(LATEST/'command_plan.json',{'commands':[]})
        if validation['status']=='blocked':
            return artifact('execution_result.json',{'run_id':get_run_id(),'status':'blocked','reason':'validation failed','validation':validation})
        if os.environ.get('GRAPHITE_AGENT_APPROVED')!='1':
            return artifact('execution_result.json',{'run_id':get_run_id(),'status':'blocked','reason':'GRAPHITE_AGENT_APPROVED=1 required'})
        results=[]
        for cmd in plan.get('commands',[]):
            if dry_run:
                results.append({'command':cmd['command'],'status':'dry_run'})
            else:
                p=subprocess.run(cmd['command'], shell=True, capture_output=True, text=True)
                results.append({'command':cmd['command'],'returncode':p.returncode,'stdout':p.stdout,'stderr':p.stderr})
                if p.returncode: break
        status='pass' if all(r.get('returncode',0)==0 for r in results) else 'failed'
        return artifact('execution_result.json',{'run_id':get_run_id(),'status':status,'results':results})
