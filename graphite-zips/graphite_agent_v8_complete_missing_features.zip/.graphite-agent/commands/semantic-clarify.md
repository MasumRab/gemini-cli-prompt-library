# Semantic Clarify

Run semantic stage and resolve bounded questions before command planning.
