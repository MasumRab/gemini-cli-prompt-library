# V8 Constitution

Analyzer-first. Semantic clarify before planning. No execution without approval.
