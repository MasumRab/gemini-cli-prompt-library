import ast, pathlib, tempfile, sys, unittest
ROOT=pathlib.Path(__file__).resolve().parents[1]
class V8CompleteTests(unittest.TestCase):
    def test_syntax_all_python(self):
        paths=list((ROOT/'tools').glob('*.py'))+list((ROOT/'tools/lib').glob('*.py'))+[ROOT/'main.py']
        for p in paths: ast.parse(p.read_text(), filename=str(p))
    def test_projection_logic_imports(self):
        sys.path.insert(0,str(ROOT/'tools'))
        from lib.ast_extractors import extract_symbols
        with tempfile.TemporaryDirectory() as td:
            p=pathlib.Path(td)/'x.py'; p.write_text('class A:\n    def m(self,x):\n        return x\n')
            names=[s['name'] for s in extract_symbols(str(p))['symbols']]
            self.assertIn('A', names); self.assertIn('A.m', names)
if __name__=='__main__': unittest.main()
