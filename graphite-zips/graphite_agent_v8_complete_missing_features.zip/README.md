# Graphite Agent V8 Complete Missing Features Build

Copy `.graphite-agent` into a Git repo and run:

```bash
python .graphite-agent/main.py all
```
