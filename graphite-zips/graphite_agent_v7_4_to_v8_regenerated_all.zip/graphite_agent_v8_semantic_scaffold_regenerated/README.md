# graphite_agent_v8_semantic_scaffold_regenerated

Run: `python .graphite-agent/tools/graphite_agent.py all --local-only`
