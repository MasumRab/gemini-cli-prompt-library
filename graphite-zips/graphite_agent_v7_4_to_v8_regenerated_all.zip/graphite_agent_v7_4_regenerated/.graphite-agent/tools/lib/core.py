#!/usr/bin/env python3
import argparse, json, subprocess
from pathlib import Path
from datetime import datetime, timezone
AGENT_DIR=Path('.graphite-agent'); OUT=AGENT_DIR/'outputs'; RUNS=OUT/'runs'; LATEST=OUT/'latest'; REPORTS=AGENT_DIR/'reports'
def ensure():
    for p in [OUT,RUNS,LATEST,REPORTS]: p.mkdir(parents=True,exist_ok=True)
def rid(new=False):
    ensure(); f=OUT/'current_run.txt'
    if f.exists() and not new: return f.read_text().strip()
    r=datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ'); f.write_text(r); return r
def wj(name,data):
    r=rid(); p=RUNS/r/name; p.parent.mkdir(parents=True,exist_ok=True); p.write_text(json.dumps(data,indent=2,sort_keys=True)); q=LATEST/name; q.parent.mkdir(parents=True,exist_ok=True); q.write_text(json.dumps(data,indent=2,sort_keys=True)); return data
def rt(name,txt):
    r=rid(); p=RUNS/r/name; p.parent.mkdir(parents=True,exist_ok=True); p.write_text(txt); q=LATEST/name; q.parent.mkdir(parents=True,exist_ok=True); q.write_text(txt); (REPORTS/Path(name).name).write_text(txt); return txt
def gj(args):
    p=subprocess.run(['git']+args,capture_output=True,text=True); return p.returncode,p.stdout.strip(),p.stderr.strip()
def root():
    c,o,_=gj(['rev-parse','--show-toplevel']); return o if c==0 else None
def branch():
    c,o,_=gj(['branch','--show-current']); return o if c==0 else None
def status():
    c,o,_=gj(['status','--porcelain=v1','-uall']); return o.splitlines() if c==0 and o else []
def branches():
    c,o,_=gj(['for-each-ref','refs/heads','--format=%(refname:short)']); return o.splitlines() if c==0 and o else []
def remotes():
    c,o,_=gj(['for-each-ref','refs/remotes','--format=%(refname:short)']); return [x for x in o.splitlines() if not x.endswith('/HEAD')] if c==0 and o else []
def active():
    g=Path(root() or '.')/'.git'; return {'active_rebase':(g/'rebase-merge').exists() or (g/'rebase-apply').exists(),'active_merge':(g/'MERGE_HEAD').exists(),'active_cherry_pick':(g/'CHERRY_PICK_HEAD').exists()}
def conflicts():
    m={'UU':'both_modified','DU':'delete_modify','UD':'delete_modify','AA':'both_added'}; return [{'path':l[3:],'status':l[:2],'conflict_type':m[l[:2]]} for l in status() if len(l)>=4 and l[:2] in m]
def discover(a=None):
    if not root(): raise SystemExit('Not inside a Git repository')
    return wj('repo_inventory.json',{'run_id':rid(),'repo':{'git_root':root(),'current_branch':branch(),'is_dirty':bool(status())},'state':{**active(),'conflicted_files':conflicts(),'status_porcelain':status()},'branches':{'local':branches(),'remote':remotes()},'targets':{'configured':[],'origin_head':None,'discovered':[]},'pr_metadata':{'available':False,'reason':'local_only_or_no_adapter'}})
def topology(a=None):
    inv=json.loads((LATEST/'repo_inventory.json').read_text()); bs=inv['branches']['local']; nodes={b:{'type':'branch'} for b in bs}; edges=[{'id':f'edge-{i:06d}','from':None,'to':b,'edge_type':'unrooted','classification':'triage_only'} for i,b in enumerate(bs,1)]; return wj('topology_graph.json',{'run_id':rid(),'nodes':nodes,'edges':edges})
def targets(a=None):
    topo=json.loads((LATEST/'topology_graph.json').read_text()); qs=[]; mat={}
    for e in topo['edges']:
        b=e['to']; q=f'q-target-{len(qs)+1:06d}'; qs.append({'id':q,'branch':b,'question_type':'target_intent','options':['leave_triage','exclude_from_migration']}); mat[b]={'requires_user_decision':True,'question_refs':[q]}
    wj('target_candidates.json',{'run_id':rid(),'candidates':{}}); wj('target_questions.json',qs); return wj('target_matrix.json',{'run_id':rid(),'branches':mat})
def roots(a=None): return wj('root_health.json',{'run_id':rid(),'roots':{}})
def replay(a=None):
    high=any(active().values()) or bool(conflicts()); return wj('replay_risk.json',{'run_id':rid(),'branch':branch(),'summary':{'overall_risk':'high' if high else 'low','execution_allowed':not high},'repository_state':{**active(),'dirty_worktree':bool(status())},'conflicts':{'conflicted_files':conflicts(),'conflict_markers_detected':[]}})
def stack(a=None): return wj('stack_order.json',{'run_id':rid(),'targets':{}})
def validate(kind):
    failed=[]
    if kind=='replay':
        r=json.loads((LATEST/'replay_risk.json').read_text())
        if r['summary']['overall_risk']=='high': failed.append({'id':'high-replay-risk','severity':'critical'})
    if kind=='targets':
        t=json.loads((LATEST/'target_matrix.json').read_text())
        failed=[{'id':'unresolved-target-intent','branch':b} for b,m in t['branches'].items() if m.get('requires_user_decision')]
    return wj(f'validation/{kind}_validation.json',{'run_id':rid(),'status':'blocked' if failed else 'pass','failed_checks':failed})
def recommend(a=None):
    todos=[{'id':'todo-000001','status':'open','priority':'high','description':'Review generated target/replay blockers and rerun validators'}]; wj('agent_todos.json',{'run_id':rid(),'todos':todos}); wj('recommendation_options.json',{'run_id':rid(),'recommendations':[]}); return wj('agent_work_package.json',{'run_id':rid(),'status':'blocked','todos':'agent_todos.json'})
def plan(a=None): return wj('command_plan.json',{'run_id':rid(),'mode':'dry_run','execution_allowed':False,'blocked_by':['validator'],'commands':[]})
def report(a=None): return rt('branch_stacking_report.md','# Branch Stacking Report\n\nAnalyzer-first regenerated package.\n')
def converge(a=None): return wj('convergence_report.json',{'run_id':rid(),'converged':False,'status':'blocked'})
def all(a=None):
    discover(a); topology(a); targets(a); roots(a); replay(a); stack(a); validate('replay'); validate('targets'); recommend(a); plan(a); report(a); return converge(a)
def main(argv=None):
    p=argparse.ArgumentParser(); p.add_argument('--local-only',action='store_true'); p.add_argument('--new-run',action='store_true'); s=p.add_subparsers(dest='cmd',required=True)
    for c in ['discover','topology','targets','roots','replay-risk','stack-order','validate-replay','validate-targets','recommend','command-plan','report','converge','all']: s.add_parser(c)
    a=p.parse_args(argv); d={'discover':discover,'topology':topology,'targets':targets,'roots':roots,'replay-risk':replay,'stack-order':stack,'recommend':recommend,'command-plan':plan,'report':report,'converge':converge,'all':all}
    out=validate(a.cmd.replace('validate-','')) if a.cmd.startswith('validate-') else d[a.cmd](a); print(json.dumps(out,indent=2) if not isinstance(out,str) else out)
if __name__=='__main__': main()
