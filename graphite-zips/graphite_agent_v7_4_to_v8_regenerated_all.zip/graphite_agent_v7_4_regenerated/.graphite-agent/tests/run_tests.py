#!/usr/bin/env python3
import ast, pathlib
root=pathlib.Path(__file__).resolve().parents[1]
for p in list((root/'tools').glob('*.py'))+list((root/'tools/lib').glob('*.py')): ast.parse(p.read_text(), filename=str(p))
print('OK syntax')
