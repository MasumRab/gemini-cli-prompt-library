# Constitution

Analyzer-first. No mutation without approval.
