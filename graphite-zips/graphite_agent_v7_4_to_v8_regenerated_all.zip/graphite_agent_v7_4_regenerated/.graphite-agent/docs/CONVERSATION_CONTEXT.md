Regenerated package. V7.4 implemented snapshot; V8 semantic scaffold when present.
