discover -> checklist/analyze -> recommend -> converge -> dry-run command plan.
