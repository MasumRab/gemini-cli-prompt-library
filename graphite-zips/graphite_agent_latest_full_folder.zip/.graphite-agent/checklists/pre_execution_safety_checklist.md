# pre_execution_safety_checklist

Artifact-first V5 workflow guidance.
