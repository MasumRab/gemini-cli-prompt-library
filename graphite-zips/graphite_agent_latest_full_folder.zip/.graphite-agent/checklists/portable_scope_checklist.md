# portable_scope_checklist

Artifact-first V5 workflow guidance.
