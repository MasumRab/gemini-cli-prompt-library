# replay_risk_checklist

Artifact-first V5 workflow guidance.
