Workflow: discover -> analyze/checklist -> recommend/todos -> converge -> dry-run command plan -> approved execution boundary.
