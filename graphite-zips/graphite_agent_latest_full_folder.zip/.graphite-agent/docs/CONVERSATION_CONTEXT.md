Latest full implemented folder based on V5 portable graphite-agent framework. V6 semantic Tree-sitter layer is discussed but not included here.
