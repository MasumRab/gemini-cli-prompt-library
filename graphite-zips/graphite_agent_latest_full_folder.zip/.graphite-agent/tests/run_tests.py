#!/usr/bin/env python3
import unittest, pathlib
suite=unittest.defaultTestLoader.discover(str(pathlib.Path(__file__).parent), pattern='test_*.py')
res=unittest.TextTestRunner(verbosity=2).run(suite)
raise SystemExit(0 if res.wasSuccessful() else 1)
