import ast, pathlib, unittest
ROOT=pathlib.Path(__file__).resolve().parents[1]
class Basic(unittest.TestCase):
 def test_core_exists(self): self.assertTrue((ROOT/'tools/lib/core.py').exists())
 def test_py_syntax(self):
  for p in list((ROOT/'tools').glob('*.py'))+list((ROOT/'tools/lib').glob('*.py')): ast.parse(p.read_text(), filename=str(p))
if __name__=='__main__': unittest.main()
