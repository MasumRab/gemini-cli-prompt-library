# complex_non_dag_workflow

Artifact-first V5 workflow guidance.
