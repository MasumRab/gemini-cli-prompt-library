#!/usr/bin/env python3
import json
from pathlib import Path
recs=json.loads(Path('.graphite-agent/outputs/latest/recommendation_options.json').read_text()) if Path('.graphite-agent/outputs/latest/recommendation_options.json').exists() else {'recommendations':[]}
for r in recs.get('recommendations',[]):
 print('# Options for', r.get('branch'))
 for o in r.get('options',[]): print('-', o.get('id'), o.get('label'))
