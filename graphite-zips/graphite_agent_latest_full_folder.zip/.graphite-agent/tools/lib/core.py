#!/usr/bin/env python3
from __future__ import annotations
import argparse, fnmatch, json, os, re, subprocess
from datetime import datetime, timezone
from pathlib import Path

AGENT_DIR=Path('.graphite-agent')
OUT=AGENT_DIR/'outputs'
RUNS=OUT/'runs'
LATEST=OUT/'latest'
REPORTS=AGENT_DIR/'reports'
DECISION_LOG=OUT/'decision_log.jsonl'
DEFAULT_CONFIG={
 'repo':{'mode':'local_only'},
 'roots':{'configured':[],'discover':True},
 'generated_files':{'patterns':['dist/**','build/**','*.generated.*','*.lock']},
 'ignore_paths':['.git/**','.venv/**','node_modules/**'],
 'replay':{'large_commit_file_threshold':20,'large_commit_line_threshold':800},
 'execution':{'default_mode':'analyzer_only','require_explicit_approval':True}
}

def ensure():
    for p in [OUT,RUNS,LATEST,REPORTS]: p.mkdir(parents=True, exist_ok=True)

def now(): return datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')
def run_id(new=False):
    ensure(); f=OUT/'current_run.txt'
    if not new and f.exists(): return f.read_text().strip()
    rid=now(); f.write_text(rid); return rid

def rd(rid=None):
    p=RUNS/(rid or run_id()); (p/'validation').mkdir(parents=True, exist_ok=True); return p

def rj(path, default=None):
    p=Path(path)
    return json.loads(p.read_text()) if p.exists() else default

def wj(path, data):
    p=Path(path); p.parent.mkdir(parents=True, exist_ok=True); p.write_text(json.dumps(data, indent=2, sort_keys=True))

def artifact(name, data, rid=None):
    rid=rid or run_id(); wj(rd(rid)/name, data); wj(LATEST/name, data); return data

def text_artifact(name, text, rid=None, report=False):
    rid=rid or run_id(); p=rd(rid)/name; p.parent.mkdir(parents=True, exist_ok=True); p.write_text(text)
    lp=LATEST/name; lp.parent.mkdir(parents=True, exist_ok=True); lp.write_text(text)
    if report: (REPORTS/Path(name).name).write_text(text)
    return text

def load_config(path=None):
    cfg=json.loads(json.dumps(DEFAULT_CONFIG)); p=Path(path) if path else AGENT_DIR/'config/repo.yaml'
    if p.exists():
        try:
            import yaml; extra=yaml.safe_load(p.read_text()) or {}
        except Exception:
            try: extra=json.loads(p.read_text())
            except Exception: extra={}
        def merge(a,b):
            for k,v in b.items(): a[k]=merge(a.get(k,{}),v) if isinstance(v,dict) and isinstance(a.get(k),dict) else v
            return a
        cfg=merge(cfg, extra)
    return cfg

def sh(cmd, check=False):
    p=subprocess.run(cmd, capture_output=True, text=True)
    if check and p.returncode: raise RuntimeError(p.stderr)
    return p.returncode,p.stdout.strip(),p.stderr.strip()

def git(args): return sh(['git']+args)
def git_root():
    c,o,_=git(['rev-parse','--show-toplevel']); return o if c==0 else None
def current_branch():
    c,o,_=git(['branch','--show-current']); return o if c==0 else None
def status_lines():
    c,o,_=git(['status','--porcelain=v1','-uall']); return o.splitlines() if c==0 and o else []
def local_branches():
    c,o,_=git(['for-each-ref','refs/heads','--format=%(refname:short)']); return o.splitlines() if c==0 and o else []
def remote_branches():
    c,o,_=git(['for-each-ref','refs/remotes','--format=%(refname:short)']); return [x for x in o.splitlines() if not x.endswith('/HEAD')] if c==0 and o else []
def head(ref):
    c,o,_=git(['rev-parse',ref]); return o if c==0 else None
def is_ancestor(a,b): return git(['merge-base','--is-ancestor',a,b])[0]==0
def upstream():
    c,o,_=git(['rev-parse','--abbrev-ref','--symbolic-full-name','@{u}']); return o if c==0 else None
def origin_head():
    c,o,_=git(['symbolic-ref','refs/remotes/origin/HEAD']); return o.rsplit('/',1)[-1] if c==0 and o.startswith('refs/remotes/origin/') else None
def active_state(root=None):
    g=Path(root or git_root() or '.')/'.git'
    return {'active_rebase':(g/'rebase-merge').exists() or (g/'rebase-apply').exists(),'active_merge':(g/'MERGE_HEAD').exists(),'active_cherry_pick':(g/'CHERRY_PICK_HEAD').exists()}
def conflicts():
    m={'UU':'both_modified','DU':'delete_modify','UD':'delete_modify','AA':'both_added','DD':'both_deleted'}; out=[]
    for l in status_lines():
        if len(l)>=4 and l[:2] in m: out.append({'path':l[3:],'status':l[:2],'conflict_type':m[l[:2]]})
    return out

def is_generated(path,cfg): return any(fnmatch.fnmatch(path,p) for p in cfg.get('generated_files',{}).get('patterns',[]))
def is_ignored(path,cfg): return any(fnmatch.fnmatch(path,p) for p in cfg.get('ignore_paths',[]))
def merge_commits(rng):
    c,o,_=git(['rev-list','--merges',rng]); return o.splitlines() if c==0 and o else []
def log_shortstat(rng):
    c,o,_=git(['log','--shortstat','--pretty=format:@@@%H%x1f%s',rng])
    if c!=0 or not o: return []
    res=[]
    for b in o.split('@@@'):
        b=b.strip()
        if not b: continue
        lines=b.splitlines(); h=lines[0].split('\x1f'); res.append({'commit':h[0],'subject':h[1] if len(h)>1 else '', 'shortstat':' '.join(lines[1:])})
    return res

def discover(args=None):
    cfg=load_config(getattr(args,'config',None)); rid=run_id(new=getattr(args,'new_run',False)); root=git_root()
    if not root: raise SystemExit('Not inside a Git repository')
    st=status_lines(); roots=set(cfg.get('roots',{}).get('configured',[]) or []); oh=origin_head()
    if oh: roots.add(oh)
    inv={'run_id':rid,'repo':{'git_root':root,'current_branch':current_branch(),'is_dirty':bool(st)},'state':{**active_state(root),'conflicted_files':conflicts(),'status_porcelain':st},'branches':{'local':local_branches(),'remote':remote_branches()},'targets':{'configured':sorted(cfg.get('roots',{}).get('configured',[]) or []),'origin_head':oh,'discovered':sorted(roots)},'pr_metadata':{'available':False,'reason':'local_only_or_no_adapter','items':[]}}
    return artifact('repo_inventory.json',inv,rid)

def topology(args=None):
    rid=run_id(); inv=rj(LATEST/'repo_inventory.json',{})
    roots=set(inv.get('targets',{}).get('discovered',[]) or []) or {'main'}; branches=inv.get('branches',{}).get('local',[])
    nodes={r:{'type':'root','name':r,'head':head(r) or head('origin/'+r)} for r in roots}; edges=[]; i=0
    for b in branches:
        nodes[b]={'type':'branch','name':b,'head':head(b)}; cands=[]
        for r in roots:
            ref=r if head(r) else 'origin/'+r
            if head(ref) and is_ancestor(ref,b): cands.append(r)
        parent=sorted(cands)[0] if cands else None; i+=1
        edges.append({'id':f'edge-{i:06d}','from':parent,'to':b,'edge_type':'nearest_root_ancestor' if parent else 'unrooted','classification':'executable_candidate' if parent else 'triage_only','confidence':'medium','evidence':[f'{parent} is ancestor of {b}' if parent else 'no discovered root ancestor found']})
    return artifact('topology_graph.json',{'run_id':rid,'roots':sorted(roots),'nodes':nodes,'edges':edges},rid)

def relationships(args=None):
    rid=run_id(); topo=rj(LATEST/'topology_graph.json',{'edges':[]}); rel=[]; i=0
    for e in topo.get('edges',[]):
        i+=1; rel.append({'id':f'rel-{i:06d}',**e})
        if e.get('from') and e.get('to'):
            rng=f"{e['from']}..{e['to']}"; mc=merge_commits(rng)
            if mc:
                i+=1; rel.append({'id':f'rel-{i:06d}','from':e['from'],'to':e['to'],'edge_type':'merge_commits_in_branch_range','classification':'blocked','confidence':'high','evidence':[f'{len(mc)} merge commit(s) in {rng}'],'metadata':{'merge_commits':mc}})
    return artifact('relationship_graph.json',{'run_id':rid,'edges':rel},rid)

def targets(args=None):
    rid=run_id(); inv=rj(LATEST/'repo_inventory.json',{}); cand={r:{'target':r,'score':80,'confidence':'high' if r==inv.get('targets',{}).get('origin_head') else 'medium','signals':['repo inventory']} for r in inv.get('targets',{}).get('discovered',[])}
    artifact('target_candidates.json',{'run_id':rid,'candidates':cand},rid)
    topo=rj(LATEST/'topology_graph.json',{'edges':[]}); branches={}; qs=[]; n=0
    for e in topo.get('edges',[]):
        b=e.get('to'); inferred=e.get('from'); req=inferred is None
        qrefs=[]
        if req:
            n+=1; qid=f'q-target-{n:06d}'; qrefs=[qid]; qs.append({'id':qid,'branch':b,'question_type':'target_intent','question':f'Which target should {b} use?','options':['target='+x for x in cand]+['leave_triage','exclude_from_migration'],'recommended_option':'leave_triage'})
        branches[b]={'declared_target':None,'candidate_targets':[{'target':inferred,'confidence':'medium','evidence':['topology inferred']}] if inferred else [],'confirmed_targets':[],'diagnostic_category':'target_confirmed' if not req else 'target_intent_required','requires_user_decision':req,'question_refs':qrefs}
    artifact('target_questions.json',qs,rid); return artifact('target_matrix.json',{'run_id':rid,'branches':branches},rid)

def roots(args=None):
    rid=run_id(); tm=rj(LATEST/'target_matrix.json',{'branches':{}}); tc=rj(LATEST/'target_candidates.json',{'candidates':{}}); roots={}; qs=[]; i=0
    for t in tc.get('candidates',{}):
        affected=[b for b,m in tm.get('branches',{}).items() if any(c.get('target')==t for c in m.get('candidate_targets',[]))]
        stale=sum(1 for b in affected if tm['branches'][b].get('requires_user_decision'))>=2
        roots[t]={'health':'stale' if stale else 'current','affected_branches':affected,'execution_allowed':not stale,'recommended_action':'root_refresh_decision_required' if stale else 'stack_order_allowed'}
        if stale:
            i+=1; qs.append({'id':f'q-root-{i:06d}','target_root':t,'question_type':'root_refresh_policy','question':f'How should stale root {t} be handled?','options':['refresh_root_before_stacking','create_clean_integration_base','do_not_refresh_root','leave_affected_branches_triage']})
    artifact('root_refresh_questions.json',qs,rid); return artifact('root_health.json',{'run_id':rid,'roots':roots},rid)

def replay(args=None):
    rid=run_id(); cfg=load_config(); inv=rj(LATEST/'repo_inventory.json',{}); branch=getattr(args,'branch',None) or inv.get('repo',{}).get('current_branch') or current_branch(); parent=getattr(args,'parent',None) or upstream() or inv.get('targets',{}).get('origin_head')
    refp=parent if parent and head(parent) else ('origin/'+parent if parent else None); rng=f'{refp}..{branch}' if refp and branch and head(refp) and head(branch) else None
    st=active_state(inv.get('repo',{}).get('git_root')); conf=conflicts(); paths=[l[3:] for l in status_lines() if len(l)>3 and not is_ignored(l[3:],cfg)]
    marks=[]
    for p in paths[:200]:
        pp=Path(p)
        if pp.exists() and pp.is_file():
            try: txt=pp.read_text(errors='ignore')
            except Exception: txt=''
            if '<<<<<<< ' in txt or '=======' in txt or '>>>>>>> ' in txt: marks.append({'path':p,'markers':True})
    large=[]
    if rng:
        for rec in log_shortstat(rng):
            files=int(re.search(r'(\d+) files? changed',rec.get('shortstat','') or '0 files changed').group(1)) if re.search(r'(\d+) files? changed',rec.get('shortstat','')) else 0
            lines=sum(int(m.group(1)) for m in re.finditer(r'(\d+) (insertion|deletion)',rec.get('shortstat','')))
            if files>=cfg['replay']['large_commit_file_threshold'] or lines>=cfg['replay']['large_commit_line_threshold']: large.append({**rec,'files_changed':files,'lines_changed':lines,'risk':'large_mixed_commit'})
    gen=[{'path':p,'recommendation':'regenerate_after_replay'} for p in paths if is_generated(p,cfg)]
    mc=merge_commits(rng) if rng else []
    high=any(st.values()) or bool(conf) or bool(marks)
    return artifact('replay_risk.json',{'run_id':rid,'branch':branch,'proposed_parent':parent,'summary':{'overall_risk':'high' if high else 'medium' if large or gen or mc else 'low','execution_allowed':not high,'primary_reason':'active replay/conflict state detected' if high else 'review recommended' if (large or gen or mc) else 'no immediate replay blockers detected'},'repository_state':{**st,'dirty_worktree':bool(status_lines())},'conflicts':{'conflicted_files':conf,'conflict_markers_detected':marks},'commit_risks':large,'generated_file_risks':gen,'merge_commit_risks':[{'sha':x,'risk':'merge_commit_in_replay_range'} for x in mc]},rid)

def decompose(args=None):
    rid=run_id(); risk=rj(LATEST/'replay_risk.json',{}); items=[]
    for g in risk.get('generated_file_risks',[]): items.append({'file':g['path'],'label':'generated_artifact','recommendation':'regenerate_after_replay'})
    for c in risk.get('conflicts',{}).get('conflicted_files',[]): items.append({'file':c['path'],'label':c.get('conflict_type'),'recommendation':'manual_semantic_decision_required'})
    out={'run_id':rid,'branch':risk.get('branch'),'decomposition':items,'manual_semantic_decisions':[x for x in items if x['recommendation']=='manual_semantic_decision_required']}
    text_artifact('hunk_decomposition.md','# Hunk Decomposition Report\n\n'+'\n'.join(f"- `{i['file']}`: {i['label']} -> {i['recommendation']}" for i in items)+'\n',rid,True)
    return artifact('hunk_decomposition.json',out,rid)

def stack_order(args=None):
    rid=run_id(); topo=rj(LATEST/'topology_graph.json',{'edges':[]}); tm=rj(LATEST/'target_matrix.json',{'branches':{}}); rh=rj(LATEST/'root_health.json',{'roots':{}}); risk=rj(LATEST/'replay_risk.json',{})
    targets={r:{'root_health':h.get('health'),'execution_allowed':h.get('execution_allowed',False),'blocked_reason':None if h.get('execution_allowed') else h.get('recommended_action'),'stacks':[]} for r,h in rh.get('roots',{}).items()}
    for e in topo.get('edges',[]):
        b=e.get('to'); r=e.get('from')
        if r in targets and targets[r]['execution_allowed'] and not tm.get('branches',{}).get(b,{}).get('requires_user_decision') and not (risk.get('branch')==b and risk.get('summary',{}).get('overall_risk')=='high'):
            targets[r].setdefault('stacks',[])
            if not targets[r]['stacks']: targets[r]['stacks'].append({'stack_id':f'stack-{r}-0001','branches':[]})
            targets[r]['stacks'][0]['branches'].append({'branch':b,'order':len(targets[r]['stacks'][0]['branches'])+1,'resolved_parent':r,'action':'track_only'})
    return artifact('stack_order.json',{'run_id':rid,'targets':targets},rid)

def validate(kind):
    rid=run_id(); failed=[]
    if kind=='replay':
        risk=rj(LATEST/'replay_risk.json',{}); st=risk.get('repository_state',{})
        for k in ['active_rebase','active_merge','active_cherry_pick']:
            if st.get(k): failed.append({'id':k.replace('_','-'),'severity':'critical'})
        if risk.get('conflicts',{}).get('conflicted_files'): failed.append({'id':'conflicted-files','severity':'critical'})
        name='validation/replay_validation.json'
    elif kind=='targets':
        tm=rj(LATEST/'target_matrix.json',{'branches':{}}); failed=[{'id':'unresolved-target-intent','branch':b,'severity':'high'} for b,m in tm.get('branches',{}).items() if m.get('requires_user_decision')]; name='validation/target_validation.json'
    elif kind=='roots':
        rh=rj(LATEST/'root_health.json',{'roots':{}}); failed=[{'id':'stale-root-blocker','target_root':r,'severity':'critical'} for r,h in rh.get('roots',{}).items() if h.get('health')=='stale' and not h.get('execution_allowed')]; name='validation/root_validation.json'
    else:
        so=rj(LATEST/'stack_order.json',{'targets':{}}); failed=[{'id':'blocked-target-has-stack','target_root':r,'severity':'critical'} for r,s in so.get('targets',{}).items() if not s.get('execution_allowed') and s.get('stacks')]; name='validation/stack_order_validation.json'
    return artifact(name,{'run_id':rid,'status':'blocked' if failed else 'pass','failed_checks':failed},rid)

def checklist(args=None):
    rid=run_id(); required=['repo_inventory.json','topology_graph.json','target_matrix.json','root_health.json','replay_risk.json','stack_order.json']; checks=[]
    for f in required:
        ok=(LATEST/f).exists(); checks.append({'id':'artifact-'+f,'status':'pass' if ok else 'failed','severity':'critical' if not ok else 'low'})
    failed=[c for c in checks if c['status']=='failed']; return artifact('checklist_report.json',{'run_id':rid,'status':'blocked' if failed else 'pass','checks':checks,'summary':{'total':len(checks),'failed':len(failed)}},rid)

def analyze(args=None):
    rid=run_id(); issues=[]; cp=rj(LATEST/'command_plan.json',{}); risk=rj(LATEST/'replay_risk.json',{})
    if cp.get('commands') and risk.get('summary',{}).get('overall_risk')=='high': issues.append({'id':'replay-risk-command-plan-conflict','severity':'critical'})
    return artifact('analysis_report.json',{'run_id':rid,'status':'blocked' if issues else 'pass','issues':issues},rid)

def questions(args=None):
    rid=run_id(); out=[]; tm=rj(LATEST/'target_matrix.json',{'branches':{}}); risk=rj(LATEST/'replay_risk.json',{})
    for b,m in tm.get('branches',{}).items():
        if m.get('requires_user_decision'): out.append({'id':f'q-target-{len(out)+1:06d}','type':'target_intent','branch':b,'question':f'Which target should {b} use?','options':['leave_triage','exclude_from_migration']})
    if risk.get('summary',{}).get('overall_risk')=='high': out.append({'id':f'q-replay-{len(out)+1:06d}','type':'conflict_resolution_policy','branch':risk.get('branch'),'question':'How should replay blockers be handled?','options':['resolve_manually_then_rerun','abort_rebase_then_reanalyse','leave_branch_blocked']})
    return artifact('decision_prompts.json',{'run_id':rid,'questions':out},rid)

def recommend(args=None):
    rid=run_id(); risk=rj(LATEST/'replay_risk.json',{}); high=risk.get('summary',{}).get('overall_risk')=='high'
    opts=[{'id':'opt-001','label':'Block execution and resolve replay blockers' if high else 'Proceed to validators and dry-run command plan','risk':'low','todos':['Resolve blockers','Rerun validators'] if high else ['Run checklist','Run analyze','Build command plan']}]
    artifact('recommendation_options.json',{'run_id':rid,'recommendations':[{'id':'rec-000001','branch':risk.get('branch'),'recommended_option':'opt-001','options':opts}]},rid)
    todos=[{'id':f'todo-{i+1:06d}','status':'open','priority':'critical' if i==0 else 'high','description':t,'completion_check':'rerun converge'} for i,t in enumerate(opts[0]['todos'])]
    artifact('agent_todos.json',{'run_id':rid,'todos':todos},rid)
    text='# Agent Briefing\n\n'+'\n'.join(f"- {t['id']}: {t['description']}" for t in todos)+'\n'
    text_artifact('agent_briefing.md',text,rid,True)
    return artifact('agent_work_package.json',{'run_id':rid,'status':'blocked' if high else 'ready_for_validation','briefing':'agent_briefing.md','recommendations':'recommendation_options.json','todos':'agent_todos.json'},rid)

def command_plan(args=None):
    rid=run_id(); reps=[rj(LATEST/'validation/replay_validation.json',{}),rj(LATEST/'validation/target_validation.json',{}),rj(LATEST/'validation/root_validation.json',{}),rj(LATEST/'validation/stack_order_validation.json',{})]; blocked=[r for r in reps if r.get('status')=='blocked']
    cmds=[]
    if not blocked:
        for _,s in rj(LATEST/'stack_order.json',{'targets':{}}).get('targets',{}).items():
            for st in s.get('stacks',[]):
                for b in st.get('branches',[]): cmds.append({'type':'suggested_graphite_track','branch':b['branch'],'parent':b['resolved_parent'],'command':f"gt track {b['branch']} --parent {b['resolved_parent']}",'requires_approval':True})
    return artifact('command_plan.json',{'run_id':rid,'mode':'dry_run','execution_allowed':False,'blocked_by':['validator'] if blocked else [],'commands':cmds},rid)

def report(args=None):
    rid=run_id(); risk=rj(LATEST/'replay_risk.json',{}); cp=rj(LATEST/'command_plan.json',{})
    return text_artifact('branch_stacking_report.md',f"# Branch Stacking Report\n\nRun ID: `{rid}`\n\nReplay risk: **{risk.get('summary',{}).get('overall_risk','unknown')}**\n\nExecution allowed: **{cp.get('execution_allowed',False)}**\n",rid,True)

def converge(args=None):
    rid=run_id(); todos=rj(LATEST/'agent_todos.json',{'todos':[]}); reps=[rj(LATEST/'validation/replay_validation.json',{}),rj(LATEST/'validation/target_validation.json',{}),rj(LATEST/'validation/root_validation.json',{}),rj(LATEST/'validation/stack_order_validation.json',{})]
    blockers=[]
    for r in reps: blockers+=r.get('failed_checks',[])
    open_t=[t for t in todos.get('todos',[]) if t.get('status')!='done']
    return artifact('convergence_report.json',{'run_id':rid,'converged':not blockers and not open_t,'status':'blocked' if blockers or open_t else 'pass','remaining_blockers':blockers,'remaining_todos':[t['id'] for t in open_t]},rid)

def run_all(args=None):
    discover(args); topology(args); relationships(args); targets(args); roots(args); replay(args); decompose(args); stack_order(args); validate('replay'); validate('targets'); validate('roots'); validate('stack'); checklist(args); questions(args); recommend(args); command_plan(args); analyze(args); report(args); return converge(args)

def main(argv=None):
    p=argparse.ArgumentParser(); p.add_argument('--config'); p.add_argument('--new-run',action='store_true'); p.add_argument('--local-only',action='store_true'); p.add_argument('--branch'); p.add_argument('--parent'); p.add_argument('--dry-run',action='store_true')
    sub=p.add_subparsers(dest='cmd',required=True)
    for c in ['discover','topology','relationships','targets','roots','replay-risk','decompose','stack-order','validate-replay','validate-targets','validate-roots','validate-stack','checklist','analyze','recommend','command-plan','report','converge','all']:
        sub.add_parser(c)
    a=p.parse_args(argv)
    funcs={'discover':discover,'topology':topology,'relationships':relationships,'targets':targets,'roots':roots,'replay-risk':replay,'decompose':decompose,'stack-order':stack_order,'checklist':checklist,'analyze':analyze,'recommend':recommend,'command-plan':command_plan,'report':report,'converge':converge,'all':run_all}
    if a.cmd.startswith('validate-'):
        out=validate(a.cmd.replace('validate-',''))
    else: out=funcs[a.cmd](a)
    print(out if isinstance(out,str) else json.dumps(out,indent=2))
if __name__=='__main__': main()
