Syntax validation performed during packaging. Git-backed runtime tests require git in the target environment.
