# Latest Graphite Agent Full Folder

Install by copying `.graphite-agent` into a Git repo. Run:

```bash
python .graphite-agent/tools/graphite_agent.py all --local-only
```

This is V5 latest implemented framework. V6 semantic Tree-sitter/LSP integration is not included yet.
