# Graphite Agent Portable Framework V4

A self-contained, repo-agnostic branch-stacking analysis scaffold inspired by Spec Kit-style command workflows: artifact-first analysis, quality gates, cross-artifact analysis, recommendations, todos, and convergence.

## First run

```bash
python .graphite-agent/tools/discover_repo.py --local-only
python .graphite-agent/tools/replay_risk.py --local-only
python .graphite-agent/tools/validate_replay.py || true
python .graphite-agent/tools/checklist.py || true
python .graphite-agent/tools/analyze_consistency.py || true
python .graphite-agent/tools/generate_questions.py
python .graphite-agent/tools/generate_recommendations.py
python .graphite-agent/tools/generate_agent_todos.py
python .graphite-agent/tools/prepare_agent_briefing.py
python .graphite-agent/tools/write_report.py
python .graphite-agent/tools/build_command_plan.py --dry-run
python .graphite-agent/tools/converge.py || true
```

Analyzer mode is default. Execution is intentionally disabled in this V4 scaffold.
