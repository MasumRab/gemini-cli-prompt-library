# V4 Diff Report

This package supersedes the previous V7.3 bridge with a portable V4 scaffold focused on:

- repo-neutral config loading
- repo inventory
- run-scoped artifacts
- robust local-only analyzer mode
- replay-risk skeleton
- failed-rebase validation fixture
- report writer
- replay validator
- deterministic dry-run command plan
- agent work package, recommendations, todos, and convergence

It intentionally avoids wiring a real executor.
