# Failed Rebase Runbook

A failed rebase should be detected as high replay risk. Expected next actions: resolve or abort rebase, rerun replay risk, then run hunk decomposition if generated-file or semantic conflicts remain.
