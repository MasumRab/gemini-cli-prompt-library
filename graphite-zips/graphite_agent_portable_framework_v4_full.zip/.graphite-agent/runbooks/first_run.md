# First Run Runbook

Run the commands listed in README. If replay validation blocks, resolve the replay state first. Do not build executable plans until replay validation, checklist, and consistency analysis pass.
