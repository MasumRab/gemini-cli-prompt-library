# Spec Kit-Inspired Workflow Adaptation

This project adapts Spec Kit's artifact-driven quality-gate pattern to Git branch stacking. The equivalent phases are:

- discover: collect repo inventory
- analyze: topology/replay/cross-artifact consistency
- checklist: completeness/readiness gates
- clarify: generated bounded questions
- recommend: option generation and todo queue
- converge: verify blockers are resolved or produce next tasks
- execute-approved: disabled unless validators pass and approval exists

The agent should not inspect raw Git first. It should read `outputs/latest/agent_work_package.json` and `outputs/latest/agent_briefing.md`, then follow generated todos.
