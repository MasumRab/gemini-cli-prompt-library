# Conversation Context and Implementation Instructions

The `.graphite-agent` scope was clarified as a portable Git branch-stacking framework, not a one-off repair script for a specific repository. Relevant requirements captured from the discussion:

- Self-contained portable analysis toolkit installable into any repo.
- No dependency on this repo's DSPy/prompt/CI domain.
- No hardcoded absolute paths or repo-specific branch names in core scripts.
- Analyzer mode by default; executor mode only after explicit approval/config.
- Discover local/remote branches, PR metadata when available, merge bases, declared PR bases, ancestry and patch relationships.
- Produce topology, replay-risk, hunk-level decomposition, recommendations, agent todos, reports, and dry-run command plans.
- Treat the failed rebase pattern as a fixture that should be detected before restack.
- If expected old code differs from assumptions, preserve old files as legacy adapters and use V4 outputs as additive diagnostics rather than overwriting project-specific logic.
- Spec Kit-inspired behavior means scripts prepare structured artifacts, agents read a work package, present bounded options, record decisions, and rerun convergence.

If the existing codebase differs from this scaffold:

1. Do not delete local scripts. Back them up under `.graphite-agent/backups/`.
2. Keep existing analyser entrypoints as compatibility wrappers.
3. Move repo-specific assumptions into `.graphite-agent/config/repo.yaml`.
4. Use this scaffold's run-scoped artifacts as the source of truth for new analysis.
5. Add adapters rather than changing portable core logic.
