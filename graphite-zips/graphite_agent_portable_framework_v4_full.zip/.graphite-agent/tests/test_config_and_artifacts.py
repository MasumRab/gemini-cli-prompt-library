import tempfile, unittest, os, shutil, subprocess, sys, importlib.util
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def load(name, rel):
    spec=importlib.util.spec_from_file_location(name, ROOT/rel); mod=importlib.util.module_from_spec(spec); sys.modules[name]=mod; spec.loader.exec_module(mod); return mod
class ConfigArtifactTests(unittest.TestCase):
    def test_config_defaults(self):
        cfg=load('cfg','tools/lib/config.py').load_config('/no/such/file.yaml')
        self.assertEqual(cfg['execution']['default_mode'], 'analyzer_only')
    def test_io_run_id(self):
        io=load('io_mod','tools/lib/io.py')
        with tempfile.TemporaryDirectory() as td:
            old=os.getcwd(); os.chdir(td)
            rid=io.get_run_id(new=True)
            self.assertTrue(rid)
            os.chdir(old)
if __name__=='__main__': unittest.main()
