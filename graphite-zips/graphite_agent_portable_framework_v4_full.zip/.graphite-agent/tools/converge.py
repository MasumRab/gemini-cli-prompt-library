#!/usr/bin/env python3
import json, sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent))
from lib.io import read_json, write_artifact, write_text_artifact, LATEST_DIR, get_run_id
rv=read_json(LATEST_DIR/'validation/replay_validation.json',{})
todos=read_json(LATEST_DIR/'agent_todos.json',{'todos':[]})
open_todos=[t for t in todos.get('todos',[]) if t.get('status')!='done']
blocked=rv.get('status')=='blocked' or bool(open_todos)
report={'run_id':get_run_id(),'converged':not blocked,'status':'blocked' if blocked else 'pass','remaining_todos':[t.get('id') for t in open_todos],'remaining_blockers':rv.get('failed_checks',[]),'next_command':'python .graphite-agent/tools/generate_agent_todos.py' if open_todos else None}
write_artifact('convergence_report.json',report)
write_text_artifact('convergence_report.md','# Convergence Report\n\nStatus: **'+report['status']+'**\n',also_report=True)
print(json.dumps(report,indent=2)); sys.exit(1 if blocked else 0)
