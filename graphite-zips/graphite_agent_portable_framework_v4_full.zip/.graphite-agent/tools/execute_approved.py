#!/usr/bin/env python3
import os, sys
print('Analyzer mode by default. Execution is disabled in this portable scaffold.')
if os.environ.get('GRAPHITE_AGENT_APPROVED')!='1': sys.exit(1)
print('Approval detected, but no executor is wired in V4 scaffold.')
