#!/usr/bin/env python3
import subprocess, sys
sys.exit(subprocess.run(['python','.graphite-agent/tools/checklist.py']).returncode)
