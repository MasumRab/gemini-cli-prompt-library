#!/usr/bin/env python3
import argparse, json
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parent))
from lib.io import read_json, write_artifact, LATEST_DIR, get_run_id
p=argparse.ArgumentParser(); p.add_argument('--dry-run', action='store_true', default=True)
a=p.parse_args()
rv=read_json(LATEST_DIR/'validation/replay_validation.json',{})
blocked = rv.get('status') == 'blocked'
plan={'run_id':get_run_id(),'mode':'dry_run','execution_allowed':False,'blocked_by':['validate_replay'] if blocked else [],'commands':[] if blocked else [{'type':'suggested_next_step','command':'Run checklist.py and analyze_consistency.py before any executor wiring','requires_approval':True}]}
write_artifact('command_plan.json',plan)
print(json.dumps(plan,indent=2))
