#!/usr/bin/env python3
import json, sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent))
from lib.io import read_json, write_artifact, LATEST_DIR, get_run_id
risk=read_json(LATEST_DIR/'replay_risk.json',{})
failed=[]
state=risk.get('repository_state',{})
for key in ['active_rebase','active_merge','active_cherry_pick']:
    if state.get(key): failed.append({'id':key.replace('_','-'),'severity':'critical','message':f'{key} detected'})
if risk.get('conflicts',{}).get('conflicted_files'): failed.append({'id':'conflicted-files','severity':'critical','message':'Conflicted files are present'})
if risk.get('conflicts',{}).get('conflict_markers_detected'): failed.append({'id':'conflict-markers','severity':'critical','message':'Conflict markers detected'})
if risk.get('summary',{}).get('overall_risk')=='high' and not failed: failed.append({'id':'high-replay-risk','severity':'high','message':'High replay risk reported'})
report={'run_id':get_run_id(),'status':'blocked' if failed else 'pass','failed_checks':failed,'next_actions':['Resolve replay/conflict state and rerun replay_risk.py'] if failed else []}
write_artifact('validation/replay_validation.json',report)
print(json.dumps(report,indent=2)); sys.exit(1 if failed else 0)
