#!/usr/bin/env python3
import argparse, json, sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent))
from lib.io import append_jsonl, get_run_id, OUTPUTS_DIR
from datetime import datetime, timezone
p=argparse.ArgumentParser(); p.add_argument('--branch'); p.add_argument('--question'); p.add_argument('--scope'); p.add_argument('--option', required=True); p.add_argument('--reason', required=True)
a=p.parse_args(); ev={'event_id':'dec-option-'+datetime.now(timezone.utc).strftime('%Y%m%d%H%M%S'),'event_type':'decision_recorded','decision_type':'recommendation_option','branch':a.branch,'question_id':a.question,'scope':a.scope,'choice':'option='+a.option,'reason':a.reason,'run_id':get_run_id(),'timestamp':datetime.now(timezone.utc).isoformat()}
append_jsonl(OUTPUTS_DIR/'decision_log.jsonl',ev); print(json.dumps(ev,indent=2))
