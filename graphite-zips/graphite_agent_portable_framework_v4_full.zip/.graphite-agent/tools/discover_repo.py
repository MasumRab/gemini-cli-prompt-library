#!/usr/bin/env python3
import argparse, json, sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent))
from lib.inventory import discover_repo
p=argparse.ArgumentParser(); p.add_argument('--local-only', action='store_true', default=False); p.add_argument('--new-run', action='store_true', default=True)
a=p.parse_args(); print(json.dumps(discover_repo(local_only=a.local_only or True, new_run=a.new_run), indent=2))
