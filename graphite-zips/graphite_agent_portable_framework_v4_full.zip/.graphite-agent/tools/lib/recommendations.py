from __future__ import annotations
from .io import read_json, write_artifact, write_text_artifact, LATEST_DIR, get_run_id

def generate_questions() -> dict:
    run_id=get_run_id(); replay=read_json(LATEST_DIR/'replay_risk.json',{}); questions=[]
    if replay.get('summary',{}).get('overall_risk')=='high':
        branch=replay.get('branch') or 'current-branch'
        if replay.get('generated_file_risks'):
            questions.append({'id':'q-replay-000001','type':'generated_file_policy','branch':branch,'question':'How should generated files be handled during replay?','options':['regenerate_after_replay','manual_merge_generated_files','exclude_generated_files_from_replay'],'recommended_option':'regenerate_after_replay','reason':'Generated files are involved in replay risk.'})
        if replay.get('conflicts',{}).get('conflicted_files'):
            questions.append({'id':'q-replay-000002','type':'conflict_resolution_policy','branch':branch,'question':'How should current conflicts be handled before branch stacking?','options':['resolve_manually_then_rerun','abort_rebase_then_reanalyse','leave_branch_blocked'],'recommended_option':'resolve_manually_then_rerun','reason':'Conflicted files are present.'})
    out={'run_id':run_id,'questions':questions}
    write_artifact('decision_prompts.json',out,run_id)
    return out

def generate_recommendations() -> dict:
    run_id=get_run_id(); replay=read_json(LATEST_DIR/'replay_risk.json',{}); risk=replay.get('summary',{}).get('overall_risk','unknown')
    branch=replay.get('branch') or 'current-branch'
    options=[]
    if risk=='high':
        options.append({'id':'opt-001','label':'Block execution and resolve replay state','risk':'low','automation_level':'safe','why':['High replay risk detected'],'todos':['Resolve/abort active replay state','Rerun replay_risk.py','Rerun validate_replay.py']})
        options.append({'id':'opt-002','label':'Run hunk decomposition before command planning','risk':'medium','automation_level':'analysis_only','why':['High-risk changes may need decomposition'],'todos':['Run hunk_decompose.py','Review hunk_decomposition.md','Regenerate command plan']})
    else:
        options.append({'id':'opt-001','label':'Proceed to checklist and consistency analysis','risk':'low','automation_level':'analysis_only','why':['No critical replay blockers detected'],'todos':['Run checklist.py','Run analyze_consistency.py','Build dry-run command plan']})
    out={'run_id':run_id,'recommendations':[{'id':'rec-000001','branch':branch,'situation':replay.get('summary',{}).get('primary_reason'),'recommended_option':options[0]['id'] if options else None,'options':options,'blocked_until':['validate_replay passes'] if risk=='high' else []}]}
    write_artifact('recommendation_options.json',out,run_id)
    return out

def generate_todos() -> dict:
    run_id=get_run_id(); recs=read_json(LATEST_DIR/'recommendation_options.json',{'recommendations':[]}); todos=[]; i=0
    for rec in recs.get('recommendations',[]):
        for opt in rec.get('options',[])[:1]:
            for t in opt.get('todos',[]):
                i+=1; todos.append({'id':f'todo-{i:06d}','status':'open','priority':'critical' if i==1 else 'high','branch':rec.get('branch'),'description':t,'completion_check':'rerun converge.py and validators'})
    out={'run_id':run_id,'todos':todos}
    write_artifact('agent_todos.json',out,run_id)
    return out

def prepare_briefing() -> str:
    run_id=get_run_id(); replay=read_json(LATEST_DIR/'replay_risk.json',{}); recs=read_json(LATEST_DIR/'recommendation_options.json',{}); todos=read_json(LATEST_DIR/'agent_todos.json',{})
    text=f"""# Agent Briefing\n\nRun ID: `{run_id}`\n\n## Situation\n\nReplay risk is **{replay.get('summary',{}).get('overall_risk','unknown')}**. {replay.get('summary',{}).get('primary_reason','')}\n\n## Recommendations\n\n{len(recs.get('recommendations',[]))} recommendation set(s) generated.\n\n## Open Todos\n\n"""
    for t in todos.get('todos',[]): text += f"- [{t.get('status')}] {t.get('id')}: {t.get('description')}\n"
    write_text_artifact('agent_briefing.md',text,run_id,also_report=True)
    work={'run_id':run_id,'status':'blocked' if replay.get('summary',{}).get('overall_risk')=='high' else 'ready_for_validation','briefing':'agent_briefing.md','recommendations':'recommendation_options.json','todos':'agent_todos.json','next_agent_action':{'command':'python .graphite-agent/tools/present_options.py'}}
    write_artifact('agent_work_package.json',work,run_id)
    return text
