from __future__ import annotations
from . import git_utils as git
from .config import load_config
from .io import write_artifact, get_run_id

def discover_repo(local_only: bool = True, new_run: bool = True) -> dict:
    run_id = get_run_id(new=new_run)
    cfg = load_config()
    root = git.git_root()
    if not root:
        raise RuntimeError('Not inside a Git repository')
    state = git.active_state(root)
    status = git.status_porcelain()
    inventory = {
        'run_id': run_id,
        'repo': {
            'path': root,
            'git_root': root,
            'current_branch': git.current_branch(),
            'is_dirty': bool(status)
        },
        'state': {**state, 'conflicted_files': git.unmerged_status_entries(), 'status_porcelain': status},
        'branches': {
            'local': git.local_branches() if cfg['analysis'].get('include_local_branches', True) else [],
            'remote': git.remote_branches() if cfg['analysis'].get('include_remote_branches', True) else []
        },
        'targets': {
            'configured': cfg.get('roots', {}).get('configured', []),
            'origin_head': git.origin_head(),
            'discovered': []
        },
        'pr_metadata': {'available': False, 'reason': 'local_only mode' if local_only else 'not implemented in portable scaffold', 'items': []},
        'config_summary': {'mode': cfg.get('repo', {}).get('mode'), 'generated_patterns': cfg.get('generated_files', {}).get('patterns', [])}
    }
    # Lightweight target discovery: configured roots + origin head + remote branch basenames used commonly.
    discovered=set(inventory['targets']['configured'])
    if inventory['targets']['origin_head']: discovered.add(inventory['targets']['origin_head'])
    for rb in inventory['branches']['remote']:
        name = rb.split('/',1)[1] if '/' in rb else rb
        if name in {'main','master','develop','dev','trunk'} or name in discovered:
            discovered.add(name)
    inventory['targets']['discovered'] = sorted(discovered)
    write_artifact('repo_inventory.json', inventory, run_id)
    return inventory
