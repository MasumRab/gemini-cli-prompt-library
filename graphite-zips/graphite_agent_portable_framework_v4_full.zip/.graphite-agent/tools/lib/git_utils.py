from __future__ import annotations
import subprocess
from pathlib import Path

def run_git(args: list[str], check: bool = False) -> tuple[int, str, str]:
    p = subprocess.run(['git'] + args, capture_output=True, text=True)
    if check and p.returncode != 0:
        raise RuntimeError(f"git {' '.join(args)} failed: {p.stderr}")
    return p.returncode, p.stdout.strip(), p.stderr.strip()

def git_root() -> str | None:
    code, out, _ = run_git(['rev-parse','--show-toplevel'])
    return out if code == 0 else None

def current_branch() -> str | None:
    code, out, _ = run_git(['branch','--show-current'])
    return out if code == 0 and out else None

def status_porcelain() -> list[str]:
    code, out, _ = run_git(['status','--porcelain=v1','-uall'])
    return out.splitlines() if code == 0 and out else []

def local_branches() -> list[str]:
    code, out, _ = run_git(['for-each-ref','refs/heads','--format=%(refname:short)'])
    return out.splitlines() if code == 0 and out else []

def remote_branches() -> list[str]:
    code, out, _ = run_git(['for-each-ref','refs/remotes','--format=%(refname:short)'])
    return [x for x in out.splitlines() if not x.endswith('/HEAD')] if code == 0 and out else []

def origin_head() -> str | None:
    code, out, _ = run_git(['symbolic-ref','refs/remotes/origin/HEAD'])
    if code == 0 and out.startswith('refs/remotes/origin/'):
        return out.rsplit('/', 1)[-1]
    return None

def upstream_ref() -> str | None:
    code, out, _ = run_git(['rev-parse','--abbrev-ref','--symbolic-full-name','@{u}'])
    return out if code == 0 and out else None

def merge_base(a: str, b: str) -> str | None:
    code, out, _ = run_git(['merge-base', a, b])
    return out if code == 0 and out else None

def branch_head(ref: str) -> str | None:
    code, out, _ = run_git(['rev-parse', ref])
    return out if code == 0 else None

def active_state(git_root_path: str | None = None) -> dict:
    root = Path(git_root_path or git_root() or '.') / '.git'
    return {
        'active_rebase': (root/'rebase-merge').exists() or (root/'rebase-apply').exists(),
        'active_merge': (root/'MERGE_HEAD').exists(),
        'active_cherry_pick': (root/'CHERRY_PICK_HEAD').exists(),
        'active_revert': (root/'REVERT_HEAD').exists(),
    }

def unmerged_status_entries() -> list[dict]:
    entries = []
    unmerged = {'DD','AU','UD','UA','DU','AA','UU'}
    for line in status_porcelain():
        if len(line) < 4: continue
        xy = line[:2]
        path = line[3:]
        if xy in unmerged:
            ctype = 'both_modified' if xy == 'UU' else 'delete_modify' if xy in {'DU','UD'} else 'unmerged'
            entries.append({'path': path, 'status': xy, 'conflict_type': ctype})
    return entries

def changed_files(ref_range: str | None = None) -> list[str]:
    args = ['diff','--name-only']
    if ref_range: args.append(ref_range)
    code, out, _ = run_git(args)
    return out.splitlines() if code == 0 and out else []

def log_shortstat(ref_range: str) -> list[dict]:
    code, out, _ = run_git(['log','--shortstat','--pretty=format:@@@%H%x1f%s', ref_range])
    if code != 0 or not out: return []
    records=[]
    for block in out.split('@@@'):
        block=block.strip()
        if not block: continue
        lines=block.splitlines()
        head=lines[0].split('\x1f')
        stat=' '.join(lines[1:]) if len(lines)>1 else ''
        records.append({'commit': head[0], 'subject': head[1] if len(head)>1 else '', 'shortstat': stat})
    return records
