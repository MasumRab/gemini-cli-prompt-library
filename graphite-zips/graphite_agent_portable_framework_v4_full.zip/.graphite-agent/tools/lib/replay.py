from __future__ import annotations
import re
from pathlib import Path
from . import git_utils as git
from .config import load_config, is_generated, is_ignored
from .io import write_artifact, read_json, LATEST_DIR, get_run_id

def _parse_shortstat(stat: str) -> tuple[int,int]:
    files=0; lines=0
    m=re.search(r'(\d+) files? changed', stat); files=int(m.group(1)) if m else 0
    for m in re.finditer(r'(\d+) (insertion|deletion)', stat): lines += int(m.group(1))
    return files, lines

def _scan_conflict_markers(paths: list[str], max_files: int = 200) -> list[dict]:
    markers=[]
    for path in paths[:max_files]:
        p=Path(path)
        if not p.exists() or not p.is_file(): continue
        try:
            text=p.read_text(errors='ignore')
        except Exception:
            continue
        if '<<<<<<< ' in text or '=======' in text or '>>>>>>> ' in text:
            markers.append({'path': path, 'markers': True})
    return markers

def assess_replay_risk(branch: str | None = None, local_only: bool = True) -> dict:
    run_id = get_run_id()
    cfg = load_config()
    inv = read_json(LATEST_DIR/'repo_inventory.json', {})
    state = git.active_state(inv.get('repo',{}).get('git_root'))
    conflicted = git.unmerged_status_entries()
    status_paths=[x[3:] for x in git.status_porcelain() if len(x)>3]
    marker_paths = [c['path'] for c in conflicted] or status_paths
    markers = _scan_conflict_markers([p for p in marker_paths if not is_ignored(p,cfg)]) if cfg.get('replay',{}).get('detect_conflict_markers', True) else []
    upstream = git.upstream_ref() or ('origin/' + inv.get('targets',{}).get('origin_head','main') if inv.get('targets',{}).get('origin_head') else None)
    current = branch or inv.get('repo',{}).get('current_branch') or git.current_branch()
    ref_range = f'{upstream}..{current}' if upstream and current else None
    large=[]
    if ref_range:
        for rec in git.log_shortstat(ref_range):
            files, lines = _parse_shortstat(rec.get('shortstat',''))
            if files >= cfg['replay']['large_commit_file_threshold'] or lines >= cfg['replay']['large_commit_line_threshold']:
                large.append({**rec, 'files_changed': files, 'lines_changed': lines, 'risk': 'large_mixed_commit', 'recommendation': 'consider decomposition before replay'})
    generated=[]
    for p in status_paths:
        if is_generated(p,cfg): generated.append({'path': p, 'reason': 'matches generated file pattern', 'recommendation': 'regenerate after replay when possible'})
    high = any(state.values()) or bool(conflicted) or bool(markers)
    risk = {
        'run_id': run_id,
        'branch': current,
        'summary': {'overall_risk': 'high' if high else 'medium' if large or generated else 'low', 'execution_allowed': not high, 'primary_reason': 'active replay/conflict state detected' if high else 'large/generated changes require review' if (large or generated) else 'no immediate replay blockers detected'},
        'repository_state': {**state, 'dirty_worktree': bool(git.status_porcelain())},
        'conflicts': {'conflicted_files': conflicted, 'conflict_markers_detected': markers},
        'commit_risks': large,
        'generated_file_risks': generated,
        'recommendations': []
    }
    if high:
        risk['recommendations'] += ['Resolve or abort active rebase/merge/cherry-pick before restack.', 'Resolve conflicted files manually.', 'Rerun replay_risk.py after working tree is clean.']
    if large: risk['recommendations'].append('Run hunk_decompose.py for large mixed commits before command planning.')
    if generated: risk['recommendations'].append('Prefer regenerating generated artifacts after replay instead of manual merge.')
    write_artifact('replay_risk.json', risk, run_id)
    return risk
