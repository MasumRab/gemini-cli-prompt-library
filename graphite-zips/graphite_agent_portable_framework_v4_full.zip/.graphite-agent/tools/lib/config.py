from __future__ import annotations
from pathlib import Path
from typing import Any
import json, fnmatch

AGENT_DIR = Path('.graphite-agent')
CONFIG_DIR = AGENT_DIR / 'config'

DEFAULT_CONFIG = {
  'repo': {'name': 'auto', 'mode': 'local_only'},
  'analysis': {'include_remote_branches': True, 'include_local_branches': True, 'include_pr_metadata': 'auto'},
  'roots': {'configured': [], 'discover': True},
  'generated_files': {'patterns': ['dist/**','build/**','*.generated.*','*.lock'], 'treat_as_replay_risk': True},
  'ignore_paths': ['.git/**','.venv/**','node_modules/**'],
  'replay': {
    'large_commit_file_threshold': 20,
    'large_commit_line_threshold': 800,
    'detect_active_rebase': True,
    'detect_conflict_markers': True,
    'detect_delete_modify': True,
    'detect_both_modified': True
  },
  'execution': {'default_mode': 'analyzer_only', 'require_explicit_approval': True}
}

def _deep_merge(a: dict, b: dict) -> dict:
    out = dict(a)
    for k,v in (b or {}).items():
        if isinstance(v, dict) and isinstance(out.get(k), dict):
            out[k] = _deep_merge(out[k], v)
        else:
            out[k] = v
    return out

def _load_yaml_like(path: Path) -> dict:
    # Prefer PyYAML if available; otherwise support a minimal JSON/YAML subset.
    text = path.read_text(encoding='utf-8')
    try:
        import yaml  # type: ignore
        data = yaml.safe_load(text) or {}
        return data if isinstance(data, dict) else {}
    except Exception:
        try:
            return json.loads(text)
        except Exception:
            # Minimal fallback: ignore unknown complex YAML rather than failing.
            return {}

def load_config(path: str | Path | None = None) -> dict:
    cfg = dict(DEFAULT_CONFIG)
    p = Path(path) if path else CONFIG_DIR / 'repo.yaml'
    if p.exists():
        cfg = _deep_merge(cfg, _load_yaml_like(p))
    return cfg

def is_ignored(path: str, cfg: dict | None = None) -> bool:
    cfg = cfg or load_config()
    return any(fnmatch.fnmatch(path, pat) for pat in cfg.get('ignore_paths', []))

def is_generated(path: str, cfg: dict | None = None) -> bool:
    cfg = cfg or load_config()
    return any(fnmatch.fnmatch(path, pat) for pat in cfg.get('generated_files', {}).get('patterns', []))
