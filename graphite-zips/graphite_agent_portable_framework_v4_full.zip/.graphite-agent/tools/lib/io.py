from __future__ import annotations
import json, os, shutil
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

AGENT_DIR = Path('.graphite-agent')
OUTPUTS_DIR = AGENT_DIR / 'outputs'
RUNS_DIR = OUTPUTS_DIR / 'runs'
LATEST_DIR = OUTPUTS_DIR / 'latest'
REPORTS_DIR = AGENT_DIR / 'reports'
CURRENT_RUN_FILE = OUTPUTS_DIR / 'current_run.txt'

def utc_run_id() -> str:
    return datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')

def ensure_dirs() -> None:
    for p in [OUTPUTS_DIR, RUNS_DIR, LATEST_DIR, REPORTS_DIR]:
        p.mkdir(parents=True, exist_ok=True)

def get_run_id(new: bool = False) -> str:
    ensure_dirs()
    env = os.environ.get('GRAPHITE_AGENT_RUN_ID')
    if env and not new:
        CURRENT_RUN_FILE.write_text(env, encoding='utf-8')
        return env
    if not new and CURRENT_RUN_FILE.exists():
        return CURRENT_RUN_FILE.read_text(encoding='utf-8').strip()
    rid = utc_run_id()
    CURRENT_RUN_FILE.write_text(rid, encoding='utf-8')
    return rid

def run_dir(run_id: str | None = None) -> Path:
    rid = run_id or get_run_id()
    p = RUNS_DIR / rid
    p.mkdir(parents=True, exist_ok=True)
    (p / 'validation').mkdir(parents=True, exist_ok=True)
    return p

def read_json(path: str | Path, default: Any = None) -> Any:
    p = Path(path)
    if not p.exists():
        return default
    return json.loads(p.read_text(encoding='utf-8'))

def write_json(path: str | Path, data: Any) -> None:
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(data, indent=2, sort_keys=True), encoding='utf-8')

def write_artifact(name: str, data: Any, run_id: str | None = None) -> Path:
    rd = run_dir(run_id)
    dest = rd / name
    write_json(dest, data)
    latest = LATEST_DIR / name
    write_json(latest, data)
    return dest

def write_text_artifact(name: str, text: str, run_id: str | None = None, also_report: bool = False) -> Path:
    rd = run_dir(run_id)
    dest = rd / name
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_text(text, encoding='utf-8')
    latest = LATEST_DIR / name
    latest.parent.mkdir(parents=True, exist_ok=True)
    latest.write_text(text, encoding='utf-8')
    if also_report:
        report = REPORTS_DIR / Path(name).name
        report.parent.mkdir(parents=True, exist_ok=True)
        report.write_text(text, encoding='utf-8')
    return dest

def append_jsonl(path: str | Path, data: dict) -> None:
    p = Path(path); p.parent.mkdir(parents=True, exist_ok=True)
    with p.open('a', encoding='utf-8') as f:
        f.write(json.dumps(data, sort_keys=True) + '\n')

def read_jsonl(path: str | Path) -> list[dict]:
    p = Path(path)
    if not p.exists(): return []
    return [json.loads(line) for line in p.read_text(encoding='utf-8').splitlines() if line.strip()]
