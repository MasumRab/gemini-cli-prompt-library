#!/usr/bin/env python3
import argparse, json, sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent))
from lib.replay import assess_replay_risk
p=argparse.ArgumentParser(); p.add_argument('--branch'); p.add_argument('--local-only', action='store_true')
a=p.parse_args(); print(json.dumps(assess_replay_risk(branch=a.branch, local_only=True), indent=2))
