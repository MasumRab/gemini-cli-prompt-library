#!/usr/bin/env python3
import json, sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent))
from lib.io import LATEST_DIR, write_artifact, write_text_artifact, get_run_id
required=['repo_inventory.json','replay_risk.json']
checks=[]
for f in required:
    ok=(LATEST_DIR/f).exists(); checks.append({'id':f'artifact-{f}','status':'pass' if ok else 'failed','severity':'critical' if not ok else 'low','message':f'{f} present' if ok else f'{f} missing'})
failed=[c for c in checks if c['status']=='failed']
report={'run_id':get_run_id(),'status':'blocked' if failed else 'pass','summary':{'total':len(checks),'failed':len(failed),'passed':len(checks)-len(failed)},'checks':checks}
write_artifact('checklist_report.json',report)
write_text_artifact('checklist_report.md','# Checklist Report\n\nStatus: **'+report['status']+'**\n',also_report=True)
print(json.dumps(report,indent=2)); sys.exit(1 if failed else 0)
