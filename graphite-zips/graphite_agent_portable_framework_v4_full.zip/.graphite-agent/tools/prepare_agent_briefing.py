#!/usr/bin/env python3
import json, sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent))
from lib.recommendations import prepare_briefing
out=prepare_briefing()
print(out if isinstance(out,str) else json.dumps(out,indent=2))
