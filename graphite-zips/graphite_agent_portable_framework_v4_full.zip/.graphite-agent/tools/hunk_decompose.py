#!/usr/bin/env python3
import argparse, json, sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent))
from lib.io import read_json, write_artifact, write_text_artifact, LATEST_DIR, get_run_id
p=argparse.ArgumentParser(); p.add_argument('--branch')
a=p.parse_args(); risk=read_json(LATEST_DIR/'replay_risk.json',{})
branch=a.branch or risk.get('branch') or 'current-branch'
items=[]
for g in risk.get('generated_file_risks',[]): items.append({'branch':branch,'file':g['path'],'label':'generated_artifact','recommendation':'regenerate_after_replay'})
for c in risk.get('conflicts',{}).get('conflicted_files',[]): items.append({'branch':branch,'file':c['path'],'label':c.get('conflict_type','conflict'),'recommendation':'manual_semantic_decision_required'})
out={'run_id':get_run_id(),'branch':branch,'decomposition':items,'manual_semantic_decisions':[x for x in items if x['recommendation']=='manual_semantic_decision_required']}
write_artifact('hunk_decomposition.json',out)
md='# Hunk Decomposition Report\n\n'+'\n'.join(f"- `{x['file']}`: {x['label']} → {x['recommendation']}" for x in items)+'\n'
write_text_artifact('hunk_decomposition.md',md,also_report=True)
print(json.dumps(out,indent=2))
