#!/usr/bin/env python3
import json, sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent))
from lib.recommendations import generate_questions
out=generate_questions()
print(out if isinstance(out,str) else json.dumps(out,indent=2))
