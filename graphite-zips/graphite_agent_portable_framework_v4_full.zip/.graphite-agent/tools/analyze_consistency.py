#!/usr/bin/env python3
import json, sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent))
from lib.io import read_json, write_artifact, write_text_artifact, LATEST_DIR, get_run_id
issues=[]
cmd=read_json(LATEST_DIR/'command_plan.json',{})
risk=read_json(LATEST_DIR/'replay_risk.json',{})
if cmd.get('commands') and risk.get('summary',{}).get('overall_risk')=='high':
    issues.append({'id':'replay-risk-command-plan-conflict','severity':'critical','message':'High replay risk but command plan contains commands','artifacts':['replay_risk.json','command_plan.json']})
status='blocked' if any(i['severity']=='critical' for i in issues) else 'pass'
report={'run_id':get_run_id(),'status':status,'issues':issues,'summary':{'critical':sum(1 for i in issues if i['severity']=='critical')}}
write_artifact('analysis_report.json',report)
write_text_artifact('analysis_report.md','# Cross-Artifact Analysis Report\n\nStatus: **'+status+'**\n',also_report=True)
print(json.dumps(report,indent=2)); sys.exit(1 if status=='blocked' else 0)
