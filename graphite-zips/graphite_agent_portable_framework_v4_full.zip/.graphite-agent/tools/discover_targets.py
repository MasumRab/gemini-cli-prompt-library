#!/usr/bin/env python3
print('This portable V4 scaffold keeps this command as a compatibility placeholder. Use discover_repo.py, replay_risk.py, checklist.py, analyze_consistency.py, and build_command_plan.py.')
