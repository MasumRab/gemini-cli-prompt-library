#!/usr/bin/env python3
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent))
from lib.reports import write_branch_stacking_report
print(write_branch_stacking_report())
