# graphite-agent discover

Run discover_repo.py --local-only. Read repo_inventory.json. Do not mutate Git.
