# graphite-agent execute-approved

Only execute if all validators pass and GRAPHITE_AGENT_APPROVED=1. Execution is not wired in V4 scaffold.
