# graphite-agent checklist

Validate artifact completeness and readiness. Treat failures as blockers unless explicitly waived.
