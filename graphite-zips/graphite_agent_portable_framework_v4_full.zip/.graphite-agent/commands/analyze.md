# graphite-agent analyze

Run checklist.py and analyze_consistency.py after artifacts exist. Report critical inconsistencies before command planning.
