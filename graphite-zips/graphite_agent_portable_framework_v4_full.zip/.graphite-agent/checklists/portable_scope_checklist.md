# Portable Scope Checklist
- [ ] No hardcoded paths.
- [ ] Config loader works without repo.yaml.
- [ ] Local-only mode works.
- [ ] No mutation by default.
