# Replay Risk Checklist
- [ ] Active rebase checked.
- [ ] Conflicts checked.
- [ ] Conflict markers checked.
- [ ] Large mixed commits checked.
- [ ] Generated files checked.
