# Failed Rebase Fixture

Represents a repository in an interrupted replay state with conflicted files. The replay-risk analyser should report high risk and block command planning.
