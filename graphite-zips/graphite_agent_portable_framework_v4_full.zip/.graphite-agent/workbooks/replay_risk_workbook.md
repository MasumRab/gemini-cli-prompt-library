# Replay Risk Workbook

```yaml
branch:
active_rebase:
active_merge:
active_cherry_pick:
conflicted_files:
conflict_markers:
large_mixed_commits:
generated_file_risks:
recommended_option:
user_decision:
validation_result:
```
