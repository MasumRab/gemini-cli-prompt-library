# Graphite Agent Constitution

1. Analyzer mode is the default.
2. No Git, PR, Graphite, or filesystem-destructive mutation without explicit approval.
3. Never auto-resolve semantic conflicts.
4. Never auto-parent patch-equivalent branches.
5. Block execution when replay risk is high.
6. Keep core scripts repo-neutral; put assumptions in config.
7. Generated files should be regenerated after replay unless config says otherwise.
