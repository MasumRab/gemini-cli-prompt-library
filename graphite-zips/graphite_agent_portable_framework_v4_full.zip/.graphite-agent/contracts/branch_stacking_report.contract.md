# Branch Stacking Report

Must contain executive summary, repository inventory, replay risk, blockers, next commands, and execution status.
