from graphite_agent.bootstrap import build_executor

def main(): build_executor(True).execute()
if __name__=="__main__": main()
