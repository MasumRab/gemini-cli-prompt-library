from graphite_agent.bootstrap import build_pr_ops

def main():
    ops=build_pr_ops()
    ops.process_current_pr(lambda comment: {"applied": False})
if __name__=="__main__": main()
