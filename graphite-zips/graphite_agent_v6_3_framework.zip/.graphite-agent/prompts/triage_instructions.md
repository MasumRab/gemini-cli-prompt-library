# Triage Instructions

Read `analysis_summary.json`, then `triage_packets.json`, then hydrate only referenced relationship evidence. Never infer parentage from patch-id overlap alone.
