from .artefact_writer import ArtefactWriter
from .branch_classifier import BranchClassifier
from .config import load_config
from .executor import StrictExecutor
from .git_adapter import GitAdapter
from .github_provider import GitHubPullRequestProvider
from .graphite_client import GraphiteClient
from .ids import IdFactory
from .invariant_verifier import InvariantVerifier
from .pipeline import AnalysisPipeline
from .plan_compiler import PlanCompiler
from .plan_reader import ExecutionPlanReader
from .policy import ConservativeGraphitePolicy
from .post_action_verifier import PostActionVerifier
from .relationship_collector import RelationshipCollector
from .triage import GuidedTriage
from .pr_ops import DailyPrOps

def build_analysis_pipeline():
    c=load_config(); ids=IdFactory(); git=GitAdapter(c.primary_remote,c.cli_retries); provider=GitHubPullRequestProvider(git); policy=ConservativeGraphitePolicy(); verifier=InvariantVerifier(c,git); collector=RelationshipCollector(c,git,ids); classifier=BranchClassifier(c,verifier,policy); compiler=PlanCompiler(ids,policy,c.schema_version); writer=ArtefactWriter(c.output_dir,c.write_legacy_aliases)
    return AnalysisPipeline(c,provider,collector,classifier,compiler,writer,policy)
def build_executor(enable_post_action_verification=True):
    c=load_config(); git=GitAdapter(c.primary_remote,c.cli_retries); graphite=GraphiteClient(git,c.dry_run); reader=ExecutionPlanReader(f"{c.output_dir}/execution_plan.json"); verifier=PostActionVerifier(build_analysis_pipeline,c.dry_run) if enable_post_action_verification else None
    return StrictExecutor(reader,graphite,verifier)
def build_triage(): return GuidedTriage(load_config().output_dir)
def build_pr_ops():
    c=load_config(); return DailyPrOps(GitAdapter(c.primary_remote,c.cli_retries))
