import json
from dataclasses import asdict,is_dataclass
from pathlib import Path
class ArtefactWriter:
    def __init__(self, output_dir, write_legacy_aliases=True): self.output_dir=Path(output_dir); self.write_legacy_aliases=write_legacy_aliases
    def _normalise(self,o):
        if is_dataclass(o): return asdict(o)
        if isinstance(o,list): return [self._normalise(x) for x in o]
        if isinstance(o,dict): return {k:self._normalise(v) for k,v in o.items()}
        return o
    def write_json(self,name,obj):
        self.output_dir.mkdir(parents=True,exist_ok=True); path=self.output_dir/name; path.write_text(json.dumps(self._normalise(obj),indent=2,sort_keys=True),encoding='utf-8'); return path
    def write_all(self,snapshot,relationship_graph,summary,execution_plan,triage_packets):
        for name,obj in [("analysis_snapshot.json",snapshot),("relationship_graph.json",relationship_graph),("analysis_summary.json",summary),("execution_plan.json",execution_plan),("triage_packets.json",triage_packets)]: self.write_json(name,obj)
        if self.write_legacy_aliases:
            legacy=Path('.graphite-agent'); legacy.mkdir(parents=True,exist_ok=True)
            (legacy/'analysis_snapshot.json').write_text(json.dumps(self._normalise(snapshot),indent=2,sort_keys=True),encoding='utf-8')
            (legacy/'plan.json').write_text(json.dumps(self._normalise(execution_plan),indent=2,sort_keys=True),encoding='utf-8')
