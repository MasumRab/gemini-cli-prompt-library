from .constants import EXECUTABLE_STATUSES
class PlanCompiler:
    def __init__(self, ids, policy, schema_version): self.ids=ids; self.policy=policy; self.schema_version=schema_version
    def compile_execution_plan(self,nodes):
        q=[]
        for b,n in nodes.items():
            if self.policy.can_execute_branch(n): q.append({"id":self.ids.execution_id(),"branch":b,"resolved_parent":n.resolved_parent,"root_branch":n.root_branch,"status":n.status,"action":"track_and_restack" if n.status=="needs_restack" else "track_only","relationship_edges":n.relationship_edges,"preconditions":n.audit.invariants})
        return {"schema_version":self.schema_version,"execution_queue":q}
    def compile_triage_packets(self,nodes):
        packets={}
        for b,n in nodes.items():
            if n.status in EXECUTABLE_STATUSES: continue
            pid=self.ids.triage_id(); packets[pid]={"id":pid,"branch":b,"status":n.status,"root_branch":n.root_branch,"primary_reason":n.reason,"relationship_edges":n.relationship_edges,"candidate_parents":n.sources,"risk_annotations":n.risk_annotations,"recommended_action":"manual review; do not auto-track","detail_refs":{"branch_node_ref":f"analysis_snapshot.branch_graph.nodes.{b}","relationship_edges":n.relationship_edges}}
        return {"schema_version":self.schema_version,"packets":packets}
