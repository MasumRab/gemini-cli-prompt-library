import json, os
class DailyPrOps:
    def __init__(self, git): self.git=git
    def unresolved_review_threads(self):
        meta=json.loads(self.git.run(['gh','repo','view','--json','owner,name']))
        pr=json.loads(self.git.run(['gh','pr','view','--json','number']))['number']
        owner=meta['owner']['login']; repo=meta['name']
        query=f"""{{ repository(owner: "{owner}", name: "{repo}") {{ pullRequest(number: {pr}) {{ reviewThreads(first: 50) {{ nodes {{ id isResolved comments(first: 1) {{ nodes {{ body }} }} }} }} }} }} }}"""
        data=json.loads(self.git.run(['gh','api','graphql','-f',f'query={query}']))
        return [t for t in data['data']['repository']['pullRequest']['reviewThreads']['nodes'] if not t.get('isResolved')]
    def process_current_pr(self, apply_fix_callback):
        fixed=False
        for t in self.unresolved_review_threads():
            body=(t.get('comments',{}).get('nodes') or [{}])[0].get('body','')
            result=apply_fix_callback(body)
            if not result or not result.get('applied'): continue
            self.git.run(['git','add','-A']); self.git.run(['git','commit','-m',result.get('message','chore: address review comment')]); fixed=True
        if fixed and os.getenv('GRAPHITE_AUTO_SUBMIT')=='1': self.git.run(['gt','submit','--stack','--no-interactive'])
        return fixed
