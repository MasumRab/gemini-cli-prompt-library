import json
from pathlib import Path
class GuidedTriage:
    def __init__(self,output_dir='.graphite-agent/outputs'): self.output_dir=Path(output_dir)
    def _load(self,name):
        path=self.output_dir/name
        if not path.exists(): raise RuntimeError(f"Missing file: {path}")
        return json.loads(path.read_text(encoding='utf-8'))
    def relationship_index(self): return {e['id']:e for e in self._load('relationship_graph.json').get('edges',[])}
    def print_summary(self):
        s=self._load('analysis_summary.json'); print(json.dumps(s.get('counts',{}),indent=2)); return s
    def print_packets(self):
        triage=self._load('triage_packets.json'); rel=self.relationship_index()
        for p in triage.get('packets',{}).values():
            print('='*72); print(f"Triage packet: {p['id']}"); print(f"Branch: {p['branch']}"); print(f"Status: {p['status']}"); print(f"Reason: {p.get('primary_reason')}")
            for rid in p.get('relationship_edges',[]):
                e=rel.get(rid); print(f"  - {rid}: {e.get('edge_type') if e else 'missing'}")
        return triage
