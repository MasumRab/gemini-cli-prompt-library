from dataclasses import dataclass, field
from typing import Any, Literal

RelationshipClassification = Literal["executable", "triage_only", "blocked", "informational"]
BranchStatus = Literal[
    "safe", "needs_restack", "cross_root_conflict", "blocked_merge_commits", "cycle",
    "unrooted", "patch_equivalence_only", "declared_base_mismatch", "ambiguous_relationship",
    "complex_hub_node", "complex_dag_dependency", "ghost_commit_overlap",
]
@dataclass
class PullRequestInfo:
    number: int | None
    title: str | None
    url: str | None
    head_ref_name: str
    head_ref_oid: str | None
    base_ref_name: str | None
    is_draft: bool = False
    review_decision: str | None = None
    merge_state_status: str | None = None
    mergeable: str | None = None
    raw: dict[str, Any] = field(default_factory=dict)
@dataclass
class RelationshipEdge:
    id: str
    from_ref: str
    to_ref: str
    edge_type: str
    classification: RelationshipClassification
    status: str
    confidence: str
    root_branch: str | None
    evidence: list[str]
@dataclass
class BranchAudit:
    root_owner: dict[str, Any]
    invariants: dict[str, bool]
    failed_invariants: list[str]
    triage_reason: list[str]
@dataclass
class BranchNode:
    branch: str
    root_branch: str | None
    resolved_parent: str | None
    status: BranchStatus | str
    reason: str
    audit: BranchAudit
    relationship_edges: list[str]
    sources: list[str] = field(default_factory=list)
    targets: list[str] = field(default_factory=list)
    risk_annotations: list[dict[str, Any]] = field(default_factory=list)
