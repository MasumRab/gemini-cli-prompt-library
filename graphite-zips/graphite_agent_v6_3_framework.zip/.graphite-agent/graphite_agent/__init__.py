"""Graphite Multi-Root Agentic Retrofit framework."""
__version__ = "6.3.0"
