class GraphiteClient:
    def __init__(self,git,dry_run=False): self.git=git; self.dry_run=dry_run; self.commands=[]
    def _run(self,args):
        self.commands.append(args)
        if self.dry_run: print('[DRY-RUN] '+' '.join(args)); return ''
        return self.git.run(args)
    def checkout_branch(self,branch):
        self.commands.append(['git','checkout','-f',branch])
        if self.dry_run: print(f'[DRY-RUN] git checkout -f {branch}'); return
        self.git.checkout_branch(branch)
    def track(self,branch,parent): self._run(['gt','track',branch,'--parent',parent,'--force','--no-interactive'])
    def restack(self): self._run(['gt','restack','--no-interactive'])
    def verify_parent(self,branch,expected_parent):
        if self.dry_run: return True
        output=self.git.run(['gt','branch','info',branch,'--no-interactive']); actual=None
        for line in output.splitlines():
            if line.strip().startswith('Parent:'): actual=line.split(':',1)[1].strip(); break
        if actual!=expected_parent: raise RuntimeError(f"Graphite parent mismatch for {branch}: expected {expected_parent!r}, got {actual!r}")
        return True
