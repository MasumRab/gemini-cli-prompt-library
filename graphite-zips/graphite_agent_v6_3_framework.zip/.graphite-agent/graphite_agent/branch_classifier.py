from .models import BranchNode
from .constants import FAILED_CI_STATES
class BranchClassifier:
    def __init__(self, config, verifier, policy): self.config=config; self.verifier=verifier; self.policy=policy
    def classify(self, pr, relationship_edges, topology=None, has_cycle=False):
        topology=topology or {"sources":[],"targets":[]}; b=pr.head_ref_name
        branch_edges=[e for e in relationship_edges if e.from_ref==b or e.to_ref==b]
        inbound=[e for e in relationship_edges if e.to_ref==b]
        executable=[e for e in inbound if self.policy.is_executable_edge(e)]
        blocked=[e for e in branch_edges if self.policy.is_blocked_edge(e)]
        known=[e for e in inbound if e.edge_type=="known_pr_merge"]
        patch=[e for e in branch_edges if e.edge_type=="patch_id_overlap"]
        patch_only=not executable and bool(patch)
        parent=executable[0].from_ref if executable else None; root=executable[0].root_branch if executable else None
        ambiguous=not parent and not patch_only and not blocked and not known
        audit=self.verifier.verify(b,root,parent,bool(executable),bool(blocked),has_cycle,ambiguous,patch_only)
        status,reason=self._status(audit,executable,blocked,known,patch_only,topology)
        return BranchNode(b,root,parent if status in {"safe","needs_restack"} else None,status,reason,audit,[e.id for e in branch_edges],topology.get("sources",[]),topology.get("targets",[]),self._risk(pr))
    def _status(self,audit,executable,blocked,known,patch_only,topology):
        if not audit.invariants["root_branch_resolved"]: return "unrooted","No configured root owner found."
        if not audit.invariants["single_root_owner"]: return "cross_root_conflict","Branch has multiple configured root owners."
        if not audit.invariants["cycle_free"]: return "cycle","Cycle detected in executable candidate graph."
        if blocked: return "blocked_merge_commits","Branch has blocked merge or cross-root evidence."
        if len(topology.get("sources",[]))>1 and len(topology.get("targets",[]))>1: return "complex_hub_node","Branch has multiple sources and multiple downstream targets."
        if known and not executable: return "complex_dag_dependency","Branch contains merge evidence from known PR branches and must be linearised."
        if executable: return ("needs_restack","Executable same-root parent exists but ancestry is stale.") if executable[0].status=="needs_restack" else ("safe","Declared parent is same-root ancestor.")
        if patch_only: return "ghost_commit_overlap","Patch overlap exists but no executable ancestry relationship exists."
        return "ambiguous_relationship","No safe Graphite parent relationship could be derived."
    def _risk(self,pr):
        anns=[]
        if pr.is_draft: anns.append({"type":"draft_pr","classification":"informational","evidence":["isDraft=true"]})
        if pr.merge_state_status:
            kind="failed_ci" if pr.merge_state_status in FAILED_CI_STATES else "mergeability_state"
            anns.append({"type":kind,"classification":"informational","evidence":[f"mergeStateStatus={pr.merge_state_status}"]})
        if pr.review_decision: anns.append({"type":"review_state","classification":"informational","evidence":[f"reviewDecision={pr.review_decision}"]})
        return anns
