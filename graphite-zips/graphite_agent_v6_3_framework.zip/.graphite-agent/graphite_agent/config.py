from dataclasses import dataclass
import os

@dataclass(frozen=True)
class GraphiteAgentConfig:
    configured_roots: list[str]
    default_root: str
    primary_remote: str = "origin"
    output_dir: str = ".graphite-agent/outputs"
    schema_version: str = "6.3"
    write_legacy_aliases: bool = True
    dry_run: bool = False
    cli_retries: int = 2

def load_config() -> GraphiteAgentConfig:
    roots = [r.strip() for r in os.getenv("GRAPHITE_TRUNK_BRANCHES", "main").split(",") if r.strip()] or ["main"]
    return GraphiteAgentConfig(
        configured_roots=roots,
        default_root=roots[0],
        primary_remote=os.getenv("GRAPHITE_PRIMARY_REMOTE", "origin"),
        output_dir=os.getenv("GRAPHITE_AGENT_OUTPUT_DIR", ".graphite-agent/outputs"),
        schema_version=os.getenv("GRAPHITE_AGENT_SCHEMA_VERSION", "6.3"),
        write_legacy_aliases=os.getenv("GRAPHITE_WRITE_LEGACY_ALIASES", "1") != "0",
        dry_run=os.getenv("GRAPHITE_DRY_RUN", "0") == "1",
        cli_retries=int(os.getenv("GRAPHITE_CLI_RETRIES", "2")),
    )
