from .models import RelationshipEdge
class RelationshipCollector:
    def __init__(self, config, git, ids): self.config=config; self.git=git; self.ids=ids
    def collect(self, prs):
        branch_map={p.head_ref_name:p for p in prs}; edges=[]
        edges += self._declared_base(prs, branch_map)
        edges += self._nearest_same_root(prs, branch_map, edges)
        edges += self._cross_root(prs)
        edges += self._merges(prs, branch_map)
        edges += self._patch_overlap(prs, branch_map)
        return edges
    def _edge(self, a,b,t,c,s,conf,evidence,root=None): return RelationshipEdge(self.ids.relationship_id(), a,b,t,c,s,conf,root,evidence)
    def _is_root(self,b): return bool(b and b in self.config.configured_roots)
    def root_owners_for_branch(self,b): return [r for r in self.config.configured_roots if self.git.is_ancestor(r,b)]
    def select_root_owner(self,b,base,branch_map):
        if self._is_root(b): return b
        if self._is_root(base): return base
        owners=self.root_owners_for_branch(b); return owners[0] if len(owners)==1 else None
    def _base_root(self,base,branch_map):
        if self._is_root(base): return base
        if base in branch_map: return self.select_root_owner(base, branch_map[base].base_ref_name, branch_map)
        return None
    def _declared_base(self,prs,branch_map):
        edges=[]
        for pr in prs:
            b,base=pr.head_ref_name,pr.base_ref_name
            if self._is_root(b) or not base or (base not in branch_map and not self._is_root(base)): continue
            root=self.select_root_owner(b,base,branch_map); same=bool(root and self._base_root(base,branch_map)==root)
            if same and self.git.is_ancestor(base,b): edges.append(self._edge(base,b,"declared_pr_base","executable","executable","high",[f"base_ref_name={base}",f"{base} is ancestor of {b}","same root family"],root))
            elif same: edges.append(self._edge(base,b,"declared_base_mismatch","executable","needs_restack","medium",[f"base_ref_name={base}",f"{base} is not ancestor of {b}","same root family"],root))
            else: edges.append(self._edge(base,b,"declared_base_mismatch","triage_only","triage_only","medium",[f"base_ref_name={base}","declared base is not in same root family"],root))
        return edges
    def _nearest_same_root(self,prs,branch_map,existing):
        edges=[]; branches=[p.head_ref_name for p in prs if not self._is_root(p.head_ref_name)]; done={e.to_ref for e in existing if e.classification=="executable"}
        for pr in prs:
            b=pr.head_ref_name
            if self._is_root(b) or b in done: continue
            root=self.select_root_owner(b,pr.base_ref_name,branch_map)
            if not root: continue
            candidates=[]
            for c in branches:
                if c==b: continue
                if self.select_root_owner(c,branch_map[c].base_ref_name,branch_map)==root and self.git.is_ancestor(c,b): candidates.append((self.git.commit_distance(c,b) or 10**9,c))
            if candidates:
                candidates.sort(); nearest=candidates[0][1]
                edges.append(self._edge(nearest,b,"nearest_same_root_ancestor","executable","needs_restack","medium",[f"nearest same-root ancestor={nearest}"],root))
        return edges
    def _cross_root(self,prs):
        edges=[]
        for pr in prs:
            if self._is_root(pr.head_ref_name): continue
            owners=self.root_owners_for_branch(pr.head_ref_name)
            if len(owners)>1:
                for owner in owners: edges.append(self._edge(owner,pr.head_ref_name,"cross_root_ancestry","blocked","blocked","high",[f"{owner} is ancestor of {pr.head_ref_name}","branch has multiple configured root owners"],None))
        return edges
    def _merges(self,prs,branch_map):
        edges=[]
        for pr in prs:
            b=pr.head_ref_name
            if self._is_root(b): continue
            root=self.select_root_owner(b,pr.base_ref_name,branch_map)
            if not root: continue
            for line in self.git.merge_commits_between(root,b):
                parts=line.split("")
                if len(parts)<3: continue
                sha,parents,subject=parts[0],parts[1].split(),parts[2]
                for psha in parents[1:]:
                    known=next((name for name,pi in branch_map.items() if pi.head_ref_oid==psha),None)
                    if known: edges.append(self._edge(known,b,"known_pr_merge","triage_only","triage_only","medium",[f"merge_commit={sha}",f"merged known PR branch={known}",f"subject={subject}"],root))
                    elif self.git.is_ancestor(psha,root): edges.append(self._edge(root,b,"trunk_update_merge","blocked","blocked","high",[f"merge_commit={sha}",f"subject={subject}"],root))
                    else: edges.append(self._edge(psha,b,"foreign_dag_merge","blocked","blocked","high",[f"merge_commit={sha}",f"foreign parent sha={psha}",f"subject={subject}"],root))
        return edges
    def _patch_overlap(self,prs,branch_map):
        edges=[]; branches=[p.head_ref_name for p in prs if not self._is_root(p.head_ref_name)]
        for i,a in enumerate(branches):
            root_a=self.select_root_owner(a,branch_map[a].base_ref_name,branch_map)
            if not root_a: continue
            for b in branches[i+1:]:
                root_b=self.select_root_owner(b,branch_map[b].base_ref_name,branch_map)
                if root_a!=root_b: continue
                overlap=self.git.patch_ids_between(root_a,a)&self.git.patch_ids_between(root_a,b)
                if overlap: edges.append(self._edge(a,b,"patch_id_overlap","triage_only","triage_only","medium",[f"shared patch-id count={len(overlap)}","patch equivalence is not sufficient for Graphite parentage"],root_a))
        return edges
