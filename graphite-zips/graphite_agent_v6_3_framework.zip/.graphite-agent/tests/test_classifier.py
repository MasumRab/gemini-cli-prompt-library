import unittest, sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from graphite_agent.models import PullRequestInfo, RelationshipEdge, BranchAudit
from graphite_agent.branch_classifier import BranchClassifier
class FakeVerifier:
    def verify(self,*args,**kwargs):
        return BranchAudit({"selected":"main","candidates":[],"ambiguous":False},{"single_root_owner":True,"cycle_free":True,"root_branch_resolved":True,"no_blocked_relationships":not kwargs.get('has_blocked_edges',False),"has_executable_parent":kwargs.get('executable_parent_exists',False)},[],[])
class Policy:
    def is_executable_edge(self,e): return e.classification=='executable'
    def is_blocked_edge(self,e): return e.classification=='blocked'
class Tests(unittest.TestCase):
    def pr(self): return PullRequestInfo(1,'t','u','feature/x','oid','main')
    def test_complex_dag_dependency(self):
        e=RelationshipEdge('rel','base','feature/x','known_pr_merge','triage_only','triage_only','medium','main',[])
        n=BranchClassifier(None,FakeVerifier(),Policy()).classify(self.pr(),[e])
        self.assertEqual(n.status,'complex_dag_dependency')
    def test_ghost_commit_overlap(self):
        e=RelationshipEdge('rel','a','feature/x','patch_id_overlap','triage_only','triage_only','medium','main',[])
        n=BranchClassifier(None,FakeVerifier(),Policy()).classify(self.pr(),[e])
        self.assertEqual(n.status,'ghost_commit_overlap')
    def test_complex_hub_node(self):
        e=RelationshipEdge('rel','base','feature/x','declared_pr_base','executable','executable','high','main',[])
        topo={'sources':['a','b'],'targets':['c','d']}
        n=BranchClassifier(None,FakeVerifier(),Policy()).classify(self.pr(),[e],topo)
        self.assertEqual(n.status,'complex_hub_node')
if __name__=='__main__': unittest.main()
