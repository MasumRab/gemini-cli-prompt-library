# V6.3 Handoff

This package implements the domain pipeline: adapters collect facts, collectors emit evidence, classifiers assign branch state, verifiers enforce invariants, policies decide executability, compilers generate artefacts, and executors act only on compact plans.

All declared advanced statuses have classifier paths: `complex_hub_node`, `complex_dag_dependency`, and `ghost_commit_overlap`.
