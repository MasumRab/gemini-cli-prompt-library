# Graphite Multi-Root Agentic Retrofit — V6.3 Framework

Production-hardened framework package with no placeholder PR-ops module, full JSON Schema contract files, dry-run executor support, retrying CLI adapter, expanded status classification, summary CI indexing, and a synthetic test suite.

## Configure

```bash
export GRAPHITE_TRUNK_BRANCHES="main,release/2.0"
export GRAPHITE_DRY_RUN=1   # optional safe execution preview
```

## Analyse

```bash
python .graphite-agent/1_analyze_and_plan.py
```

## Execute

```bash
python .graphite-agent/2_strict_executor.py
```

## Test

```bash
python -m unittest discover .graphite-agent/tests
```
