# Graphite Agent V8 Semantic Tooling Fixed
Run `python .graphite-agent/main.py all` in a Git repo.
