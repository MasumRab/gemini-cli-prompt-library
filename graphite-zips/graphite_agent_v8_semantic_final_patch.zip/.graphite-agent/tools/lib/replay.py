from .git_core import GitCore
from .io import artifact, get_run_id
def replay_risk():
    g=GitCore(); high=any(g.active_state().values()) or bool(g.conflicted_files()); return artifact('replay_risk.json',{'run_id':get_run_id(),'branch':g.current_branch(),'summary':{'overall_risk':'high' if high else 'low','execution_allowed':not high},'repository_state':{**g.active_state(),'dirty_worktree':bool(g.status_lines())},'conflicts':{'conflicted_files':g.conflicted_files(),'conflict_markers_detected':[]}})
