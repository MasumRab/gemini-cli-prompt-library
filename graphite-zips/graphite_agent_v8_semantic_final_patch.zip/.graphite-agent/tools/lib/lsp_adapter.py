from pathlib import Path
class MinimalLspAdapter:
    def available(self):
        try:
            import pygls; return {'available':True,'runtime':'pygls'}
        except Exception: return {'available':False,'runtime':None,'reason':'pygls not installed'}
    def diagnostics(self,path):
        p=Path(path)
        if not p.exists(): return [{'severity':'error','message':'file not found','path':path}]
        if p.suffix=='.py':
            try: compile(p.read_text(),str(p),'exec'); return []
            except SyntaxError as exc: return [{'severity':'error','message':str(exc),'line':exc.lineno,'path':path}]
        return []
