from .git_core import GitCore
class TrajectoryAnalyzer:
    def __init__(self,git=None): self.git=git or GitCore()
    def root_candidates(self,configured=None):
        roots=set(configured or []); oh=self.git.origin_head()
        if oh: roots.add(oh)
        for b in self.git.local_branches()+self.git.remote_branches():
            name=b.split('/',1)[1] if '/' in b else b
            if name in {'main','master','develop','dev','trunk'}: roots.add(name)
        return sorted(roots)
    def branch_root_edges(self,roots):
        edges=[]
        for i,b in enumerate(self.git.local_branches(),1):
            parent=None; ev=[]; mb=None
            for r in roots:
                ref=r if self.git.head(r) else 'origin/'+r
                if self.git.head(ref):
                    mb=self.git.merge_base(ref,b)
                    if self.git.is_ancestor(ref,b): parent=r; ev=[f'{r} is ancestor of {b}']; break
            edges.append({'id':f'edge-{i:06d}','from':parent,'to':b,'merge_base':mb,'edge_type':'nearest_root_ancestor' if parent else 'unrooted','classification':'executable_candidate' if parent else 'triage_only','evidence':ev or ['no root ancestor found']})
        return edges
    def recompute_stale_roots(self,root_health,topology,replay):
        failed=[]
        if replay.get('repository_state',{}).get('active_rebase'): failed.append({'id':'active-rebase','severity':'critical','evidence':['active rebase present']})
        for root,h in root_health.get('roots',{}).items():
            edges=[e for e in topology.get('edges',[]) if e.get('from')==root]
            if h.get('health')=='stale' and not h.get('execution_allowed'): failed.append({'id':'stale-root-blocker','target_root':root,'severity':'critical','evidence':h.get('evidence',[])})
            elif not h.get('evidence') and len(edges)>1 and replay.get('summary',{}).get('overall_risk')=='high': failed.append({'id':'stale-root-evidence-missing','target_root':root,'severity':'high'})
        return failed
