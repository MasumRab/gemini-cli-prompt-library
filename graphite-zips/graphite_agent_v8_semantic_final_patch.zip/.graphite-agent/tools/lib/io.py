from __future__ import annotations
import json
from pathlib import Path
from datetime import datetime, timezone
AGENT_DIR=Path('.graphite-agent'); OUTPUTS=AGENT_DIR/'outputs'; RUNS=OUTPUTS/'runs'; LATEST=OUTPUTS/'latest'; REPORTS=AGENT_DIR/'reports'; DECISION_LOG=OUTPUTS/'decision_log.jsonl'; EXECUTION_LOG=OUTPUTS/'execution_log.jsonl'
def ensure_dirs():
    for p in [OUTPUTS,RUNS,LATEST,REPORTS]: p.mkdir(parents=True, exist_ok=True)
def get_run_id(new=False):
    ensure_dirs(); f=OUTPUTS/'current_run.txt'
    if f.exists() and not new: return f.read_text().strip()
    rid=datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ'); f.write_text(rid); return rid
def run_dir(rid=None):
    p=RUNS/(rid or get_run_id()); (p/'validation').mkdir(parents=True, exist_ok=True); return p
def read_json(path, default=None):
    p=Path(path); return json.loads(p.read_text()) if p.exists() else default
def write_json(path,data):
    p=Path(path); p.parent.mkdir(parents=True, exist_ok=True); p.write_text(json.dumps(data, indent=2, sort_keys=True))
def artifact(name,data,rid=None):
    rid=rid or get_run_id(); write_json(run_dir(rid)/name,data); write_json(LATEST/name,data); return data
def root_artifact(name,data): write_json(OUTPUTS/name,data); return data
def text_artifact(name,text,rid=None,report=False):
    rid=rid or get_run_id(); p=run_dir(rid)/name; p.parent.mkdir(parents=True, exist_ok=True); p.write_text(text); lp=LATEST/name; lp.parent.mkdir(parents=True, exist_ok=True); lp.write_text(text)
    if report: (REPORTS/Path(name).name).write_text(text)
    return text
def read_jsonl(path):
    p=Path(path); return [json.loads(x) for x in p.read_text().splitlines() if x.strip()] if p.exists() else []
def append_jsonl(path,row):
    p=Path(path); p.parent.mkdir(parents=True, exist_ok=True)
    with p.open('a') as f:
        f.write(json.dumps(row, sort_keys=True) + '\\n')
