from collections import defaultdict
from pathlib import Path
from .io import artifact, read_json, LATEST, get_run_id, text_artifact
from .config import load_config, is_generated, is_ignored
from .tree_sitter_adapter import TreeSitterAdapter
from .lsp_adapter import MinimalLspAdapter
def candidate_files():
    inv=read_json(LATEST/'repo_inventory.json',{}); paths=[x[3:] for x in inv.get('state',{}).get('status_porcelain',[]) if len(x)>=4]
    if not paths: paths=[str(p) for p in Path('.').rglob('*.py') if '.git' not in p.parts and '.graphite-agent' not in p.parts]
    cfg=load_config(); return [p for p in paths if Path(p).is_file() and not is_ignored(p,cfg)]
def semantic_inventory():
    adapter=TreeSitterAdapter(); cfg=load_config(); files=[]
    for p in candidate_files()[:cfg.get('semantics',{}).get('max_files_per_run',1000)]: parsed=adapter.parse_file(p); parsed['generated']=is_generated(p,cfg); files.append(parsed)
    return artifact('semantic_inventory.json',{'run_id':get_run_id(),'adapter':adapter.available(),'files':files})
def ast_index(): inv=read_json(LATEST/'semantic_inventory.json',{'files':[]}); return artifact('ast_index.json',{'run_id':get_run_id(),'files':{f['path']:f for f in inv.get('files',[])}})
def symbol_graph():
    inv=read_json(LATEST/'semantic_inventory.json',{'files':[]}); symbols={}; edges=[]; i=0
    for f in inv.get('files',[]):
        for s in f.get('symbols',[]): symbols[s['id']]=s; i+=1; edges.append({'id':f'sym-edge-{i:06d}','from':f['path'],'to':s['id'],'edge_type':'file_defines_symbol','evidence':['AST extraction']})
    return artifact('symbol_graph.json',{'run_id':get_run_id(),'symbols':symbols,'edges':edges})
def reference_graph(): inv=read_json(LATEST/'semantic_inventory.json',{'files':[]}); ad=MinimalLspAdapter(); return artifact('reference_graph.json',{'run_id':get_run_id(),'available':ad.available().get('available',False),'adapter':ad.available(),'references':[{'file':f['path'],'diagnostics':ad.diagnostics(f['path'])} for f in inv.get('files',[])],'edges':[]})
def api_change_report():
    inv=read_json(LATEST/'semantic_inventory.json',{'files':[]}); changes=[]
    for f in inv.get('files',[]):
        for s in f.get('symbols',[]):
            if s.get('kind') in {'function','method'}: changes.append({'symbol':s.get('name'),'signature':s.get('signature'),'file':f.get('path'),'change_type':'signature_observed'})
    return artifact('api_change_report.json',{'run_id':get_run_id(),'changes':changes})
def test_impact_report(): return artifact('test_impact_report.json',{'run_id':get_run_id(),'tests':[]})
def generated_file_provenance(): inv=read_json(LATEST/'semantic_inventory.json',{'files':[]}); return artifact('generated_file_provenance.json',{'run_id':get_run_id(),'items':[{'path':f.get('path'),'reason':'matches generated-file pattern'} for f in inv.get('files',[]) if f.get('generated')]})
def semantic_conflicts():
    graph=read_json(LATEST/'symbol_graph.json',{'symbols':{}}); by=defaultdict(list); conflicts=[]
    for s in graph.get('symbols',{}).values(): by[s.get('name')].append(s)
    for name,items in by.items():
        files=sorted({x.get('file') for x in items})
        if len(files)>1: conflicts.append({'id':f'sem-conflict-{len(conflicts)+1:06d}','type':'competing_symbol_change','symbol':name,'files':files,'evidence':['same symbol name appears in multiple changed files']})
    return artifact('semantic_conflicts.json',{'run_id':get_run_id(),'conflicts':conflicts})
def semantic_questions():
    api=read_json(LATEST/'api_change_report.json',{'changes':[]}); prov=read_json(LATEST/'generated_file_provenance.json',{'items':[]}); qs=[]
    ch=api.get('changes',[{}])[0] if api.get('changes') else {}; qs.append({'id':'q-sem-000001','type':'api_change_intent','symbol':ch.get('symbol'),'question':'Should detected API shape be canonical?','options':['canonical_api_change','local_experiment','manual_semantic_review'],'recommended_option':'manual_semantic_review','evidence':[ch] if ch else ['capability self-check']})
    qs.append({'id':'q-sem-000002','type':'competing_symbol_change','symbol':None,'question':'How should competing symbol changes be handled?','options':['merge_semantics_manually','leave_both_blocked'],'recommended_option':'leave_both_blocked','evidence':['capability self-check']})
    qs.append({'id':'q-sem-000003','type':'generated_file_provenance','question':'How should generated file provenance be handled?','options':['regenerate_from_source','keep_generated_change_as_intentional','exclude_generated_change','manual_review_required'],'recommended_option':'manual_review_required','evidence':prov.get('items') or ['capability self-check']})
    text = '# Semantic Clarification Report\n\n' + '\n'.join(f"- {q['id']}: {q['type']}" for q in qs) + '\n'
    text_artifact('semantic_clarification_report.md', text, report=True)
    return artifact('semantic_questions.json', {'run_id': get_run_id(), 'questions': qs})
def semantic_recommendations(): qs=read_json(LATEST/'semantic_questions.json',{'questions':[]}); return artifact('semantic_recommendations.json',{'run_id':get_run_id(),'recommendations':[{'question_ref':q['id'],'recommended_action':q.get('recommended_option'),'blocked_until':[q['id']+' answered']} for q in qs.get('questions',[])]})
