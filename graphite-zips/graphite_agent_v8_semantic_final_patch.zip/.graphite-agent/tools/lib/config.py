from pathlib import Path
import json, fnmatch
DEFAULT_CONFIG={'roots':{'configured':[],'discover':True},'generated_files':{'patterns':['dist/**','build/**','generated/**','*.generated.*','*.lock']},'ignore_paths':['.git/**','.venv/**','node_modules/**','.graphite-agent/outputs/**'],'execution':{'default_mode':'dry_run','require_explicit_approval':True,'graphite':{'track_template':'gt track {branch} --parent {parent}','restack_template':'gt restack {branch}','submit_template':'gt submit {branch}'}},'semantics':{'enabled':True,'max_files_per_run':1000},'task_tracking':{'backend':'internal','beads':{'enabled':False,'command':'bd'}}}
def _merge(a,b):
    out=dict(a)
    for k,v in (b or {}).items(): out[k]=_merge(out.get(k,{}),v) if isinstance(v,dict) and isinstance(out.get(k),dict) else v
    return out
def load_config(path=None):
    cfg=dict(DEFAULT_CONFIG); p=Path(path) if path else Path('.graphite-agent/config/repo.yaml')
    if p.exists():
        try:
            import yaml; extra=yaml.safe_load(p.read_text()) or {}
        except Exception:
            try: extra=json.loads(p.read_text())
            except Exception: extra={}
        cfg=_merge(cfg,extra)
    return cfg
def matches(path,patterns): return any(fnmatch.fnmatch(path,pat) for pat in patterns)
def is_generated(path,cfg=None): cfg=cfg or load_config(); return matches(path,cfg.get('generated_files',{}).get('patterns',[]))
def is_ignored(path,cfg=None): cfg=cfg or load_config(); return matches(path,cfg.get('ignore_paths',[]))
