import subprocess, hashlib
from pathlib import Path
class GitCore:
    def __init__(self,cwd=None): self.cwd=cwd or '.'
    def git(self,args,check=False):
        p=subprocess.run(['git']+args,cwd=self.cwd,capture_output=True,text=True)
        if check and p.returncode: raise RuntimeError(p.stderr.strip())
        return p.returncode,p.stdout.strip(),p.stderr.strip()
    def root(self): c,o,_=self.git(['rev-parse','--show-toplevel']); return o if c==0 else None
    def current_branch(self): c,o,_=self.git(['branch','--show-current']); return o if c==0 and o else None
    def local_branches(self): c,o,_=self.git(['for-each-ref','refs/heads','--format=%(refname:short)']); return o.splitlines() if c==0 and o else []
    def remote_branches(self): c,o,_=self.git(['for-each-ref','refs/remotes','--format=%(refname:short)']); return [x for x in o.splitlines() if not x.endswith('/HEAD')] if c==0 and o else []
    def origin_head(self): c,o,_=self.git(['symbolic-ref','refs/remotes/origin/HEAD']); return o.rsplit('/',1)[-1] if c==0 and o.startswith('refs/remotes/origin/') else None
    def head(self,ref): c,o,_=self.git(['rev-parse',ref]); return o if c==0 else None
    def merge_base(self,a,b): c,o,_=self.git(['merge-base',a,b]); return o if c==0 else None
    def is_ancestor(self,a,b): return self.git(['merge-base','--is-ancestor',a,b])[0]==0
    def status_lines(self): c,o,_=self.git(['status','--porcelain=v1','-uall']); return o.splitlines() if c==0 and o else []
    def active_state(self):
        g=Path(self.root() or '.')/'.git'; return {'active_rebase':(g/'rebase-merge').exists() or (g/'rebase-apply').exists(),'active_merge':(g/'MERGE_HEAD').exists(),'active_cherry_pick':(g/'CHERRY_PICK_HEAD').exists()}
    def conflicted_files(self):
        m={'UU':'both_modified','DU':'delete_modify','UD':'delete_modify','AA':'both_added','DD':'both_deleted'}; return [{'path':x[3:],'status':x[:2],'conflict_type':m[x[:2]]} for x in self.status_lines() if len(x)>=4 and x[:2] in m]
    def patch_id(self,commit): c,o,_=self.git(['show',commit,'--pretty=format:','--patch']); return hashlib.sha1(o.encode()).hexdigest() if c==0 else None
    def get_merge_base_of_commits(self,commits):
        if not commits: return None
        c,o,_=self.git(['merge-base']+commits); return o if c==0 else None
