import ast,pathlib,tempfile,sys,unittest
ROOT=pathlib.Path(__file__).resolve().parents[1]
class T(unittest.TestCase):
 def test_syntax(self):
  for p in list((ROOT/'tools').glob('*.py'))+list((ROOT/'tools/lib').glob('*.py'))+[ROOT/'main.py']: ast.parse(p.read_text(),filename=str(p))
 def test_imports(self):
  sys.path.insert(0,str(ROOT/'tools')); import lib.symbols, lib.references, lib.semantic_conflicts, lib.semantic_questions, lib.semantic_recommendations, lib.lsp_adapter
if __name__=='__main__': unittest.main()
