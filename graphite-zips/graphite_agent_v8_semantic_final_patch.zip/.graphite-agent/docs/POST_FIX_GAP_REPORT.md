# Post-fix Gap Report
All checklist-targeted semantic files are present. Residual: Tree-sitter/LSP integrations are adapter-based unless dependencies are installed.
