# Graphite Agent V8 Capability Verification Pack

This pack verifies whether a repository's `.graphite-agent` implementation satisfies the **full V8 semantic framework** expectations discussed for graphite-agent.

It is a **verification pack**, not the V8 implementation itself.

## What it checks

The verifier checks for:

- V8 semantic tools and libraries
- Tree-sitter semantic inventory support
- AST index and symbol graph outputs
- reference graph and optional LSP adapter hooks
- semantic conflict detection
- Spec Kit-style semantic clarify questions
- semantic recommendations and validation gates
- agent todos and convergence integration
- optional Beads/task-tracker adapter boundaries
- run-scoped artifacts and latest aliases
- dry-run-only command plan behavior

## How to use

Copy or keep this verifier outside the repo under test, then run from the repository root that contains `.graphite-agent`:

```bash
python .graphite-agent-v8-verifier/tests/run_v8_verification.py --repo . --json
```

If this directory is not inside your repo, pass the verifier path explicitly:

```bash
python /path/to/.graphite-agent-v8-verifier/tests/run_v8_verification.py --repo /path/to/repo --json
```

## Expected result

A full V8 implementation should pass all **required** checks. Optional checks, such as Beads integration or LSP enrichment, may be reported as optional unless configured as required.

The verifier writes:

```text
.graphite-agent-v8-verifier/reports/v8_verification_report.json
.graphite-agent-v8-verifier/reports/v8_verification_report.md
```

## Important

The current V8 semantic scaffold previously generated in this conversation is expected to **fail** many required checks because it documents the semantic layer but does not fully implement Tree-sitter/LSP semantic runtime behavior.
