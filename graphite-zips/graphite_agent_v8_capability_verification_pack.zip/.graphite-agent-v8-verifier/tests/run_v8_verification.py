#!/usr/bin/env python3
from __future__ import annotations
import argparse, json, subprocess, sys
from pathlib import Path
from datetime import datetime, timezone

REQUIRED_TOOLS = [
    'semantic_inventory.py', 'ast_analyse.py', 'symbol_graph.py', 'reference_graph.py',
    'semantic_conflicts.py', 'semantic_clarify.py', 'semantic_recommend.py', 'validate_semantics.py'
]
REQUIRED_LIBS = [
    'tree_sitter_adapter.py', 'ast_extractors.py', 'symbols.py', 'references.py',
    'semantic_conflicts.py', 'semantic_questions.py', 'semantic_recommendations.py'
]
OPTIONAL_LIBS = ['lsp_adapter.py', 'task_tracker.py', 'beads_adapter.py']
REQUIRED_LATEST_ARTIFACTS = [
    'semantic_inventory.json', 'ast_index.json', 'symbol_graph.json', 'semantic_conflicts.json',
    'semantic_questions.json', 'semantic_recommendations.json', 'validation/semantic_validation.json'
]


def run(cmd, cwd):
    p = subprocess.run(cmd, cwd=cwd, capture_output=True, text=True)
    return {'cmd': cmd, 'returncode': p.returncode, 'stdout': p.stdout, 'stderr': p.stderr}


def check_file(path: Path, required=True):
    return {
        'id': 'file:' + str(path),
        'status': 'pass' if path.exists() else ('fail' if required else 'optional_missing'),
        'path': str(path),
        'required': required
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--repo', default='.', help='Repository root containing .graphite-agent')
    ap.add_argument('--json', action='store_true')
    ap.add_argument('--run-tools', action='store_true', help='Attempt to run semantic tools before checking artifacts')
    args = ap.parse_args()

    repo = Path(args.repo).resolve()
    agent = repo / '.graphite-agent'
    verifier = Path(__file__).resolve().parents[1]
    report_dir = verifier / 'reports'
    report_dir.mkdir(parents=True, exist_ok=True)

    checks = []
    checks.append(check_file(agent / 'tools' / 'graphite_agent.py', required=False))

    for t in REQUIRED_TOOLS:
        checks.append(check_file(agent / 'tools' / t, required=True))
    for l in REQUIRED_LIBS:
        checks.append(check_file(agent / 'tools' / 'lib' / l, required=True))
    for l in OPTIONAL_LIBS:
        checks.append(check_file(agent / 'tools' / 'lib' / l, required=False))

    tool_runs = []
    if args.run_tools:
        sequence = [
            ['python', str(agent / 'tools' / 'semantic_inventory.py')],
            ['python', str(agent / 'tools' / 'ast_analyse.py')],
            ['python', str(agent / 'tools' / 'symbol_graph.py')],
            ['python', str(agent / 'tools' / 'semantic_conflicts.py')],
            ['python', str(agent / 'tools' / 'semantic_clarify.py')],
            ['python', str(agent / 'tools' / 'semantic_recommend.py')],
            ['python', str(agent / 'tools' / 'validate_semantics.py')]
        ]
        for cmd in sequence:
            if Path(cmd[1]).exists():
                tool_runs.append(run(cmd, repo))

    for a in REQUIRED_LATEST_ARTIFACTS:
        checks.append(check_file(agent / 'outputs' / 'latest' / a, required=True))

    # Semantic questions content checks, if present.
    questions_path = agent / 'outputs' / 'latest' / 'semantic_questions.json'
    semantic_question_checks = []
    if questions_path.exists():
        try:
            data = json.loads(questions_path.read_text())
            questions = data.get('questions', data if isinstance(data, list) else [])
            q_types = {q.get('type') for q in questions if isinstance(q, dict)}
            for qtype in ['api_change_intent', 'competing_symbol_change', 'generated_file_provenance']:
                semantic_question_checks.append({
                    'id': 'semantic_question_type:' + qtype,
                    'status': 'pass' if qtype in q_types else 'fail',
                    'required': True
                })
        except Exception as exc:
            semantic_question_checks.append({'id': 'semantic_questions_parseable', 'status': 'fail', 'error': str(exc), 'required': True})
    else:
        semantic_question_checks.append({'id': 'semantic_questions_present', 'status': 'fail', 'required': True})
    checks.extend(semantic_question_checks)

    failed = [c for c in checks if c.get('status') == 'fail']
    optional_missing = [c for c in checks if c.get('status') == 'optional_missing']
    result = {
        'generated_at_utc': datetime.now(timezone.utc).isoformat(),
        'repo': str(repo),
        'status': 'pass' if not failed else 'fail',
        'summary': {
            'checks_total': len(checks),
            'failed': len(failed),
            'optional_missing': len(optional_missing)
        },
        'checks': checks,
        'tool_runs': tool_runs,
        'interpretation': 'Full V8 semantic implementation verified' if not failed else 'Full V8 semantic implementation is incomplete or not yet run successfully'
    }

    (report_dir / 'v8_verification_report.json').write_text(json.dumps(result, indent=2), encoding='utf-8')
    md = ['# V8 Verification Report', '', f"Status: **{result['status'].upper()}**", '', '## Summary', f"- Total checks: {len(checks)}", f"- Failed: {len(failed)}", f"- Optional missing: {len(optional_missing)}", '', '## Failed Checks']
    if failed:
        for c in failed:
            md.append(f"- `{c.get('id')}` → {c.get('path','')}")
    else:
        md.append('- None')
    md.append('')
    md.append('## Optional Missing')
    if optional_missing:
        for c in optional_missing:
            md.append(f"- `{c.get('id')}`")
    else:
        md.append('- None')
    (report_dir / 'v8_verification_report.md').write_text('\n'.join(md) + '\n', encoding='utf-8')

    if args.json:
        print(json.dumps(result, indent=2))
    else:
        print(f"V8 verification status: {result['status']} ({len(failed)} failed checks)")
        print(f"Report: {report_dir / 'v8_verification_report.md'}")
    return 0 if not failed else 1

if __name__ == '__main__':
    raise SystemExit(main())
