# V8 Semantic Artifact Checklist

A full run should produce run-scoped and latest artifacts:

- [ ] `semantic_inventory.json`
- [ ] `ast_index.json`
- [ ] `symbol_graph.json`
- [ ] `reference_graph.json`
- [ ] `api_change_report.json`
- [ ] `test_impact_report.json`
- [ ] `generated_file_provenance.json`
- [ ] `semantic_conflicts.json`
- [ ] `semantic_questions.json`
- [ ] `semantic_recommendations.json`
- [ ] `validation/semantic_validation.json`
- [ ] `reports/semantic_conflict_report.md`
- [ ] `reports/semantic_clarification_report.md`
