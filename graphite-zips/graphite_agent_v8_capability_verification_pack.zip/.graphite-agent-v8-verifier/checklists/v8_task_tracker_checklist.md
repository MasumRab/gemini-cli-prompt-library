# V8 Task Tracker / Beads Compatibility Checklist

Internal todos remain canonical:

- [ ] `agent_todos.json` exists and is usable without external tracker
- [ ] task tracker integration is opt-in
- [ ] Beads is not a hard dependency
- [ ] `export_todos.py --backend beads --dry-run` exists
- [ ] `import_todos.py --backend beads` exists or reports unsupported gracefully
- [ ] task export preserves dependencies/blockers when available
- [ ] task export uses machine-readable output
