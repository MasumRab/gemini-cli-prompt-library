# V8 Semantic Clarify Checklist

The implementation should generate bounded, evidence-backed questions for:

- [ ] API signature changed and dependent callers exist
- [ ] deleted symbol still referenced
- [ ] multiple branches change same symbol
- [ ] generated file changed without source/schema provenance
- [ ] test expectation changed without corresponding source change
- [ ] hunk ownership ambiguous
- [ ] branch split required

Each question should include:

- [ ] stable question ID
- [ ] branch/symbol scope
- [ ] evidence references
- [ ] bounded options
- [ ] recommended option
- [ ] confidence
- [ ] decision recording path
