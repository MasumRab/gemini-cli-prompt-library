# V8 Required Files Checklist

## Tools

- [ ] `.graphite-agent/tools/semantic_inventory.py`
- [ ] `.graphite-agent/tools/ast_analyse.py`
- [ ] `.graphite-agent/tools/symbol_graph.py`
- [ ] `.graphite-agent/tools/reference_graph.py`
- [ ] `.graphite-agent/tools/semantic_conflicts.py`
- [ ] `.graphite-agent/tools/semantic_clarify.py`
- [ ] `.graphite-agent/tools/semantic_recommend.py`
- [ ] `.graphite-agent/tools/validate_semantics.py`
- [ ] `.graphite-agent/tools/export_todos.py`
- [ ] `.graphite-agent/tools/import_todos.py`

## Libraries

- [ ] `.graphite-agent/tools/lib/tree_sitter_adapter.py`
- [ ] `.graphite-agent/tools/lib/ast_extractors.py`
- [ ] `.graphite-agent/tools/lib/lsp_adapter.py`
- [ ] `.graphite-agent/tools/lib/symbols.py`
- [ ] `.graphite-agent/tools/lib/references.py`
- [ ] `.graphite-agent/tools/lib/semantic_conflicts.py`
- [ ] `.graphite-agent/tools/lib/semantic_questions.py`
- [ ] `.graphite-agent/tools/lib/semantic_recommendations.py`
- [ ] `.graphite-agent/tools/lib/task_tracker.py`
- [ ] `.graphite-agent/tools/lib/beads_adapter.py`
