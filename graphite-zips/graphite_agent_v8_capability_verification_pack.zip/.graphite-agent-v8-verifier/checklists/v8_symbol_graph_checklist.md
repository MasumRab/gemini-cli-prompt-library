# V8 Symbol Graph Checklist

The symbol graph should support:

- [ ] file-to-symbol extraction
- [ ] branch-to-symbol change edges
- [ ] hunk-to-enclosing-symbol mapping
- [ ] same-symbol changed-by-multiple-branches detection
- [ ] public/API-like symbol marking where possible
- [ ] test-symbol classification
- [ ] generated-file provenance link where possible
- [ ] optional LSP reference enrichment
