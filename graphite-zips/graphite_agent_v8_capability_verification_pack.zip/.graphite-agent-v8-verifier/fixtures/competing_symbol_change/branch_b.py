def authorize(payment):
    return payment.amount > 0 and not payment.flagged
