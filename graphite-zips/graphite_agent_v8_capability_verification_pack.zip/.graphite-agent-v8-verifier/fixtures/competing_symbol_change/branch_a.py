def authorize(payment):
    return payment.amount > 0
