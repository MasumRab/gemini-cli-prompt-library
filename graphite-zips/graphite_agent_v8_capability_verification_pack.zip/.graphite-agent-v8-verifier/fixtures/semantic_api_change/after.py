class Client:
    def fetch_user(self, user_id, include_profile=False):
        return {"id": user_id, "profile": include_profile}
