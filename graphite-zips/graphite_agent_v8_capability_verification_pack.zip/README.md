# Graphite Agent V8 Verification Pack

This ZIP contains checklists, contracts, fixtures, and a verification test runner to determine whether a `.graphite-agent` implementation actually provides the full V8 semantic capabilities.

Run from the repository root under test:

```bash
python .graphite-agent-v8-verifier/tests/run_v8_verification.py --repo . --json
```

To attempt semantic tools before verifying artifacts:

```bash
python .graphite-agent-v8-verifier/tests/run_v8_verification.py --repo . --run-tools --json
```

This pack is intentionally strict. The previously generated V8 semantic scaffold is expected to fail required runtime checks until the Tree-sitter/LSP semantic tools are implemented.
