# TEST_REPORT

## Syntax validation
Passed for all generated Python files.

## Unit tests
```text

test_projection_module_imports (test_v8_targeted.V8TargetedTests.test_projection_module_imports) ... ok
test_semantic_import_and_extraction (test_v8_targeted.V8TargetedTests.test_semantic_import_and_extraction) ... ok
test_syntax (test_v8_targeted.V8TargetedTests.test_syntax) ... ok

----------------------------------------------------------------------
Ran 3 tests in 0.052s

OK

```
