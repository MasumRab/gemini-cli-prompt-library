# Graphite Agent V8 Targeted Complete Bundle

Copy `.graphite-agent` into a Git repo and run:

```bash
python .graphite-agent/main.py all
```
