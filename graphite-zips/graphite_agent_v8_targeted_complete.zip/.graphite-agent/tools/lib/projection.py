from __future__ import annotations
from .io import read_json, read_jsonl, artifact, root_artifact, LATEST, DECISION_LOG, get_run_id

def active_decisions():
    decisions={}
    for ev in read_jsonl(DECISION_LOG):
        key=ev.get('branch') or ev.get('scope') or ev.get('target_root') or ev.get('question_id')
        if not key: continue
        if ev.get('event_type')=='decision_revoked': decisions.pop(key,None)
        else: decisions[key]=ev
    return decisions

def rebuild_execution_plan():
    snap=read_json(LATEST/'analysis_snapshot.json', read_json('.graphite-agent/outputs/analysis_snapshot.json', {'branches':{}}))
    decisions=active_decisions(); queue=[]; blocked=[]
    for branch, meta in snap.get('branches',{}).items():
        dec=decisions.get(branch); target=None
        if meta.get('candidate_targets'): target=meta['candidate_targets'][0].get('target')
        if dec and 'target=' in str(dec.get('choice','')): target=str(dec['choice']).split('target=',1)[1]
        if meta.get('requires_user_decision') and not dec:
            blocked.append({'branch':branch,'reason':'target decision required'}); continue
        if target: queue.append({'branch':branch,'parent':target,'action':'graphite_track','source':'projection'})
        else: blocked.append({'branch':branch,'reason':'no target/parent resolved'})
    plan={'run_id':get_run_id(),'execution_queue':queue,'blocked':blocked,'decisions_applied':list(decisions)}
    artifact('execution_plan.json',plan); root_artifact('execution_plan.json',plan); return plan
