import argparse, json
from .analysis import discover_repo, analyse
from .replay import replay_risk
from .semantic import semantic_inventory, ast_index, symbol_graph, reference_graph, semantic_conflicts, semantic_questions, semantic_recommendations
from .projection import rebuild_execution_plan
from .validation import validate_all, validate_replay, validate_targets, validate_roots, validate_semantics, validate_plan
from .command_plan import build_command_plan
from .execution import ExecutionEngine
from .io import artifact, read_json, LATEST, get_run_id, text_artifact
from .task_tracker import export_todos
STAGES={'discover':{},'analyse':{},'triage':{},'decide':{},'plan':{},'validate':{},'execute':{}}
def semantic_stage(): semantic_inventory(); ast_index(); symbol_graph(); reference_graph(); semantic_conflicts(); semantic_questions(); semantic_recommendations(); return validate_semantics()
def triage():
    qs=read_json(LATEST/'semantic_questions.json',{'questions':[]}); todos=[{'id':f'todo-sem-{i+1:06d}','status':'open','priority':'high','description':'Resolve semantic question '+q['id'],'question_ref':q['id']} for i,q in enumerate(qs.get('questions',[]))]
    return artifact('agent_todos.json',{'run_id':get_run_id(),'todos':todos})
def decide(): return artifact('decision_projection_status.json',{'run_id':get_run_id(),'status':'decisions-read-from-decision_log.jsonl'})
def report():
    cp=read_json(LATEST/'command_plan.json',{'commands':[]}); qs=read_json(LATEST/'semantic_questions.json',{'questions':[]})
    return text_artifact('branch_stacking_report.md',f"# Branch Stacking Report\n\nCommands: {len(cp.get('commands',[]))}\nSemantic questions: {len(qs.get('questions',[]))}\n",report=True)
def all_stage():
    discover_repo(); replay_risk(); analyse(); semantic_stage(); triage(); decide(); rebuild_execution_plan(); validate_all(); build_command_plan(); report(); return read_json(LATEST/'command_plan.json')
def main(argv=None):
    p=argparse.ArgumentParser(); p.add_argument('--dry-run',action='store_true'); p.add_argument('--backend',default='internal')
    sub=p.add_subparsers(dest='cmd',required=True)
    for c in ['discover','analyse','triage','decide','plan','validate','execute','semantic','validate-roots','validate-replay','validate-targets','validate-semantics','validate-plan','command-plan','report','export-todos','all']: sub.add_parser(c)
    a=p.parse_args(argv)
    mapping={'discover':discover_repo,'analyse':analyse,'triage':triage,'decide':decide,'plan':rebuild_execution_plan,'validate':validate_all,'execute':lambda:ExecutionEngine().execute(dry_run=a.dry_run),'semantic':semantic_stage,'validate-roots':validate_roots,'validate-replay':validate_replay,'validate-targets':validate_targets,'validate-semantics':validate_semantics,'validate-plan':validate_plan,'command-plan':build_command_plan,'report':report,'export-todos':lambda:export_todos(a.backend,a.dry_run),'all':all_stage}
    out=mapping[a.cmd](); print(json.dumps(out,indent=2) if not isinstance(out,str) else out)
