from __future__ import annotations
from .io import artifact, root_artifact, get_run_id
from .config import load_config
from .git_core import GitCore
from .trajectory import TrajectoryAnalyzer

def discover_repo():
    g=GitCore(); root=g.root()
    if not root: raise SystemExit('Not inside a Git repository')
    data={'run_id':get_run_id(),'repo':{'git_root':root,'current_branch':g.current_branch(),'is_dirty':bool(g.status_lines())},'state':{**g.active_state(),'conflicted_files':g.conflicted_files(),'status_porcelain':g.status_lines()},'branches':{'local':g.local_branches(),'remote':g.remote_branches()},'targets':{'origin_head':g.origin_head(),'configured':load_config().get('roots',{}).get('configured',[]),'discovered':[]}}
    return artifact('repo_inventory.json',data)

def analyse():
    cfg=load_config(); ta=TrajectoryAnalyzer(); roots=ta.root_candidates(cfg.get('roots',{}).get('configured',[])); edges=ta.branch_root_edges(roots)
    nodes={r:{'type':'root'} for r in roots}
    for e in edges: nodes[e['to']]={'type':'branch'}
    topo=artifact('topology_graph.json',{'run_id':get_run_id(),'roots':roots,'nodes':nodes,'edges':edges})
    matrix={}; questions=[]
    for e in edges:
        b=e['to']; unresolved=e['from'] is None; q=[]
        if unresolved:
            qid=f'q-target-{len(questions)+1:06d}'; q=[qid]; questions.append({'id':qid,'type':'target_intent','branch':b,'question':f'Which target should {b} use?','options':['leave_triage','exclude_from_migration']})
        matrix[b]={'candidate_targets':[{'target':e['from'],'confidence':'medium','evidence':e.get('evidence',[])}] if e['from'] else [],'requires_user_decision':unresolved,'question_refs':q}
    artifact('target_matrix.json',{'run_id':get_run_id(),'branches':matrix}); artifact('target_questions.json',questions)
    roots_h={r:{'health':'current','execution_allowed':True,'affected_branches':[e['to'] for e in edges if e['from']==r],'evidence':['computed from trajectory graph']} for r in roots}
    artifact('root_health.json',{'run_id':get_run_id(),'roots':roots_h})
    snap={'run_id':get_run_id(),'branches':matrix,'topology_edges':edges,'roots':roots_h}
    artifact('analysis_snapshot.json',snap); root_artifact('analysis_snapshot.json',snap); return snap
