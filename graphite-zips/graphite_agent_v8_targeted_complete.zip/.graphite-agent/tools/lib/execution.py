import os, subprocess
from .io import read_json, artifact, LATEST, get_run_id, append_jsonl, EXECUTION_LOG
from .validation import validate_all

def clean_worktree_gate():
    from .git_core import GitCore
    g=GitCore(); st=g.active_state()
    return not any(st.values()) and not g.conflicted_files()
class ExecutionEngine:
    def execute(self, dry_run=True):
        validation=validate_all(); plan=read_json(LATEST/'command_plan.json',{'commands':[]})
        if validation['status']=='blocked': return artifact('execution_result.json',{'run_id':get_run_id(),'status':'blocked','reason':'validation failed','validation':validation})
        if os.environ.get('GRAPHITE_AGENT_APPROVED')!='1': return artifact('execution_result.json',{'run_id':get_run_id(),'status':'blocked','reason':'GRAPHITE_AGENT_APPROVED=1 required'})
        if not clean_worktree_gate(): return artifact('execution_result.json',{'run_id':get_run_id(),'status':'blocked','reason':'working tree not clean or active replay state'})
        results=[]
        for cmd in plan.get('commands',[]):
            row={'command':cmd['command'],'dry_run':dry_run}
            if dry_run: row['status']='dry_run'
            else:
                p=subprocess.run(cmd['command'],shell=True,capture_output=True,text=True); row.update({'returncode':p.returncode,'stdout':p.stdout,'stderr':p.stderr})
            append_jsonl(EXECUTION_LOG,row); results.append(row)
            if row.get('returncode',0): break
        return artifact('execution_result.json',{'run_id':get_run_id(),'status':'pass' if all(r.get('returncode',0)==0 for r in results) else 'failed','results':results,'rollback_log':str(EXECUTION_LOG)})
