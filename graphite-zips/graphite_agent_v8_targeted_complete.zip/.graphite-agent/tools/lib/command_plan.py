from .io import read_json, artifact, LATEST, get_run_id
from .config import load_config

def build_command_plan():
    validation=read_json(LATEST/'validation/all_validation.json',{})
    execution=read_json(LATEST/'execution_plan.json',{'execution_queue':[]})
    blocked=validation.get('status')=='blocked'; cmds=[]; tmpl=load_config()['execution']['graphite']['track_template']
    if not blocked:
        for item in execution.get('execution_queue',[]):
            command=tmpl.format(branch=item['branch'], parent=item['parent'])
            cmds.append({'type':'graphite_track','branch':item['branch'],'parent':item['parent'],'command':command,'requires_approval':True,'dry_run':True,'blocked_by':[]})
    return artifact('command_plan.json',{'run_id':get_run_id(),'mode':'dry_run','execution_allowed':False,'blocked_by':['validation'] if blocked else [],'commands':cmds})
