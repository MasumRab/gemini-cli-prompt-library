from __future__ import annotations
import json
from pathlib import Path
from datetime import datetime, timezone
from typing import Any

AGENT_DIR = Path('.graphite-agent')
OUTPUTS = AGENT_DIR / 'outputs'
RUNS = OUTPUTS / 'runs'
LATEST = OUTPUTS / 'latest'
REPORTS = AGENT_DIR / 'reports'
DECISION_LOG = OUTPUTS / 'decision_log.jsonl'
EXECUTION_LOG = OUTPUTS / 'execution_log.jsonl'

def ensure_dirs():
    for p in [OUTPUTS, RUNS, LATEST, REPORTS]:
        p.mkdir(parents=True, exist_ok=True)

def run_id(new: bool = False) -> str:
    ensure_dirs()
    f = OUTPUTS / 'current_run.txt'
    if f.exists() and not new:
        return f.read_text(encoding='utf-8').strip()
    rid = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')
    f.write_text(rid, encoding='utf-8')
    return rid

def get_run_id(new: bool = False) -> str:
    return run_id(new=new)

def run_dir(rid: str | None = None) -> Path:
    p = RUNS / (rid or run_id())
    (p / 'validation').mkdir(parents=True, exist_ok=True)
    return p

def read_json(path: str | Path, default: Any = None) -> Any:
    p = Path(path)
    if not p.exists(): return default
    return json.loads(p.read_text(encoding='utf-8'))

def write_json(path: str | Path, data: Any) -> None:
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(data, indent=2, sort_keys=True), encoding='utf-8')

def artifact(name: str, data: Any, rid: str | None = None) -> Any:
    rid = rid or run_id()
    write_json(run_dir(rid) / name, data)
    write_json(LATEST / name, data)
    return data

def root_artifact(name: str, data: Any) -> Any:
    write_json(OUTPUTS / name, data)
    return data

def text_artifact(name: str, text: str, rid: str | None = None, report: bool = False) -> str:
    rid = rid or run_id()
    p = run_dir(rid) / name
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(text, encoding='utf-8')
    lp = LATEST / name
    lp.parent.mkdir(parents=True, exist_ok=True)
    lp.write_text(text, encoding='utf-8')
    if report:
        rp = REPORTS / Path(name).name
        rp.parent.mkdir(parents=True, exist_ok=True)
        rp.write_text(text, encoding='utf-8')
    return text

def read_jsonl(path: str | Path) -> list[dict]:
    p = Path(path)
    if not p.exists(): return []
    return [json.loads(line) for line in p.read_text(encoding='utf-8').splitlines() if line.strip()]

def append_jsonl(path: str | Path, row: dict) -> None:
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    with p.open('a', encoding='utf-8') as f:
        f.write(json.dumps(row, sort_keys=True) + '\n')
