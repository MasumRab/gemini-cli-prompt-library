#!/usr/bin/env python3
import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
from lib.dispatcher import main
main(['triage']+sys.argv[1:])
