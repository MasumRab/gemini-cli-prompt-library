class Client:
    def fetch_user(self, user_id):
        return {"id": user_id}
