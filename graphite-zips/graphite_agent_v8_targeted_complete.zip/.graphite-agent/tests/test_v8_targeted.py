import ast, pathlib, tempfile, sys, unittest, json
ROOT=pathlib.Path(__file__).resolve().parents[1]
class V8TargetedTests(unittest.TestCase):
 def test_syntax(self):
  for p in list((ROOT/'tools').glob('*.py'))+list((ROOT/'tools/lib').glob('*.py'))+[ROOT/'main.py']: ast.parse(p.read_text(),filename=str(p))
 def test_semantic_import_and_extraction(self):
  sys.path.insert(0,str(ROOT/'tools'))
  from lib.ast_extractors import extract_symbols
  with tempfile.TemporaryDirectory() as td:
   p=pathlib.Path(td)/'x.py'; p.write_text('class A:\n    def m(self,x):\n        return x\n')
   names=[s['name'] for s in extract_symbols(str(p))['symbols']]
   self.assertIn('A',names); self.assertIn('A.m',names)
 def test_projection_module_imports(self):
  sys.path.insert(0,str(ROOT/'tools'))
  import lib.projection, lib.command_plan, lib.execution, lib.trajectory
if __name__=='__main__': unittest.main()
