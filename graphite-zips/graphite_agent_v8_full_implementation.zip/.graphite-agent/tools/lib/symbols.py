from __future__ import annotations
from pathlib import Path
from .io import artifact, read_json, LATEST, get_run_id
from .config import load_config, is_ignored, is_generated
from .tree_sitter_adapter import TreeSitterAdapter
def candidate_files():
    inv=read_json(LATEST/'repo_inventory.json',{}); paths=[l[3:] for l in inv.get('state',{}).get('status_porcelain',[]) if len(l)>=4]
    if not paths: paths=[str(p) for p in Path('.').rglob('*.py') if '.git' not in p.parts and '.graphite-agent' not in p.parts]
    cfg=load_config(); return [p for p in paths if Path(p).is_file() and not is_ignored(p,cfg)]
def semantic_inventory():
    rid=get_run_id(); adapter=TreeSitterAdapter(); files=[]
    for p in candidate_files()[:load_config().get('semantics',{}).get('max_files_per_run',1000)]:
        parsed=adapter.parse_file(p); parsed['generated']=is_generated(p); files.append(parsed)
    return artifact('semantic_inventory.json',{'run_id':rid,'files':files,'adapter':adapter.available()},rid)
def ast_index():
    rid=get_run_id(); inv=read_json(LATEST/'semantic_inventory.json',{'files':[]}); return artifact('ast_index.json',{'run_id':rid,'files':{f['path']:f for f in inv.get('files',[])}},rid)
def symbol_graph():
    rid=get_run_id(); inv=read_json(LATEST/'semantic_inventory.json',{'files':[]}); symbols={}; edges=[]; i=0
    for f in inv.get('files',[]):
        for s in f.get('symbols',[]):
            symbols[s['id']]=s; i+=1; edges.append({'id':f'sym-edge-{i:06d}','from':f['path'],'to':s['id'],'edge_type':'file_defines_symbol','evidence':['AST extraction']})
    return artifact('symbol_graph.json',{'run_id':rid,'symbols':symbols,'edges':edges},rid)
