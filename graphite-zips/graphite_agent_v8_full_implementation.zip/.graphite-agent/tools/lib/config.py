from __future__ import annotations
from pathlib import Path
import fnmatch, json
DEFAULT_CONFIG={'generated_files':{'patterns':['dist/**','build/**','*.generated.*','*.lock','generated/**']},'ignore_paths':['.git/**','.venv/**','node_modules/**','.graphite-agent/outputs/**'],'semantics':{'max_files_per_run':1000},'task_tracking':{'backend':'internal','beads':{'enabled':False,'command':'bd'}}}
def load_config(path=None):
    cfg=json.loads(json.dumps(DEFAULT_CONFIG)); p=Path(path) if path else Path('.graphite-agent/config/repo.yaml')
    if p.exists():
        try:
            import yaml; extra=yaml.safe_load(p.read_text()) or {}
        except Exception:
            try: extra=json.loads(p.read_text())
            except Exception: extra={}
        def merge(a,b):
            for k,v in b.items(): a[k]=merge(a.get(k,{}),v) if isinstance(v,dict) and isinstance(a.get(k),dict) else v
            return a
        cfg=merge(cfg,extra)
    return cfg
def matches(path, patterns): return any(fnmatch.fnmatch(path, pat) for pat in patterns)
def is_generated(path,cfg=None): cfg=cfg or load_config(); return matches(path,cfg.get('generated_files',{}).get('patterns',[]))
def is_ignored(path,cfg=None): cfg=cfg or load_config(); return matches(path,cfg.get('ignore_paths',[]))
