from .io import artifact, get_run_id
def reference_graph(): return artifact('reference_graph.json', {'run_id': get_run_id(), 'available': False, 'reason': 'LSP adapter not configured', 'references': [], 'edges': []})
