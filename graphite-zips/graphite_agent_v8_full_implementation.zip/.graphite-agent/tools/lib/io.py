from __future__ import annotations
import json, os
from datetime import datetime, timezone
from pathlib import Path
from typing import Any
AGENT_DIR=Path('.graphite-agent'); OUT=AGENT_DIR/'outputs'; RUNS=OUT/'runs'; LATEST=OUT/'latest'; REPORTS=AGENT_DIR/'reports'; DECISION_LOG=OUT/'decision_log.jsonl'
def ensure_dirs():
    for p in [OUT,RUNS,LATEST,REPORTS]: p.mkdir(parents=True,exist_ok=True)
def get_run_id(new=False):
    ensure_dirs(); f=OUT/'current_run.txt'
    if f.exists() and not new: return f.read_text().strip()
    rid=datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ'); f.write_text(rid); return rid
def run_dir(run_id=None):
    p=RUNS/(run_id or get_run_id()); (p/'validation').mkdir(parents=True,exist_ok=True); return p
def read_json(path, default=None):
    p=Path(path); return json.loads(p.read_text(encoding='utf-8')) if p.exists() else default
def write_json(path,data):
    p=Path(path); p.parent.mkdir(parents=True,exist_ok=True); p.write_text(json.dumps(data,indent=2,sort_keys=True),encoding='utf-8')
def artifact(name,data,run_id=None):
    rid=run_id or get_run_id(); write_json(run_dir(rid)/name,data); write_json(LATEST/name,data); return data
def text_artifact(name,text,run_id=None,report=False):
    rid=run_id or get_run_id(); p=run_dir(rid)/name; p.parent.mkdir(parents=True,exist_ok=True); p.write_text(text,encoding='utf-8'); lp=LATEST/name; lp.parent.mkdir(parents=True,exist_ok=True); lp.write_text(text,encoding='utf-8')
    if report:
        rp=REPORTS/Path(name).name; rp.parent.mkdir(parents=True,exist_ok=True); rp.write_text(text,encoding='utf-8')
    return text
