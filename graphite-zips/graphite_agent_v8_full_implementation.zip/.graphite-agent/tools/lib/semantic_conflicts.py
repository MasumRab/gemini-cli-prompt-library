from collections import defaultdict
from .io import read_json, artifact, LATEST, get_run_id
def detect_semantic_conflicts():
    graph=read_json(LATEST/'symbol_graph.json',{'symbols':{}}); by=defaultdict(list); conflicts=[]
    for s in graph.get('symbols',{}).values(): by[s.get('name')].append(s)
    for name,entries in by.items():
        files=sorted({e.get('file') for e in entries})
        if len(files)>1: conflicts.append({'id':f'sem-conflict-{len(conflicts)+1:06d}','type':'competing_symbol_change','symbol':name,'files':files,'evidence':['same symbol name appears in multiple changed files']})
    return artifact('semantic_conflicts.json',{'run_id':get_run_id(),'conflicts':conflicts})
