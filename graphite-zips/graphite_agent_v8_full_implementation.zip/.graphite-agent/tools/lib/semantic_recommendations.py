from .io import read_json, artifact, LATEST, get_run_id
def semantic_recommendations():
    qs=read_json(LATEST/'semantic_questions.json',{'questions':[]}); recs=[{'id':'sem-rec-'+q['id'].split('-')[-1],'question_ref':q['id'],'recommended_action':q.get('recommended_option'),'blocked_until':[q['id']+' answered']} for q in qs.get('questions',[])]
    return artifact('semantic_recommendations.json',{'run_id':get_run_id(),'recommendations':recs})
def validate_semantics():
    qs=read_json(LATEST/'semantic_questions.json',{'questions':[]}); failed=[]
    if qs.get('questions'): failed.append({'id':'semantic-questions-open','severity':'high','count':len(qs['questions'])})
    return artifact('validation/semantic_validation.json',{'run_id':get_run_id(),'status':'blocked' if failed else 'pass','failed_checks':failed})
