from __future__ import annotations
import subprocess
from pathlib import Path
class GitCore:
    def __init__(self,cwd=None): self.cwd=cwd or '.'
    def git(self,args):
        p=subprocess.run(['git']+args,cwd=self.cwd,capture_output=True,text=True); return p.returncode,p.stdout.strip(),p.stderr.strip()
    def root(self): c,o,_=self.git(['rev-parse','--show-toplevel']); return o if c==0 else None
    def current_branch(self): c,o,_=self.git(['branch','--show-current']); return o if c==0 and o else None
    def status_lines(self): c,o,_=self.git(['status','--porcelain=v1','-uall']); return o.splitlines() if c==0 and o else []
    def local_branches(self): c,o,_=self.git(['for-each-ref','refs/heads','--format=%(refname:short)']); return o.splitlines() if c==0 and o else []
    def remote_branches(self): c,o,_=self.git(['for-each-ref','refs/remotes','--format=%(refname:short)']); return [x for x in o.splitlines() if not x.endswith('/HEAD')] if c==0 and o else []
    def origin_head(self): c,o,_=self.git(['symbolic-ref','refs/remotes/origin/HEAD']); return o.rsplit('/',1)[-1] if c==0 and o.startswith('refs/remotes/origin/') else None
    def active_state(self):
        g=Path(self.root() or '.')/'.git'; return {'active_rebase':(g/'rebase-merge').exists() or (g/'rebase-apply').exists(),'active_merge':(g/'MERGE_HEAD').exists(),'active_cherry_pick':(g/'CHERRY_PICK_HEAD').exists()}
    def conflicts(self):
        m={'UU':'both_modified','DU':'delete_modify','UD':'delete_modify','AA':'both_added','DD':'both_deleted'}; return [{'path':l[3:],'status':l[:2],'conflict_type':m[l[:2]]} for l in self.status_lines() if len(l)>=4 and l[:2] in m]
