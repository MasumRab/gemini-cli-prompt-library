# V8 Constitution
Analyzer-first. Semantic clarify before command planning.
