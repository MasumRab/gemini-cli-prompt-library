# Test Report

```text

test_extractor (test_v8_semantics.T.test_extractor) ... ok
test_syntax (test_v8_semantics.T.test_syntax) ... ok

----------------------------------------------------------------------
Ran 2 tests in 0.010s

OK

```
