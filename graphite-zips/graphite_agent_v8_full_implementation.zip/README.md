# Graphite Agent V8 Full Implementation
Copy `.graphite-agent` into a Git repository and run:

```bash
python .graphite-agent/main.py all --local-only
```
