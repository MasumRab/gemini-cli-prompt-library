# Known Limitations
- Tree-sitter and LSP are optional boundaries; Python AST fallback is implemented.
- Semantic analysis is evidence-backed and heuristic.
- Graphite mutation remains gated and not wired by default.
